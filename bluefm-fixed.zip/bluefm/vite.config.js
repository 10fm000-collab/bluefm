import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';

const ROOT = import.meta.dirname;

/* Firebase web config is PUBLIC by design (it is not a secret). It is injected
 * at build time from env so the same repo builds for local + Vercel.
 * Without these vars the app simply runs cookie-auth only. */
const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY || '',
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN || '',
  projectId: process.env.VITE_FIREBASE_PROJECT_ID || '',
  appId: process.env.VITE_FIREBASE_APP_ID || '',
};

const firebaseConfigPlugin = {
  name: 'inject-firebase-config',
  transformIndexHtml(html) {
    if (!firebaseConfig.apiKey) return html;
    const script = `<script>window.__FIREBASE_CONFIG__ = ${JSON.stringify(firebaseConfig)};</script>`;
    return html.replace('</head>', `  ${script}\n  </head>`);
  },
};

export default defineConfig({
  root: path.join(ROOT, 'client'),
  plugins: [react(), firebaseConfigPlugin],
  publicDir: path.join(ROOT, 'public'),
  build: {
    outDir: path.join(ROOT, 'dist', 'client'),
    emptyOutDir: true,
    target: 'es2020',
    sourcemap: false,
  },
  server: {
    host: '0.0.0.0',
    allowedHosts: true,
    proxy: {
      '/api': 'http://localhost:8080',
      '/media': 'http://localhost:8080',
    },
  },
});
