/**
 * BLUEFM — webApi: the SAME Express API, running as a Cloud Function.
 *
 * Why this file exists
 * --------------------
 * The client (client/src) talks to /api/*. Rather than rewriting the frontend
 * to httpsCallable (which would change the UI's data layer for no user-visible
 * gain), the exact same Express routes are served from Cloud Functions:
 *
 *   bluefm.qzz.io/api/*  ──(Vercel rewrite)──>  webApi (Cloud Run/Gen2)
 *                                                  │
 *                                        Express app (server/)
 *                                                  │
 *                                  Firestore (durable) + in-memory mirror
 *
 * The frontend therefore needs ZERO changes, and the local `npm start` keeps
 * working (file driver).
 *
 * AUTH BRIDGE
 * -----------
 * The UI signs in with email+password and gets an HttpOnly session cookie
 * (unchanged from the local build). On Firebase, the auth route ALSO returns a
 * Firebase custom token and the client can exchange it for an ID token with
 * `signInWithCustomToken` (see client/src/lib/firebase.js). From then on the
 * cookie is the session, and Firebase Auth is the identity store — so the admin
 * console, password reset mails and future Google sign-in all keep working.
 */
import express from 'express';
import { onRequest } from 'firebase-functions/v2/https';
import { defineSecret } from 'firebase-functions/params';
import { logger } from 'firebase-functions/logger';

/* Secrets live in Secret Manager, never in the bundle. */
const S = {
  SESSION_SECRET: defineSecret('SESSION_SECRET'),
  AUDIO_SIGNING_SECRET: defineSecret('AUDIO_SIGNING_SECRET'),
  STREAM_TOKEN_SECRET: defineSecret('STREAM_TOKEN_SECRET'),
  CASHFREE_CLIENT_ID: defineSecret('CASHFREE_CLIENT_ID'),
  CASHFREE_CLIENT_SECRET: defineSecret('CASHFREE_CLIENT_SECRET'),
  CASHFREE_ENV: defineSecret('CASHFREE_ENV'),
  B2_KEY_ID: defineSecret('B2_KEY_ID'),
  B2_APP_KEY: defineSecret('B2_APP_KEY'),
  B2_BUCKET_ID: defineSecret('B2_BUCKET_ID'),
  ADMIN_PASSWORD: defineSecret('ADMIN_PASSWORD'),
};

const PARAMS = Object.values(S);
const REGION = process.env.FUNCTIONS_REGION || 'asia-south1';

let appPromise = null;

/** Secrets are injected into process.env once per instance before first use. */
function applySecrets() {
  for (const [name, param] of Object.entries(S)) {
    try {
      const v = param.value();
      if (v) process.env[name] = v;
    } catch {
      /* not bound yet (local emulator) — env stays as-is */
    }
  }
}

async function buildApp() {
  // Must be set BEFORE the server modules are imported: config.js reads env at
  // module load, and db.js picks its driver from DB_DRIVER.
  applySecrets();
  process.env.DB_DRIVER = 'firestore';
  process.env.AUTH_MODE = process.env.AUTH_MODE || 'local';
  process.env.NODE_ENV = process.env.NODE_ENV || 'production';
  process.env.PAYMENT_PROVIDER = process.env.PAYMENT_PROVIDER || 'cashfree';
  process.env.AUDIO_STORAGE = process.env.AUDIO_STORAGE || 'b2';
  process.env.DATA_DIR = process.env.DATA_DIR || '/tmp/bluefm';
  // Vercel frontend + Cloud Functions API are different sites to the browser.
  // Without this the session cookie is rejected right after login.
  process.env.COOKIE_SAMESITE = process.env.COOKIE_SAMESITE || 'none';
  process.env.ALLOWED_ORIGINS = process.env.ALLOWED_ORIGINS || 'https://bluefm.qzz.io';

  const { createApp } = await import('../server/app.js');
  const { initDb } = await import('../server/db.js');

  const init = await initDb();
  logger.info('bluefm webApi ready', init);

  return createApp();
}

function getApp() {
  if (!appPromise) appPromise = buildApp();
  return appPromise;
}

export const webApi = onRequest(
  {
    region: REGION,
    // Gen2 HTTPS functions default to PRIVATE (Cloud Run IAM). The website
    // (Vercel) and browsers call this API without a Google identity, so it must
    // be publicly invokable. Auth is enforced inside Express (session cookie),
    // not by Cloud Run IAM. Without this every /api/* returns 403.
    invoker: 'public',
    secrets: PARAMS,
    memory: '512MiB',
    timeoutSeconds: 120,
    // Audio is served from B2/Cloudflare, never through this function, so the
    // payloads are small JSON. 10MB is plenty for admin cover uploads.
    concurrency: 80,
  },
  async (req, res) => {
    // Mounting on "/" means Express sees the FULL path including the function
    // name. Strip it so the same routes work locally and in the cloud.
    if (req.url.startsWith('/webApi')) req.url = req.url.slice('/webApi'.length) || '/';

    try {
      const app = await getApp();
      return app(req, res);
    } catch (err) {
      logger.error('webApi boot failed', err);
      if (!res.headersSent) {
        res.status(500).json({ error: 'Service unavailable', code: 'boot_failed' });
      }
    }
  },
);
