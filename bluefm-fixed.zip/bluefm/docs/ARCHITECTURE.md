# BLUEFM — Architecture

## 1. Phase 1: existing-system audit (honest version)

The brief asks for an audit of the existing BLUEFM repository, Firebase project, B2 bucket and
payment merchant account before changing anything. **That access was not available** in this
environment (no repository, no service-account JSON, no storage keys, no merchant credentials).
Per the brief's own instruction — *"If repository access is unavailable, request the necessary
source files and configuration details instead of inventing existing infrastructure"* — nothing
about your production system is assumed or modified.

What was done instead: the whole product is built behind **explicit adapter boundaries** so it can
be attached to your infrastructure without a rewrite and **without touching existing production
collections**.

### What I need from you to complete the integration

| Need | Why | Where it plugs in |
| --- | --- | --- |
| Repo URL / archive | confirm current stack & reuse components | replaces `client/` shell |
| Firebase project id + service-account JSON | Auth reuse, Firestore for new collections | `server/db.js` table adapter |
| Confirm Firestore rules file(s) | add new-collection rules without breaking APK/site | `docs/DEPLOYMENT.md §5` |
| B2 bucket name + key id/app key + Cloudflare hostname | serve existing audio unchanged | `server/lib/storage.js` (planned `b2` driver) |
| Razorpay/other merchant key id + secret + webhook secret + approval for ₹1 | live payments | `server/payments/provider.js` |
| Existing collections list | avoid name collisions | `stories_web`, `purchases_web`, … prefixed |

Until then the app runs on an isolated data layer with **zero coupling** to anything production.

## 2. Stack decision

The brief's preferred direction was Next.js + Firebase. This build uses **React 19 + Vite + Express**
instead, for three concrete reasons:

1. **One deployable origin.** The audio authorisation endpoint must be a trusted server. Express
   serves both API and client on the same origin, which removes CORS entirely and lets playback
   URLs stay same-origin (no cookie/third-party issues on mobile).
2. **Payment + audio logic stays server-side by construction.** There is no way for the React
   bundle to import entitlement code — it doesn't exist there.
3. **Rendering cost.** Story pages are personalised (access status per user), so ISR/SSG would be
   cache-poisoned per user. SSR for a handful of pages adds an operational surface without benefit;
   the client bundle is 110 kB gzipped.

The data layer is a `Table` abstraction with a Firestore-shaped API (`get / set / patch / where /
find / all`), so moving to Firestore is an implementation swap, not a rewrite. See §5.

## 3. Component map

```
Browser (React 19, React Router 7, hand-written CSS design system)
   │  same-origin fetch, httpOnly session cookie
   ▼
Express (server/index.js)
   ├─ security headers, cookie parsing, body parsing (raw body kept for webhooks)
   ├─ /media/covers       public, immutable, 30d cache
   ├─ /api/auth           register / login / logout / me (+ Firebase hook)
   ├─ /api/*              catalog: home, stories, search, categories
   ├─ /api/playback       authorize → signed URL → streaming with Range
   ├─ /api/payments       checkout, verify, webhooks, sandbox simulation
   ├─ /api/me             profile, passes, purchases, history, favourites, continue
   └─ /api/admin          stats, stories, episodes, payments, users, audit
   ▼
lib/access.js  ── single source of truth for "can this user hear this episode?"
   ▼
Table adapter (server/db.js) ── JSON file store now, Firestore later
```

## 4. Critical flows

### 4.1 Playback (the security-critical path)

```
client           server                                   storage
  │  POST /api/playback/authorize {storyId, episodeId}
  │ ─────────────────────────────────────────────────────►
  │                1. session → user (httpOnly cookie)
  │                2. load entitlement(uid, storyId)
  │                3. now = serverNow(); active && expiresAt > now ?
  │                4. if not → 403 {access_locked|access_expired} + audit log
  │                5. sign {u, e, s, x=now+TTL} with AUDIO_SIGNING_SECRET
  │                6. append listening_history row
  │ ◄───── { url: /api/playback/stream/:id?t=<sig>, expiresAt }
  │
  │  GET <url> (Range: bytes=…)
  │ ─────────────────────────────────────────────────────►
  │                7. verify HMAC constant-time, check expiry
  │                8. token episode === path episode (no swapping)
  │                9. RE-CHECK entitlement (revocation/expiry wins)
  │               10. stream 206 + Content-Range, Cache-Control: private, no-store
  │ ◄────────────────────────────────────────────────────
```

Properties: the browser never sees a durable audio path; a leaked URL dies in 10 minutes; a token
is bound to one user + one episode; expiry is evaluated at request time, so a long-lived session
cannot outlive a pass.

### 4.2 Purchase → entitlement

```
POST /api/payments/checkout            → provider order created, purchase row status=created
                                          (NO access granted here)
provider checkout (sandbox UI | Razorpay Checkout JS)
POST /api/payments/verify (client)     → signature verified server-side
POST /api/payments/webhooks/:provider  → raw-body HMAC verified in constant time
        both funnel into services/payments.js settlePurchase()
           • if purchase.status === 'paid' → no-op (idempotent)
           • renewal extends from current expiry ONLY if a different purchase is active
           • writes entitlement { plan, startsAt, expiresAt, status: active }
           • writes audit_log
```

Failure paths: `payment.failed` → `status=failed`; user cancels → `cancelled`;
`refund.processed` → `refunded` **and** entitlement `revoked` (access is not a free ride).

### 4.3 Access model

- One entitlement document per `(user, story)`, mirroring `users/{uid}/storyAccess/{storyId}`.
- `purchases` is append-only and never overwritten by another story's purchase.
- Expiry is never computed on the client. The server returns `expiresAt` and the UI renders a
  countdown for display only; the decision always comes from `checkStoryAccess()`.
- Expired rows are lazily flipped to `status=expired` on read, so the admin dashboard is accurate
  without a scheduled job. (A Cloud Function/cron can do this proactively in production.)

## 5. Firestore migration plan (no production change)

1. Implement `makeFirestoreTable(collection)` exposing the same six methods used by routes.
2. Use **new, prefixed collections**: `stories_web`, `episodes_web`, `purchases_web`,
   `story_entitlements`, `listening_progress`, `listening_history`, `favorites`, `audit_logs`.
3. `server/lib/access.js` reads `story_entitlements` — it never reads existing collections.
4. Add Firestore rules for the new collections only (see `docs/DEPLOYMENT.md §5`). Audio stays
   server-proxied or CDN-signed, so rules are a defence-in-depth layer, not the primary gate.
5. Backfill stories by exporting your existing metadata into `stories_web` (read-only access to
   the old collection is enough — no writes).

## 6. Authentication

Email + password is fully implemented with `scrypt` hashes (64-byte key, per-user salt,
`timingSafeEqual` comparison) and server-side sessions (httpOnly, SameSite=Lax, `Secure` in
production, 30-day expiry, revocable).

`POST /api/auth/firebase` is the integration point for Google/phone. It returns **501 with the exact
env list** when Firebase is not configured rather than issuing a session from an unverified token.
With Firebase configured, the flow is: client `signInWithPopup`/`signInWithPhoneNumber` → ID token
→ server `verifyIdToken` → upsert `users` by `firebaseUid` → mint BLUEFM session. **Existing BLUEFM
accounts are reused by email, but no paid entitlement is ever granted by logging in.**

## 7. Audio storage & delivery

- Now: files under `data/media/audio`, served **only** through `/api/playback/stream` with Range
  support (verified 206 + `Content-Range`).
- Existing infrastructure: set `AUDIO_STORAGE=b2` and `AUDIO_PUBLIC_BASE=https://cdn…`. The
  authorise endpoint then returns a **B2/Cloudflare signed URL with a short TTL** instead of a
  local path; re-uploading existing audio is not required (`audioKey` already matches your object
  names). See `docs/DEPLOYMENT.md §6`.
- Covers are public marketing assets (immutable, 30-day cache, WebP, ≤60 kB each, plus a 16px LQIP
  inlined in API responses to prevent layout shift).

## 8. Performance

- One `/api/home` call instead of 8 waterfalls on 3G-class networks.
- Images: `loading="lazy"` below the fold, `fetchpriority="high"` for the hero, explicit
  width/height (no CLS), LQIP background.
- Response payloads are shaped per view (no leaking internal fields).
- Client bundle 110 kB gzipped; CSS 8 kB gzipped; **zero UI framework dependencies**.
- Debounced search, abortable requests, tiny in-memory cache for back-navigation.
