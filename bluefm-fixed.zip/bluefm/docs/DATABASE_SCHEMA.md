# BLUEFM — Database schema

Implemented on a Firestore-shaped adapter (`server/db.js`). Each collection below maps 1:1 to a
Firestore collection with the same field names; document ids are shown as `id`.

## users
| field | type | notes |
| --- | --- | --- |
| id | string | uid (`u_…`) |
| email | string | lowercased, unique (indexed) |
| name | string | 2–60 chars |
| passwordHash | string | `scrypt$salt$hash` — never leaves the server |
| role | `user` \| `admin` | **server-assigned only**; never accepted from a request body |
| firebaseUid | string \| null | set when Firebase Auth is linked |
| phone | string \| null | after phone verification |
| avatarColor | string | deterministic avatar tint |
| createdAt / lastActiveAt | ISO string | |

## sessions
`id`, `userId`, `createdAt`, `expiresAt`. Sessions are server-side so logout and admin revocation
are real; the cookie contains only `{sid, uid, exp}` signed with HMAC-SHA256.

## stories  (seed: 10)
| field | type | notes |
| --- | --- | --- |
| id / slug | string | stable identifiers |
| title, author, narrator, tagline, synopsis, description | string | |
| genre | string[] | category ids |
| tags | string[] | free-form discovery tags |
| language | string | e.g. `Hindi + English` |
| coverKey, lqip | string | cover asset + 16px inline placeholder |
| rating, plays | number | |
| featuredRank | number | 0 = not featured, 1..n = hero carousel order |
| trending, isNew | boolean | badges + filters |
| episodeCount, totalDuration | number | denormalised, maintained by admin writes |
| publishedAt, status, createdAt, updatedAt | | `published` \| `draft` |

Indexes: `status`, `slug` (unique), `featuredRank`, `publishedAt`.

## episodes  (seed: 67)
`id`, `storyId` (indexed), `number`, `title`, `description`, `audioKey`, `duration` (seconds, from
ffprobe), `bytes`, `narrator`, `publishedAt`, `status`, `createdAt`.
Ordered by `(storyId, number)`. The audio key is **never** returned to a client.

## purchases  (append-only ledger)
| field | notes |
| --- | --- |
| id | `pur_…` |
| userId, storyId | indexed |
| plan | `daily` \| `weekly` \| `monthly` |
| amount | integer **paise** (₹1 = 100) — no floats in money |
| currency | `INR` |
| status | `created` \| `paid` \| `failed` \| `cancelled` \| `refunded` |
| provider | `sandbox` \| `razorpay` |
| providerOrderId, providerPaymentId | gateway references |
| signatureVerified, webhookVerified | which verification path succeeded |
| createdAt, paidAt, verifiedAt, updatedAt, failureReason | |
| testAccelerated | true only for sandbox demo compression |

Never stores card/UPI data.

## entitlements  (`story_entitlements`, one doc per user+story)
Document id: `ent_{userId}_{storyId}` — equivalent to `users/{uid}/storyAccess/{storyId}`.

| field | notes |
| --- | --- |
| userId, storyId | |
| purchaseId | the purchase that last granted time |
| plan, amount, currency | |
| startsAt, expiresAt | **server timestamps only** |
| status | `active` \| `expired` \| `revoked` |
| renewalCount | increments only on genuine renewals |
| lastVerifiedAt | last successful access check |
| createdAt, updatedAt | |

**Renewal policy (deterministic):** if the current entitlement is active *and* was granted by a
different purchase, the new window starts at the existing `expiresAt` (paid time is never lost).
Otherwise it starts now. Replaying the same purchase never adds time.

## progress  (`listening_progress`)
`id = {userId}_{episodeId}`, `userId` (indexed), `storyId`, `episodeId`, `position` (s, clamped to
duration), `duration`, `completed`, `updatedAt`. Indexes: `(userId, updatedAt)`.

## history  (`listening_history`)
Append-only: `id`, `userId`, `storyId`, `episodeId`, `playedSeconds`, `at`. Drives "Recently
played" and the admin listen metrics.

## favorites
`id = fav_{userId}_{storyId}`, `userId`, `storyId`, `createdAt`.

## categories
`id`, `name`, `icon`. Counts are computed at read time so they can never drift.

## audit_logs
`id`, `actorId`, `actorEmail`, `action` (`auth.login`, `entitlement.granted`,
`payment.signature_rejected`, `webhook.rejected`, `story.created`, …), `target`, `meta`, `at`.
Admin actions, entitlement grants and rejected signatures are all recorded.

## webhook_events
`id` (provider event id — the idempotency key), `type`, `orderId`, `paymentId`, `receivedAt`,
`processedAt`, `result` (`entitlement_granted`, `duplicate_noop`, `marked_failed`,
`refund_revoked`, `error: …`).

## relationships

```
users 1─n purchases n─1 stories
users 1─1 entitlements n─1 stories      (unique per pair)
users 1─n progress  n─1 episodes n─1 stories
users 1─n history   n─1 episodes
users 1─n favorites n─1 stories
purchases 1─0..1 entitlements (purchaseId)
webhook_events → purchases (via providerOrderId)
```

## Read/write discipline
- Episode lists are paginated implicitly (story pages) and never load audio metadata.
- `episodeCount` / `totalDuration` are denormalised because they are read on every card and
  recomputed on every admin write — no drift.
- Analytics use `history` + `purchases`, never a mutable counter that can be double-counted.
