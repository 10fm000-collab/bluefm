# BLUEFM — Security model

Principles: **the client is never trusted**, **money gates access only after server verification**,
and **every playback request is authorised afresh**.

## Threat → control

| # | Threat | Control | Verified by |
| --- | --- | --- | --- |
| 1 | Client fakes payment success | `/api/payments/verify` recomputes the HMAC over `orderId|paymentId` with the provider secret; a forged signature is rejected and the purchase marked `failed` + audit row | test 7 |
| 2 | Replayed webhook grants free access | Raw-body HMAC in constant time; `webhook_events` keyed by provider event id; `settlePurchase` is a no-op when `status === 'paid'` | test 9, 16 |
| 3 | Double-granting time on retries | Renewal extends only when the live entitlement came from a **different** purchase id | test 9 |
| 4 | Sharing a direct audio URL | Audio is not on a static path. Authorise → short-lived (default 600 s) HMAC token bound to `{user, episode, story, expiry}`; stream endpoint re-verifies the token **and** re-checks the entitlement at request time | test 8, 11 |
| 5 | Token reuse across episodes | Stream endpoint requires token episode == path episode | test 11 |
| 6 | Access after expiry | `checkStoryAccess()` uses `serverNow()` on every call; expired rows are flipped to `expired` on read | test 5, 8 |
| 7 | Buying story A unlocks story B | One entitlement per `(user, story)`; nothing global is ever set | test 10 |
| 8 | Refund kept alive as free access | `refund.processed` sets purchase `refunded` **and** entitlement `revoked` | — (logic path) |
| 9 | Privilege escalation to admin | `role` is server-assigned; `requireAdmin` reads the user document from the session, never a header/body/param | test 13, 14 |
| 10 | Session forgery / theft | HMAC-signed httpOnly cookie, `SameSite=Lax`, `Secure` in production, server-side session row with expiry and revocation | test 12, 17 |
| 11 | Credential stuffing | scrypt hashing, constant-time compare, uniform error message, token-bucket rate limit on `/auth/login` (10/min/IP) | — |
| 12 | Enumeration of accounts | Register returns 409 only on signup (standard UX trade-off, rate-limited); login never reveals existence | — |
| 13 | Stored XSS via admin content | React escapes all interpolation; no `dangerouslySetInnerHTML` anywhere; CSP-friendly, no inline event handlers | code review |
| 14 | Clickjacking / sniffing | `X-Frame-Options: SAMEORIGIN`, `X-Content-Type-Options: nosniff`, `Referrer-Policy`, `Permissions-Policy` | headers |
| 15 | Cache-based bypass of expiry | Audio responses `Cache-Control: private, no-store`; the service worker **never** intercepts `/api/*` | test 8 + `public/sw.js` |
| 16 | Progress writes as a probe | Progress requires an active entitlement for that story and clamps position to duration | test 15 |
| 17 | Secrets leaking to the browser | Secrets live in server env; the bundle contains only public config; the session token never appears in `localStorage` | — |
| 18 | Admin endpoints abused by a signed-in user | Every `/api/admin/*` route is behind `requireAdmin` **and** rate-limited | test 13 |

## Money handling
- Amounts are **integer paise** end-to-end (₹1 = 100). Prices come from the server config, never
  from the request.
- The client cannot specify an amount; `/checkout` accepts only `{storyId, plan}`.
- Orders, payments, signatures, webhook deliveries, and expiry are all persisted so a dispute can
  be reconstructed.
- No card / UPI / bank data ever touches this app or its database.

## Logging
`audit_logs` records authentication, entitlement grants, rejected signatures, rejected webhooks and
admin mutations. Logs contain ids and reasons — never tokens, secrets, or password material.

## PWA safety
Static assets are cached; covers use stale-while-revalidate; **audio and all `/api/*` traffic are
network-only**, so offline caching can never outlive an entitlement.

## Known gaps / before going live
1. **CSP is not set** by the Express layer (a strict policy needs the final font/CDN list). Add it
   at the CDN/host layer once `AUDIO_PUBLIC_BASE` is decided.
2. **Rate limiting is in-process**; move the bucket to Redis/Firestore for multi-instance deploys.
3. **Webhook IP allow-listing** for Razorpay should be added at the edge in addition to signatures.
4. **Email verification / password reset** are not implemented (they need a transactional email
   provider) — currently accounts are usable immediately.
5. `POST /api/auth/firebase` intentionally returns 501 until Firebase Admin credentials exist.
