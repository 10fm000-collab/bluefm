# BLUEFM — Testing report

Date: 2026-11-04 · Build: `dist/client` (110 kB gz JS, 7.9 kB gz CSS) · Runtime: Node 20.20.2

## A. Automated suite — 17/17 passing

`BASE=http://localhost:8099 node --test test/` against an isolated `DATA_DIR` so no demo data is
mutated.

| # | Spec requirement | Test | Result |
| --- | --- | --- | --- |
| 1 | New user registration (+ validation) | weak password → 400; duplicate email → 409 | PASS |
| 2 | Existing user login | wrong password → 401 | PASS |
| 3 | Story browsing / search | `?q=metro` returns real matches from the DB | PASS |
| 4 | Auth required for playback | anonymous `authorize` → 401 | PASS |
| 5 | Locked story blocked | active access required → 403 `access_locked` | PASS |
| 6 | **Failed payment** | simulate failure → playback still 403, story still `locked` | PASS |
| 7 | Forged payment signature | verify → 400 `signature_invalid`, no access | PASS |
| 8 | Daily purchase = 24 h + playback | expiry within ±60 s of 24 h; range request → 206 `audio/mpeg`, `private, no-store` | PASS |
| 9 | **Duplicate webhook / retried verify** | second verify → `duplicate: true`, expiry unchanged (no stacked time) | PASS |
| 10 | **Independent entitlements** | pass for story A → story B still 403 | PASS |
| 11 | Unauthorised audio URL | no token → 403; token from ep 1 on ep 2 → 403 | PASS |
| 12 | Tampered session cookie | `/auth/me` → `user: null` | PASS |
| 13 | **Admin authorisation** | all 5 admin endpoints → 403 for a normal user | PASS |
| 14 | Admin access works | stats + payments readable by admin | PASS |
| 15 | Progress validation | position clamped to duration; unknown story → 404 | PASS |
| 16 | Webhook authenticity | unsigned POST → 400 | PASS |
| 17 | Logout | session invalidated immediately | PASS |

Reproduce:

```bash
DATA_DIR=/tmp/bluefm-test PORT=8099 node server/seed.js --reset
DATA_DIR=/tmp/bluefm-test PORT=8099 node server/index.js &
BASE=http://localhost:8099 node --test test/
```

## B. Browser (headless Chromium, Android Pixel 7 profile, DPR 2)

| Check | Result |
| --- | --- |
| Home renders, 28 story cards, **0 console/page errors** | PASS |
| Category counts (`Drama 6 stories`) after fix | PASS |
| Locked state no longer blurs artwork (regression found & fixed) | PASS |
| Sign-in with demo account → redirect to intended page | PASS |
| Purchase sheet: plan select → ₹7 weekly → sandbox checkout → **Access granted until 11 Nov 2026 (6d 23h left)** | PASS |
| Player opens, audio position advances 0:02 → 0:04 → 0:05 while playing | PASS |
| Speed toggle 1× → 1.25× applied to the audio element | PASS |
| Next episode switches to "The Letter He Never Sent" | PASS |
| Seek to 65% moves position and time label | PASS |
| Minimise → mini player visible, playback continues | PASS |
| Story page shows locked banner + all 7 episodes browsable | PASS |
| No horizontal overflow at 390 px | PASS |

### Screenshots
`shots/v2-home.png`, `v2-signin.png`, `v2-story-locked.png`, `v3-plans.png`, `v3-checkout.png`,
`v3-success.png`, `v3-player.png`, `v3-player-next.png`, `v3-mini.png`.

## C. Timing / performance observations

| Metric | Value |
| --- | --- |
| `/api/home` payload | 48 kB (one request instead of 8 waterfalls) |
| Cover images | 60 kB WebP @600×900 + 16 px inline LQIP |
| Client bundle | 374 kB raw / **110 kB gzip** |
| CSS | 35 kB raw / 7.9 kB gzip |
| Fonts | Google Fonts, `display=swap`, preconnect (self-host for strict CSP) |
| Audio seek | HTTP Range → 206, first byte in <10 ms locally |

## D. Defects found and fixed during testing

1. **Renewal double-grant** — a retried verification for the same purchase extended access (48 h for
   a 24 h pass). Fixed: extension only applies when the active entitlement came from a *different*
   purchase. Covered by test 9.
2. **Category counts showed "0 stories"** — `/api/home` shipped categories without counts while
   `/api/categories` computed them. Both now use one `categoriesWithCounts()` helper.
3. **Blurred cover art** — the full-card lock overlay used `backdrop-filter`, blurring the entire
   artwork on mobile. Replaced with a corner lock chip.
4. **Hero layout** — action buttons wrapped awkwardly and collided with carousel dots; dots moved to
   the top-right, actions kept on one line.
5. **Progress loss on navigation** — positions under 8 s could be lost because the sync was
   throttled. Added `pagehide` / `visibilitychange` / `close()` flushes and reduced the throttle to 5 s.
6. **Seeded pass invisible to the access layer** — `seed.js` wrote the demo entitlement under
   `ent_demo_last_metro` while `lib/access.js` looks up `ent_{userId}_{storyId}`. The demo user's
   paid pass was silently ignored (correctly denied, but wrong behaviour for seeded data). The seed
   now derives the id from `entitlementId()`; verified `/api/stories/last-metro` returns
   `access.status=active` and `authorize` returns 200, while a different story still returns 403.
7. **Audio path hardening** — a request directly to `/media/audio/…` fell through the SPA fallback
   returning `index.html` (200). Now an explicit `403 direct_audio_forbidden` route guarantees no
   path-based audio delivery even if `DATA_DIR` were misconfigured.
8. **Trending rail undersized on desktop** — the 6-column grid only received 4 stories because the
   filter was strictly `trending === true`. Now ranks flagged titles first and tops up with the
   most-played series, so rails are always full.

## E. Not tested (requires external configuration)

| Item | Blocker |
| --- | --- |
| Real ₹1 Razorpay capture | merchant live keys + a real card/UPI |
| Google / phone sign-in | Firebase project + enabled providers |
| B2/Cloudflare signed delivery | bucket keys + CDN hostname |
| iOS Safari background audio | requires a physical device; Media Session handlers are wired |
| Load/concurrency | single-instance JSON store; needs Firestore + Redis for a real load test |

## Phase 2 — real backend suite

`npm test` = `test/api.test.js` (17) + `test/cashfree.test.js` (7).

```bash
BASE=http://localhost:8080 node --test test/api.test.js     # 17/17
node --test test/cashfree.test.js                            # 7/7
```

`test/cashfree.test.js` spins up a **mock Cashfree Orders API** and runs the real
provider code end-to-end:

| # | Assertion |
|---|-----------|
| C1 | plans report ₹2 / ₹14 / ₹60 |
| C2 | order create sends **rupees** (₹14, not 1400 paise) + phone |
| C3 | unpaid order → no access (403) |
| C4 | `order_status=PAID` → pass granted, expiry ≈168 h |
| C5 | replaying verify → expiry unchanged (idempotent) |
| C6 | forged webhook → 400; signed Cashfree webhook → access granted; duplicate event id inert |
| C7 | buying one story still does not unlock another |

Backblaze B2 verified manually (live credentials):

```
create bucket bluefm-web-audio (allPrivate)        ✔
upload 67 audio files                              ✔
signed URL range GET  → 206 audio/mpeg, MP3 bytes  ✔
unsigned access       → 401                         ✔
server authorize      → delivery: "b2"              ✔
```

When `AUDIO_STORAGE=b2`, tests 8 and 11 switch to the storage path automatically
(they assert either proxy or signed-URL delivery).

### Cloudflare streaming worker (`test/worker.test.mjs`)

```bash
node test/worker.test.mjs     # 8/8
```

| # | Assertion |
|---|-----------|
| W1 | token nahi → 403 |
| W2 | signature forge → 403 |
| W3 | expired token → 403 |
| W4 | doosre episode ka token → 403 |
| W5 | valid → 200 MISS, dobara → 200 **HIT, B2 hit count 1** |
| W6 | Range → 206 `content-range` edge cache se, origin trip 0 |
| W7 | B2 ko worker ka apna bucket token jaata hai, user ka `?t=` kabhi nahi |
| W8 | path traversal → 400 |

**Total: 17 (API) + 7 (Cashfree) + 8 (Cloudflare) = 32/32**
