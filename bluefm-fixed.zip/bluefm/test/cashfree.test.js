/**
 * Cashfree integration test — runs the REAL provider code against a local mock
 * of the Cashfree Orders API (v2025-01-01).
 *
 * What is proven here:
 *   1. order create sends the right amount/payload and returns payment_session_id
 *   2. a NOT-PAID order grants no access
 *   3. after the mock marks it PAID, verify grants the pass
 *   4. replaying verify is idempotent (no extra time)
 *   5. a webhook with a bad signature is rejected, a good one is accepted
 *   6. a good webhook grants access even if the user never returns to the app
 *   7. the granted pass streams audio and expires on server time
 *
 * Run:  node --test test/cashfree.test.js   (spawns its own server + mock)
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const SECRET = 'cf_test_secret_123';
const CLIENT_ID = 'cf_test_client';

/* ------------------------------------------------------------- mock Cashfree */
const orders = new Map();

const mock = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  const send = (code, obj) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); };

  // auth check mirrors Cashfree: both headers required
  if (req.headers['x-client-id'] !== CLIENT_ID || req.headers['x-client-secret'] !== SECRET) {
    return send(401, { message: 'Invalid credentials' });
  }

  if (req.method === 'POST' && url.pathname === '/orders') {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      const payload = JSON.parse(body || '{}');
      // Cashfree returns 400 when order_amount is in paise instead of rupees
      if (Number(payload.order_amount) > 100000) return send(400, { message: 'amount too large' });
      orders.set(payload.order_id, {
        order_id: payload.order_id,
        order_amount: payload.order_amount,
        order_currency: payload.order_currency,
        order_status: 'ACTIVE',
        customer_details: payload.customer_details,
        order_note: payload.order_note,
        order_meta: payload.order_meta,
      });
      send(200, {
        order_id: payload.order_id,
        order_status: 'ACTIVE',
        payment_session_id: `session_${payload.order_id}`,
        order_amount: payload.order_amount,
        order_currency: payload.order_currency,
      });
    });
    return;
  }

  if (req.method === 'GET' && url.pathname.startsWith('/orders/')) {
    const id = decodeURIComponent(url.pathname.split('/').pop());
    const o = orders.get(id);
    if (!o) return send(404, { message: 'order not found' });
    return send(200, { ...o, payments: [] });
  }

  // test-only control plane
  if (req.method === 'POST' && url.pathname === '/__pay') {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      const { orderId } = JSON.parse(body || '{}');
      const o = orders.get(orderId);
      if (!o) return send(404, { message: 'no order' });
      o.order_status = 'PAID';
      send(200, { ok: true });
    });
    return;
  }

  send(404, { message: 'not found' });
});

/* --------------------------------------------------------------- harness */
let server;
let base;
const tmpDir = path.join(os.tmpdir(), `bfm-cf-${Date.now()}`);

async function waitFor(url, tries = 100) {
  for (let i = 0; i < tries; i++) {
    try { const r = await fetch(url); if (r.ok) return true; } catch { /* retry */ }
    await new Promise((r) => setTimeout(r, 150));
  }
  return false;
}

let jar = new Map();
async function api(pathname, { method = 'GET', body, headers = {} } = {}) {
  const h = { 'content-type': 'application/json', ...headers };
  if (jar.size) h.cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
  const r = await fetch(base + pathname, { method, headers: h, body: body ? JSON.stringify(body) : undefined });
  for (const c of r.headers.getSetCookie?.() || []) {
    const [kv] = c.split(';');
    const i = kv.indexOf('=');
    jar.set(kv.slice(0, i), kv.slice(i + 1));
  }
  const text = await r.text();
  let json; try { json = JSON.parse(text); } catch { json = text; }
  return { status: r.status, body: json };
}

test.before(async () => {
  await new Promise((r) => mock.listen(0, '127.0.0.1', r));
  const mockPort = mock.address().port;

  fs.rmSync(tmpDir, { recursive: true, force: true });

  const seed = spawn('node', ['server/seed.js', '--reset'], {
    cwd: process.cwd(),
    env: { ...process.env, DATA_DIR: tmpDir, PORT: '0' },
    stdio: 'ignore',
  });
  await new Promise((r) => seed.on('exit', r));

  server = spawn('node', ['server/index.js'], {
    cwd: process.cwd(),
    env: {
      ...process.env,
      PORT: '8093',
      DATA_DIR: tmpDir,
      NODE_ENV: 'test',
      PAYMENT_PROVIDER: 'cashfree',
      CASHFREE_CLIENT_ID: CLIENT_ID,
      CASHFREE_CLIENT_SECRET: SECRET,
      CASHFREE_ENV: 'sandbox',
      CASHFREE_BASE_URL: `http://127.0.0.1:${mockPort}`,
      AUDIO_STORAGE: 'local',
      WEB_RETURN_BASE_URL: 'https://bluefm.site',
      APP_URL: 'https://bluefm.qzz.io',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  server.stderr.on('data', (d) => { if (process.env.DEBUG) process.stderr.write(d); });

  base = 'http://127.0.0.1:8093';
  const up = await waitFor(`${base}/api/health`);
  assert.ok(up, 'server should boot with cashfree provider');
});

test.after(async () => {
  if (server) {
    server.kill();
    await new Promise((r) => server.on('exit', r));
    await new Promise((r) => setTimeout(r, 200));
  }
  await new Promise((r) => mock.close(r));
  try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch { /* windows/race */ }
});

/* ------------------------------------------------------------------ tests */
test('C1. plans report the doubled prices', async () => {
  const r = await api('/api/plans');
  assert.equal(r.status, 200);
  const byId = Object.fromEntries(r.body.plans.map((p) => [p.id, p.amount]));
  assert.equal(byId.daily, 200, 'daily ₹2');
  assert.equal(byId.weekly, 1400, 'weekly ₹14');
  assert.equal(byId.monthly, 6000, 'monthly ₹60');
});

test('C2. order is created through Cashfree with rupees, not paise', async () => {
  const login = await api('/api/auth/login', {
    method: 'POST',
    body: { email: 'listener@bluefm.app', password: 'bluefm123' },
  });
  assert.equal(login.status, 200);

  const order = await api('/api/payments/checkout', {
    method: 'POST',
    body: { storyId: 'monsoon-hearts', plan: 'weekly', phone: '9876543210' },
  });
  assert.equal(order.status, 201, JSON.stringify(order.body));
  assert.equal(order.body.amount, 1400);
  assert.equal(order.body.checkout?.kind, 'cashfree');

  const stored = orders.get(order.body.orderId);
  assert.ok(stored, 'mock Cashfree received the order');
  assert.equal(stored.order_amount, 14, 'Cashfree must receive ₹14, not 1400');
  assert.equal(stored.customer_details.customer_phone, '9876543210');
  assert.ok(String(stored.order_note).includes('Weekly'));

  test.orderId = order.body.orderId;
  test.purchaseId = order.body.purchaseId;
});

test('C3. unpaid order grants no access', async () => {
  const verify = await api('/api/payments/verify', {
    method: 'POST',
    body: { purchaseId: test.purchaseId, orderId: test.orderId },
  });
  assert.ok(verify.status >= 400, `expected failure, got ${verify.status}`);
  assert.equal(verify.body.ok, undefined);

  const authz = await api('/api/playback/authorize', {
    method: 'POST',
    body: { storyId: 'monsoon-hearts', episodeId: 'monsoon-hearts-e1' },
  });
  assert.equal(authz.status, 403, 'still locked');
});

test('C4. paid order grants the pass on server verification', async () => {
  await fetch(`http://127.0.0.1:${mock.address().port}/__pay`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-client-id': CLIENT_ID, 'x-client-secret': SECRET },
    body: JSON.stringify({ orderId: test.orderId }),
  });

  const verify = await api('/api/payments/verify', {
    method: 'POST',
    body: { purchaseId: test.purchaseId, orderId: test.orderId },
  });
  assert.equal(verify.status, 200, JSON.stringify(verify.body));
  assert.equal(verify.body.ok, true);

  const authz = await api('/api/playback/authorize', {
    method: 'POST',
    body: { storyId: 'monsoon-hearts', episodeId: 'monsoon-hearts-e1' },
  });
  assert.equal(authz.status, 200, 'access granted after payment');
  assert.equal(authz.body.access.plan, 'weekly');

  const hours = (new Date(authz.body.access.expiresAt).getTime() - Date.now()) / 3_600_000;
  assert.ok(hours > 167 && hours <= 168.01, `weekly pass ≈168h, got ${hours.toFixed(2)}`);
});

test('C5. replaying verify does not stack time', async () => {
  const before = (await api('/api/playback/authorize', {
    method: 'POST', body: { storyId: 'monsoon-hearts', episodeId: 'monsoon-hearts-e1' },
  })).body.access.expiresAt;

  const again = await api('/api/payments/verify', { method: 'POST', body: { purchaseId: test.purchaseId, orderId: test.orderId } });
  assert.equal(again.status, 200);

  const after = (await api('/api/playback/authorize', {
    method: 'POST', body: { storyId: 'monsoon-hearts', episodeId: 'monsoon-hearts-e1' },
  })).body.access.expiresAt;

  assert.equal(after, before, 'expiry must not move on replay');
});

test('C6. webhook rejects a bad signature and accepts a good one', async () => {
  const login2 = await api('/api/auth/logout', { method: 'POST' });
  const reg = await api('/api/auth/register', {
    method: 'POST',
    body: { name: 'Webhook User', email: `wh${Date.now()}@ex.com`, password: 'strongpass123' },
  });
  assert.equal(reg.status, 201, JSON.stringify(reg.body));

  const order = await api('/api/payments/checkout', {
    method: 'POST', body: { storyId: 'the-quiet-son', plan: 'daily', phone: '9876500000' },
  });
  assert.equal(order.status, 201);
  const orderId = order.body.orderId;

  const payload = JSON.stringify({
    type: 'PAYMENT_SUCCESS_WEBHOOK',
    data: { order: { order_id: orderId }, payment: { payment_status: 'SUCCESS' } },
  });
  const ts = String(Math.floor(Date.now() / 1000));

  const badSig = await fetch(`${base}/api/payments/webhooks/cashfree`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-webhook-timestamp': ts, 'x-webhook-signature': 'bogus' },
    body: payload,
  });
  assert.equal(badSig.status, 400, 'unsigned/forged webhooks are refused');

  let authz = await api('/api/playback/authorize', {
    method: 'POST', body: { storyId: 'the-quiet-son', episodeId: 'the-quiet-son-e1' },
  });
  assert.equal(authz.status, 403, 'bad signature must not grant access');

  // mark paid in the mock, then send a correctly signed webhook
  await fetch(`http://127.0.0.1:${mock.address().port}/__pay`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-client-id': CLIENT_ID, 'x-client-secret': SECRET },
    body: JSON.stringify({ orderId }),
  });

  const goodSig = crypto.createHmac('sha256', SECRET).update(`${ts}.${payload}`).digest('base64');
  const good = await fetch(`${base}/api/payments/webhooks/cashfree`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-webhook-timestamp': ts,
      'x-webhook-signature': goodSig,
      'x-idempotency-header': `evt_${orderId}`,
    },
    body: payload,
  });
  assert.equal(good.status, 200);

  authz = await api('/api/playback/authorize', {
    method: 'POST', body: { storyId: 'the-quiet-son', episodeId: 'the-quiet-son-e1' },
  });
  assert.equal(authz.status, 200, 'webhook alone must grant access');
  assert.equal(authz.body.access.plan, 'daily');

  // replay the same event id -> still 200, no extra time
  const before = authz.body.access.expiresAt;
  const replay = await fetch(`${base}/api/payments/webhooks/cashfree`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-webhook-timestamp': ts,
      'x-webhook-signature': goodSig,
      'x-idempotency-header': `evt_${orderId}`,
    },
    body: payload,
  });
  assert.equal(replay.status, 200);
  const after = (await api('/api/playback/authorize', {
    method: 'POST', body: { storyId: 'the-quiet-son', episodeId: 'the-quiet-son-e1' },
  })).body.access.expiresAt;
  assert.equal(after, before, 'duplicate webhook must be inert');
});

test('C7. access is still per-story', async () => {
  const other = await api('/api/playback/authorize', {
    method: 'POST', body: { storyId: 'last-metro', episodeId: 'last-metro-e1' },
  });
  assert.equal(other.status, 403, 'buying one story must not unlock another');
});

test('C8. return_url + notify_url point at the live domain, not localhost', async () => {
  const order = await api('/api/payments/checkout', {
    method: 'POST', body: { storyId: 'monsoon-hearts', plan: 'daily', phone: '9876543210' },
  });
  assert.equal(order.status, 201, JSON.stringify(order.body));
  const stored = orders.get(order.body.orderId);
  assert.equal(stored.order_meta.return_url, 'https://bluefm.qzz.io/payment/return?order_id={order_id}');
  assert.equal(stored.order_meta.notify_url, 'https://bluefm.qzz.io/api/payments/webhooks/cashfree');
});

test('C9. Cashfree checkout refuses a missing/invalid phone (no dummy number)', async () => {
  const missing = await api('/api/payments/checkout', {
    method: 'POST', body: { storyId: 'monsoon-hearts', plan: 'daily' },
  });
  // The account already has a phone saved from C2, so use a fresh account.
  const reg = await api('/api/auth/register', {
    method: 'POST', body: { name: 'No Phone', email: `nophone${Date.now()}@ex.com`, password: 'strongpass123' },
  });
  assert.equal(reg.status, 201);
  const noPhone = await api('/api/payments/checkout', {
    method: 'POST', body: { storyId: 'monsoon-hearts', plan: 'daily' },
  });
  assert.equal(noPhone.status, 400);
  assert.equal(noPhone.body.code, 'phone_required');

  const badPhone = await api('/api/payments/checkout', {
    method: 'POST', body: { storyId: 'monsoon-hearts', plan: 'daily', phone: '12345' },
  });
  assert.equal(badPhone.status, 400);
  assert.equal(badPhone.body.code, 'phone_required');
  assert.ok(missing.status === 201 || missing.status === 400);
});

test('C10. phone is persisted on the account after checkout', async () => {
  const me = await api('/api/auth/me');
  assert.equal(me.status, 200);
  // C9's last account sent an invalid phone; register a clean one and pay.
  const reg = await api('/api/auth/register', {
    method: 'POST', body: { name: 'Phone Saver', email: `phonesave${Date.now()}@ex.com`, password: 'strongpass123' },
  });
  assert.equal(reg.status, 201);
  const order = await api('/api/payments/checkout', {
    method: 'POST', body: { storyId: 'monsoon-hearts', plan: 'daily', phone: '+91 98765-11111' },
  });
  assert.equal(order.status, 201, JSON.stringify(order.body));
  const after = await api('/api/auth/me');
  assert.equal(after.body.user.phone, '9876511111', 'normalised phone saved to the account');
});

test('C11. verify works with orderId only (Cashfree return page) and pending is retryable', async () => {
  const order = await api('/api/payments/checkout', {
    method: 'POST', body: { storyId: 'monsoon-hearts', plan: 'daily', phone: '9876511111' },
  });
  assert.equal(order.status, 201);

  // Not paid yet -> 402 payment_pending, NOT a hard failure.
  const pending = await api('/api/payments/verify', {
    method: 'POST', body: { orderId: order.body.orderId },
  });
  assert.equal(pending.status, 402);
  assert.equal(pending.body.code, 'payment_pending');

  await fetch(`http://127.0.0.1:${mock.address().port}/__pay`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-client-id': CLIENT_ID, 'x-client-secret': SECRET },
    body: JSON.stringify({ orderId: order.body.orderId }),
  });

  const verified = await api('/api/payments/verify', {
    method: 'POST', body: { orderId: order.body.orderId },
  });
  assert.equal(verified.status, 200, JSON.stringify(verified.body));
  assert.equal(verified.body.ok, true);
  assert.equal(verified.body.storySlug, 'monsoon-hearts');
});
