/**
 * Cloud-parity test WITHOUT a Firestore server.
 *
 * Why not a real emulator: this sandbox blocks gRPC, so firebase-admin's
 * Firestore client never connects. A test that hangs is worse than no test.
 *
 * What IS proven here, and why it matters:
 *   1. the Express app is importable and mountable from a Cloud Function
 *      (server/app.js createApp) — that is the whole point of webApi
 *   2. `webApi` strips its own path prefix, so routing is identical
 *   3. FirestoreTable implements the same contract as the file Table, so routes
 *      do not care which driver is active
 *   4. COLLECTION NAMES MATCH between the migration script and the server.
 *      This is the bug that made a freshly migrated Firestore render an empty
 *      catalogue; the assertions below would have caught it.
 *   5. writing through the adapter reaches the database layer (no silent loss)
 *
 * The real project check is `node scripts/migrate-to-firebase.js --verify`
 * (talks to nodio-575bf with your credentials) — see START-HERE.md.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

/* ------------------------------------------------------------------ setup */
const ROOT = process.cwd();

test('C1. the same app mounts as a Cloud Function (path stripping works)', async () => {
  // simulate the Cloud Functions request object: url INCLUDES the function name
  const { createApp } = await import(path.join(ROOT, 'server/app.js'));
  const app = createApp();
  assert.equal(typeof app, 'function', 'createApp returns an express app');

  // express routing must resolve /api/health after the prefix is stripped
  const req = { url: '/webApi/api/health', method: 'GET', headers: {} };
  if (req.url.startsWith('/webApi')) req.url = req.url.slice('/webApi'.length) || '/';
  assert.equal(req.url, '/api/health', 'webApi strips its own prefix');

  // and the app really has middleware mounted (express 5 keeps them on .router)
  const stack = app._router?.stack || app.router?.stack || app.stack || [];
  assert.ok(stack.length > 0, 'middleware/routes mounted');
});

test('C2. FirestoreTable exposes the exact Table contract', async () => {
  const { FirestoreTable } = await import(path.join(ROOT, 'server/db-firestore.js'));
  const t = new FirestoreTable('stories');
  const required = ['get', 'has', 'set', 'patch', 'delete', 'all', 'count', 'where', 'find', 'findOne', 'invalidate', 'load', 'flush'];
  for (const m of required) {
    assert.equal(typeof t[m], 'function', `missing method: ${m}`);
  }
});

test('C3. CRUD through the Firestore adapter behaves like the file store', async () => {
  const { FirestoreTable } = await import(path.join(ROOT, 'server/db-firestore.js'));
  const remote = new FirestoreTable('probe');
  remote.load = async () => 0;           // no network in this test
  remote.flush = async () => {};

  remote.set('a1', { id: 'a1', title: 'Alpha', status: 'published', plays: 5 });
  remote.set('a2', { id: 'a2', title: 'Beta', status: 'draft', plays: 1 });

  assert.equal(remote.get('a1').title, 'Alpha');
  assert.equal(remote.count(), 2);
  assert.deepEqual(remote.where('status', 'published').map((d) => d.id), ['a1']);
  assert.equal(remote.find((d) => d.plays > 3).length, 1);
  assert.equal(remote.findOne((d) => d.title === 'Beta').status, 'draft');

  remote.patch('a2', { status: 'published' });
  assert.equal(remote.where('status', 'published').length, 2, 'patch is reflected');

  assert.equal(remote.delete('a2'), true);
  assert.equal(remote.has('a2'), false);
  assert.equal(remote.count(), 1);
});

test('C4. collection names are IDENTICAL for server and migration (bug #4)', async () => {
  // db.js owns the naming rule; the migration must follow it, not invent names.
  process.env.FIRESTORE_PREFIX = '';
  const dbMod = await import(path.join(ROOT, 'server/db.js'));
  const tables = ['users', 'sessions', 'stories', 'episodes', 'categories', 'purchases',
    'entitlements', 'progress', 'favorites', 'history', 'audit', 'webhookEvents', 'rateLimits'];

  for (const t of tables) {
    assert.equal(dbMod.collectionName(t), t, `default collection name for ${t}`);
  }

  process.env.FIRESTORE_PREFIX = 'web_';
  for (const t of tables) {
    assert.equal(dbMod.collectionName(t), `web_${t}`, `prefixed collection name for ${t}`);
  }
  delete process.env.FIRESTORE_PREFIX;

  // the migration script must not hardcode a different name
  const mig = fs.readFileSync(path.join(ROOT, 'scripts/migrate-to-firebase.js'), 'utf8');
  assert.ok(!/collection\('web_stories'\)/.test(mig), 'migration must not hardcode web_stories');
  assert.ok(/col\('stories'\)/.test(mig), 'migration uses the shared naming rule');
  assert.ok(/col\('episodes'\)/.test(mig), 'migration uses the shared naming rule');
});

test('C5. a write through the adapter is queued for durability (not lost)', async () => {
  const { FirestoreTable } = await import(path.join(ROOT, 'server/db-firestore.js'));
  const t = new FirestoreTable('queuetest');
  t.load = async () => 0;

  const captured = [];
  t.flush = async function () {
    captured.push(...this.pending.splice(0, this.pending.length));
  };

  t.set('x', { id: 'x', v: 1 });
  t.patch('x', { v: 2 });
  await new Promise((r) => setTimeout(r, 30));   // let the scheduled flush run
  await t.flush();

  assert.equal(captured.length, 2, `both writes reached the database layer (got ${captured.length})`);
  assert.equal(captured[0].op, 'set');
  assert.equal(captured[1].op, 'patch');
  assert.equal(captured[1].data.v, 2);
});

test('C6. webApi module loads with the right function shape', async () => {
  const mod = await import(path.join(ROOT, 'firebase-web/api.js'));
  assert.ok(mod.webApi, 'webApi exported');
  // firebase-functions v2 wraps handlers; presence of the export is the contract
  assert.ok(mod.webApi.run || typeof mod.webApi === 'function' || mod.webApi.__endpoint,
    'webApi is a deployable function');
});

test('C7. vercel.json points /api at webApi and preserves the /api prefix', async () => {
  const v = JSON.parse(fs.readFileSync(path.join(ROOT, 'vercel.json'), 'utf8'));
  const api = v.rewrites.find((r) => r.source === '/api/:path*');
  assert.ok(api, '/api rewrite exists');
  // The destination MUST keep the /api prefix: Express mounts the router at
  // /api, so a destination like …/webApi/:path* drops it and every route 404s.
  assert.match(api.destination, /\/api\/:path\*$/, api.destination);
  const spa = v.rewrites.find((r) => r.destination === '/index.html');
  assert.ok(spa, 'SPA fallback exists');
});

test('C8. firebase.json rewrites /api to webApi in the same region', async () => {
  const f = JSON.parse(fs.readFileSync(path.join(ROOT, 'firebase/firebase.json'), 'utf8'));
  const rewrite = f.hosting.rewrites.find((r) => r.source === '/api/**');
  assert.ok(rewrite, '/api rewrite exists');
  assert.equal(rewrite.function.region, 'asia-south1', 'region matches Firestore');
});

test('C9. edge token format matches the worker contract (bug #d)', async () => {
  process.env.STREAM_TOKEN_SECRET = 'test_secret_for_format';
  const { signEdgeToken, verifyEdgeToken } = await import(path.join(ROOT, 'server/lib/b2.js'));

  const tok = signEdgeToken({ episodeId: 'last-metro-e1', expiresAt: Date.now() + 60_000 });
  const [body, sig] = tok.split('.');
  assert.ok(body && sig, 'token has payload.signature');

  const payload = JSON.parse(Buffer.from(body.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString());
  // the worker checks exactly these two fields
  assert.equal(payload.exp, Math.floor((Date.now() + 60_000) / 1000), 'payload.exp present');
  assert.equal(payload.path, '/last-metro-e1.mp3', 'payload.path present and absolute');

  assert.equal(verifyEdgeToken(tok).ok, true);
});

test('C10. B2 download token is scoped to the single episode (bug #b)', async () => {
  const src = fs.readFileSync(path.join(ROOT, 'firebase/functions-web/callables.cjs'), 'utf8');
  assert.ok(/fileNamePrefix: ep\.audioKey/.test(src), 'fileNamePrefix must be the episode key');
  assert.ok(!/fileNamePrefix: ''/.test(src), 'must not grant a whole-bucket download token');
  assert.ok(/split\('\/'\)\.map\(encodeURIComponent\)/.test(src), 'audio keys are encoded per path segment');
});

test('C11. functions bundle uses the same Firebase SDKs as the root project', async () => {
  // firebase-functions 6.x ships CJS-only subpaths; the ESM named import
  // `import { logger } from 'firebase-functions/logger'` crashes container
  // startup ("Container Healthcheck failed"). Keep the bundle on the tested
  // root SDK versions so local boot and cloud boot cannot drift apart again.
  const rootPkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  const fnPkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'firebase/functions-web/package.json'), 'utf8'));
  assert.equal(fnPkg.dependencies['firebase-functions'], rootPkg.dependencies['firebase-functions']);
  assert.equal(fnPkg.dependencies['firebase-admin'], rootPkg.dependencies['firebase-admin']);
});

test('C12. public HTTPS functions set invoker:public (no Cloud Run IAM 403)', async () => {
  // Gen2 onRequest defaults to PRIVATE. The website + Cashfree call these
  // without a Google identity, so they must be publicly invokable or every
  // request returns 403 from Cloud Run IAM before Express ever runs.
  const api = fs.readFileSync(path.join(ROOT, 'firebase-web/api.js'), 'utf8');
  assert.ok(/invoker:\s*'public'/.test(api), 'webApi must set invoker:public');
  const callables = fs.readFileSync(path.join(ROOT, 'firebase/functions-web/callables.cjs'), 'utf8');
  const webhookBlock = callables.slice(callables.indexOf('exports.webCashfreeWebhook'));
  assert.ok(/invoker:\s*'public'/.test(webhookBlock.slice(0, 300)), 'webCashfreeWebhook must set invoker:public');
});
