# BLUEFM — Cloudflare delivery + upload (B2 = storage only)

Architecture:

```
Browser ──> Cloudflare Worker (bluefm-stream)
              ├─ GET /<episodeId>.mp3?t=HMAC   → signed audio stream (edge cache)
              ├─ GET /covers/<id>.webp         → public cover images
              └─ POST /upload (Bearer HMAC)    → admin audio/cover upload → B2
                        │
                        └──> Backblaze B2 bucket (private, storage only)
```

- **Backblaze** = sirf storage.
- **Cloudflare** = delivery + upload front door.
- B2 → Cloudflare egress Bandwidth Alliance se free hai.
- Full edge cache ke liye custom domain best hai; `*.workers.dev` pe Cache API
  no-op hota hai, lekin auth + upload + B2-via-Cloudflare delivery kaam karti hai.

---

## 1) Worker deploy karo

```powershell
cd C:\Users\User\Downloads\bluefm-fixed\bluefm\cloudflare
npx wrangler login
```

Secrets set karo (hidden prompt me value paste karo, chat me nahi):

```powershell
npx wrangler secret put STREAM_TOKEN_SECRET
npx wrangler secret put B2_KEY_ID
npx wrangler secret put B2_APP_KEY
npx wrangler secret put B2_BUCKET_ID
```

`STREAM_TOKEN_SECRET` **wahi same value** honi chahiye jo Firebase secret
`STREAM_TOKEN_SECRET` me hai. B2 application key me `readFiles` + `writeFiles`
capability honi chahiye.

Deploy:

```powershell
npx wrangler deploy
```

Output me URL milega, jaise:

```
https://bluefm-stream.singhvikas21571.workers.dev
```

## 2) Firebase me delivery ON karo

Worker URL ko Firebase secret `B2_DOWNLOAD_URL` me set karo:

```powershell
cd C:\Users\User\Downloads\bluefm-fixed\bluefm
firebase functions:secrets:set B2_DOWNLOAD_URL --project nodio-575bf
```

Prompt me worker URL paste karo (example):

```
https://bluefm-stream.singhvikas21571.workers.dev
```

Backend deploy:

```powershell
npm run fb:prepare
firebase deploy --only functions:web --project nodio-575bf
```

Frontend deploy:

```powershell
npm run build
vercel --prod
```

## 3) Verify

- Admin → Stories → koi story edit karo, cover upload karo.
- Admin → Episodes → MP3 upload karo.
- App me story play karo; audio URL ab `workers.dev` (ya custom domain) honi chahiye.
- `/api/admin/media-config` me `remoteUpload: true` aana chahiye.

## 4) Custom domain (optional, full edge cache)

Agar aapke paas Cloudflare zone hai (e.g. `bluefm.site`), to Worker ko custom
domain do:

```
media.bluefm.site  →  Worker route / custom domain
```

Phir `wrangler.toml` me routes uncomment karo aur `B2_DOWNLOAD_URL` ko
`https://media.bluefm.site` par update karke backend redeploy karo.

Custom domain pe Cache API active hota hai, isliye repeated streams edge cache
se serve hote hain aur B2 origin hit kam hota hai.

## 5) Demo content hatana

Dry run:

```powershell
node scripts/clear-demo.js --project=nodio-575bf
```

Actual delete:

```powershell
node scripts/clear-demo.js --apply --project=nodio-575bf
```

Ye sirf seeded demo stories/episodes + demo listener + unka B2 audio hatata hai.
Real users/purchases/admin safe hain. B2 audio cleanup ke liye local env me
`B2_KEY_ID`, `B2_APP_KEY`, `B2_BUCKET_ID` set hone chahiye; warna sirf Firestore
demo docs delete honge aur B2 cleanup skip ho jayega.
