# BLUEFM — Cloudflare streaming (B2 = storage, Cloudflare = delivery)

**Yehi real app ka architecture hai:** audio ka *origin* Backblaze B2 hai, lekin
*browser tak delivery* Cloudflare se hoti hai. Isse do fayde hain jo aapne
point kiye:

1. **B2 egress free** — Cloudflare ↔ Backblaze ke beech Bandwidth Alliance hai,
   B2 se Cloudflare tak data free nikalta hai. B2 ka download/egress bill ₹0.
2. **User tak delivery Cloudflare se** — cache HITs pe Cloudflare se serve hota
   hai, B2 ko chhua bhi nahi jaata.

```
Browser ──> media.bluefm.site (Cloudflare edge) ──> B2 origin bucket
              │  cached at edge (Range supported, 206)
              └─ cache MISS pe hi origin hit
```

Bina custom domain ke B2 direct `f005.backblazeb2.com` deta hai — udhar egress
**billable** hota hai. Isliye custom domain lagana zaroori hai.

---

## Step 1 — Cloudflare account + zone

`bluefm.site` ka DNS Cloudflare pe hona chahiye (aapka already hai). Zone ID
nikalo:

```bash
curl -s "https://api.cloudflare.com/client/v4/zones?name=bluefm.site" \
  -H "Authorization: Bearer $CF_API_TOKEN" | jq '.result[0].id'
```

Token scope: **Zone.DNS:Edit** (custom domain ke liye) aur **Zone.Cache Purge**
(audio update karne ke liye).

## Step 2 — B2 par custom domain lagao

B2 ka custom domain feature Cloudflare ko origin ke roop me accept karta hai
(aur Cloudflare free-plan pe bhi kaam karta hai, SSL "Full" mode me):

```bash
# bucket par custom domain attach
curl -X POST "https://api005.backblazeb2.com/b2api/v3/b2_update_bucket" \
  -H "Authorization: $B2_AUTH_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "accountId": "0faf30fb7bce",
    "bucketId": "e0af0a7f83d0af4ba71b0c1e",
    "customBucketInfo": {
      "customBucketDomain": "media.bluefm.site"
    }
  }'
```

Phir B2 jo CNAME dega wo Cloudflare DNS me daalo:

```
media.bluefm.site  CNAME  bluefm-web-audio.s3.us-west-002.backblazeb2.com   (proxied ☁️ ON)
```

⚠️ **Proxied (orange cloud) ON** hona chahiye — tabhi Cloudflare edge se serve
hoga aur B2 egress free rahega. Grey cloud (DNS only) = direct B2 = billable.

> B2 custom domain ka exact CNAME target `b2_get_bucket` ke response me
> `customBucketInfo` se milta hai. Ek baar attach karne ke baad wo wahi rahega.

## Step 3 — Env set karo

Server sirf itna badalna hai:

```bash
# streaming Cloudflare se jaayega
AUDIO_STORAGE=b2
B2_DOWNLOAD_URL=https://media.bluefm.site     # ⬅️ ye line hi CDN on karti hai
B2_BUCKET_NAME=bluefm-web-audio
B2_KEY_ID=...
B2_APP_KEY=...
B2_BUCKET_ID=e0af0a7f83d0af4ba71b0c1e
```

`B2_DOWNLOAD_URL` set hote hi signed URLs ka host badal jaata hai aur
`/api/playback/authorize` ka response `delivery: "cloudflare"` deta hai.
Verify:

```bash
curl -s localhost:8080/api/playback/authorize -b cookie.txt \
  -H 'content-type: application/json' \
  -d '{"storyId":"last-metro","episodeId":"last-metro-e1"}' | jq -r .url
# https://media.bluefm.site/last-metro-e1.mp3?Authorization=...
```

## Step 4 — Cache rules (Cloudflare dashboard → Caching → Cache Rules)

| Rule | Setting |
|------|---------|
| `hostname eq "media.bluefm.site"` | Cache eligible ✅ |
| | Edge TTL: **Respect origin** ya 7 days |
| | **Ignore query string: ON** (Authorization token cache key me na aaye) |
| | Cache Range requests: ON (default) |

Query string ignore karna zaroori hai — warna har naye token pe cache MISS hoga
aur B2 egress wapas billable ho jayega. Security token se nahi, **edge worker**
se lagti hai (Step 5) — isliye query ignore safe hai.

Purge (audio replace karne pe):

```bash
curl -X POST "https://api.cloudflare.com/client/v4/zones/$ZONE_ID/purge_cache" \
  -H "Authorization: Bearer $CF_API_TOKEN" \
  -H 'content-type: application/json' \
  -d '{"files":["https://media.bluefm.site/last-metro-e1.mp3"]}'
```

---

## Step 5 (recommended) — Edge auth Worker

`B2_DOWNLOAD_URL` wala tarika simple hai aur abhi kaam karta hai: signed URL me
B2 token hota hai, Cloudflare use cache karta hai aur origin pe forward karta
hai. Lekin token 10 min me expire hota hai, isliye **Worker** zyada saaf hai:
URL sada rehta hai, entitlement check edge pe hota hai, aur cache `Authorization`
header se bilkul independent hota hai.

Deploy: `workers/stream-auth/README.md` dekho.

```
GET https://media.bluefm.site/{episodeId}.mp3?t=<HMAC token>
   │  Worker: HMAC verify + expiry check
   ├─ valid   → fetch(origin, {cf: {cacheEverything: true, cacheTtl: 604800}})
   └─ invalid → 403
```

---

## Kya kya free hai (bill ka hisaab)

| Leg | Provider | Cost |
|-----|----------|------|
| Browser → Cloudflare edge | Cloudflare | **free** (unlimited) |
| Cloudflare edge → B2 origin (miss) | Bandwidth Alliance | **free** |
| B2 storage (14.3 MB abhi) | Backblaze | ~$0.006/GB/month |
| B2 → Cloudflare egress | Backblaze | **₹0** (alliance) |
| B2 → browser *direct* (custom domain ke bina) | Backblaze | billable ⚠️ |

Isliye custom domain + orange cloud lagana hi asli bachat hai — aur wahi real
app karta hai.
