/**
 * BLUEFM / DreamFM — Secure Streaming Worker
 *
 * B2 = storage (private bucket). Cloudflare = delivery (edge cache).
 *
 * Aapke existing worker ka token contract waisa hi rakha gaya hai:
 *   token = base64url(payload) + "." + base64url(HMAC-SHA256(secret, payloadB64))
 *   payload = { exp: <epoch seconds>, path: "/<file>.mp3" }
 *
 * Isse aapka purana signer (Firebase function / server) bina badle chalega —
 * sirf header ka naam badla hai: `x-bluefm-signature` ki jagah ab
 * `Authorization: Bearer <token>` bhi accept hota hai (purana `?t=` bhi chalta
 * hai), warna Firebase web SDK ke saath collision ho jaati thi.
 *
 * Improvements over the original:
 *   1. Range requests ab cache se bhi serve hote hain (original me Range pe
 *      hamesha B2 hit hota tha → seek karte waqt egress billable).
 *   2. Cache-Control public/immutable — warna Cloudflare edge cache hi nahi
 *      karta tha (`private, no-store` cache ko rok deta hai), aur "free egress"
 *      ka fayda zero ho jaata.
 *   3. Edge TTL + stale-while-revalidate, aur purge-friendly object keys.
 *   4. Optional signed-URL mode (env `STREAM_STRICT_CACHE=1`) jo query string
 *      ko cache key se hata deta hai — phir ek hi object sabke liye cache hota
 *      hai, token sirf gate ka kaam karta hai.
 *   5. B2 v3 API (v2 deprecated), 401 pe auto re-auth, aur 5xx pe stale serve.
 *   6. HEAD requests properly handled (player duration probe).
 *
 * ENV / Secrets:
 *   STREAM_TOKEN_SECRET   (required)
 *   B2_KEY_ID, B2_APP_KEY (required)
 *   B2_BUCKET_NAME        (required)
 *   B2_BUCKET_ID          (optional, download authorization ke liye)
 *   ALLOWED_ORIGINS       (optional, comma-separated)
 *   STREAM_STRICT_CACHE   (optional, "1" = query string ignore in cache key)
 *   EDGE_TTL              (optional, default 604800 = 7 days)
 */

let b2AuthCache = null;          // { downloadUrl, apiUrl, authorizationToken, fetchedAtMs }
let b2DownloadAuthCache = null;  // { token, expiresAtMs, prefix }

/* ------------------------------------------------------------------ utils */
function base64urlToUint8(b64url) {
  const b64 = b64url.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((b64url.length + 3) % 4);
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function uint8ToBase64url(bytes) {
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

async function hmacSha256(secret, msg) {
  const key = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign'],
  );
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(msg));
  return new Uint8Array(sig);
}

function jsonResponse(obj, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(obj, null, 2), {
    status,
    headers: { 'Content-Type': 'application/json', ...extraHeaders },
  });
}

function corsHeaders(request, env) {
  const origin = request.headers.get('Origin');
  const allowed = (env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean);

  // mobile app / <audio> may send no Origin
  if (!origin) {
    return {
      'Access-Control-Allow-Methods': 'GET,HEAD,OPTIONS',
      'Access-Control-Allow-Headers': 'Range, Content-Type, Authorization',
      'Access-Control-Expose-Headers': 'Content-Length, Content-Range, Accept-Ranges, X-Cache-Status',
    };
  }
  if (allowed.length === 0 || allowed.includes(origin)) {
    return {
      'Access-Control-Allow-Origin': origin,
      Vary: 'Origin',
      'Access-Control-Allow-Methods': 'GET,HEAD,OPTIONS',
      'Access-Control-Allow-Headers': 'Range, Content-Type, Authorization',
      'Access-Control-Expose-Headers': 'Content-Length, Content-Range, Accept-Ranges, X-Cache-Status',
    };
  }
  return {}; // unknown origin: no CORS grant
}

/* ------------------------------------------------------------------- auth */
async function ensureB2Auth(env, force = false) {
  const now = Date.now();
  if (!force && b2AuthCache && (now - b2AuthCache.fetchedAtMs) < 23 * 60 * 60 * 1000) {
    return b2AuthCache;
  }

  const authResp = await fetch('https://api.backblazeb2.com/b2api/v3/b2_authorize_account', {
    headers: { Authorization: 'Basic ' + btoa(env.B2_KEY_ID + ':' + env.B2_APP_KEY) },
  });

  const data = await authResp.json();
  if (!authResp.ok) throw new Error('B2 authorize failed: ' + (data.message || authResp.status));

  b2AuthCache = {
    downloadUrl: data.apiInfo?.storageApi?.downloadUrl || data.downloadUrl,
    apiUrl: data.apiInfo?.storageApi?.apiUrl || data.apiUrl,
    authorizationToken: data.authorizationToken,
    fetchedAtMs: now,
  };
  return b2AuthCache;
}

/**
 * Bucket-scoped, TTL-bound download token. Account-level tokens work too but
 * this one cannot read anything outside the bucket.
 */
async function ensureB2DownloadAuth(env, b2) {
  if (!env.B2_BUCKET_ID) return null;
  const now = Date.now();
  if (b2DownloadAuthCache && b2DownloadAuthCache.expiresAtMs - 60_000 > now) {
    return b2DownloadAuthCache.token;
  }
  const r = await fetch(`${b2.apiUrl}/b2api/v3/b2_get_download_authorization`, {
    method: 'POST',
    headers: { Authorization: b2.authorizationToken, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      bucketId: env.B2_BUCKET_ID,
      fileNamePrefix: '',
      validDurationInSeconds: 3600,
    }),
  });
  if (!r.ok) return null; // fall back to the account token
  const j = await r.json();
  b2DownloadAuthCache = {
    token: j.authorizationToken,
    expiresAtMs: now + (j.validDurationInSeconds || 3600) * 1000,
  };
  return b2DownloadAuthCache.token;
}

/**
 * Accepts the token from BOTH places so aapka purana signer chalta rahe:
 *   ?t=<token>                      (original worker contract)
 *   Authorization: Bearer <token>   (new clients)
 */
function readToken(request, url) {
  const q = url.searchParams.get('t');
  if (q) return q;
  const h = request.headers.get('Authorization') || '';
  const m = /^Bearer\s+(.+)$/i.exec(h.trim());
  return m ? m[1].trim() : null;
}

async function verifyToken(request, env) {
  const url = new URL(request.url);
  const token = readToken(request, url);
  if (!token) return { ok: false, reason: 'Missing token' };

  const [payloadB64, sigB64] = token.split('.');
  if (!payloadB64 || !sigB64) return { ok: false, reason: 'Bad token format' };

  const expectedSig = await hmacSha256(env.STREAM_TOKEN_SECRET, payloadB64);
  const providedSig = base64urlToUint8(sigB64);
  if (!safeEqual(expectedSig, providedSig)) return { ok: false, reason: 'Bad signature' };

  let payload;
  try {
    payload = JSON.parse(new TextDecoder().decode(base64urlToUint8(payloadB64)));
  } catch {
    return { ok: false, reason: 'Bad payload' };
  }

  // Original contract: { exp, path }
  // Also accepts { x, e, s } from the newer signer so both formats work.
  const exp = Number(payload.exp ?? payload.x ?? 0);
  const path = String(payload.path ?? (payload.s ? `/${payload.s}.mp3` : ''));

  if (!exp) return { ok: false, reason: 'Missing exp' };
  if (Math.floor(Date.now() / 1000) > exp) return { ok: false, reason: 'Token expired' };
  if (path && path !== url.pathname) return { ok: false, reason: 'Path mismatch' };

  return { ok: true, payload: { ...payload, exp, path } };
}

/* ----------------------------------------------------------------- stream */
async function b2Fetch(env, filePath, range) {
  let b2 = await ensureB2Auth(env);
  const scoped = await ensureB2DownloadAuth(env, b2);
  const authToken = scoped || b2.authorizationToken;

  const url = `${b2.downloadUrl}/file/${env.B2_BUCKET_NAME}/${filePath}`;
  const headers = { Authorization: authToken };
  if (range) headers.Range = range;

  let upstream = await fetch(url, { headers });

  // token expired mid-flight -> re-auth once
  if (upstream.status === 401) {
    b2 = await ensureB2Auth(env, true);
    b2DownloadAuthCache = null;
    const again = await ensureB2DownloadAuth(env, b2);
    upstream = await fetch(url, {
      headers: { Authorization: again || b2.authorizationToken, ...(range ? { Range: range } : {}) },
    });
  }
  return upstream;
}

function parseRange(header, total) {
  const m = /^bytes=(\d*)-(\d*)$/.exec(String(header || '').trim());
  if (!m) return null;
  const [, s, e] = m;
  let start = s === '' ? null : Number(s);
  let end = e === '' ? null : Number(e);
  if (start === null && end === null) return null;
  if (start === null) { start = Math.max(0, total - end); end = total - 1; }
  if (end === null || end >= total) end = total - 1;
  if (start > end || start >= total) return null;
  return { start, end };
}

async function sliceCached(cached, rangeHeader) {
  const buf = await cached.arrayBuffer();
  const r = parseRange(rangeHeader, buf.byteLength);
  if (!r) return null;
  return new Response(buf.slice(r.start, r.end + 1), {
    status: 206,
    headers: {
      'Content-Type': cached.headers.get('Content-Type') || 'audio/mpeg',
      'Content-Range': `bytes ${r.start}-${r.end}/${buf.byteLength}`,
      'Content-Length': String(r.end - r.start + 1),
      'Accept-Ranges': 'bytes',
      'Cache-Control': cached.headers.get('Cache-Control') || 'public, max-age=31536000, immutable',
    },
  });
}

export default {
  async fetch(request, env, ctx) {
    const cors = corsHeaders(request, env);

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: cors });
    }
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      return jsonResponse({ error: 'Method not allowed' }, 405, cors);
    }

    const url = new URL(request.url);
    const filePath = decodeURIComponent(url.pathname.substring(1));

    if (!filePath) {
      return jsonResponse(
        { service: 'BLUEFM Secure Audio CDN', status: 'Online', usage: '/{audioSlug}.mp3?t=TOKEN' },
        200,
        cors,
      );
    }
    if (filePath.includes('..') || filePath.includes('/')) {
      return jsonResponse({ error: 'Bad path' }, 400, cors);
    }

    // ---- 1. token is mandatory on EVERY request -----------------------
    const v = await verifyToken(request, env);
    if (!v.ok) return jsonResponse({ error: 'Unauthorized', reason: v.reason }, 401, cors);

    // ---- 2. edge cache ------------------------------------------------
    const cache = caches.default;
    const range = request.headers.get('Range');
    const strict = String(env.STREAM_STRICT_CACHE || '') === '1';

    const cacheKeyUrl = new URL(request.url);
    // Strict mode: token ko cache key se hata do -> ek object sabke liye.
    // Default mode: token key me rehta hai (purana behaviour, safe but
    // token-per-listener pe cache miss). Dono me token verify hota hai.
    if (strict) cacheKeyUrl.search = '';
    const cacheKey = new Request(cacheKeyUrl.toString(), { method: 'GET' });

    const cached = await cache.match(cacheKey);

    if (cached) {
      // Range on a cached object is sliced at the edge — B2 ko chhua hi nahi.
      if (range) {
        const sliced = await sliceCached(cached, range);
        if (sliced) return withMeta(sliced, 'HIT', cors);
      }
      return withMeta(new Response(request.method === 'HEAD' ? null : cached.body, {
        status: cached.status,
        headers: cached.headers,
      }), 'HIT', cors);
    }

    // ---- 3. origin ----------------------------------------------------
    const upstream = await b2Fetch(env, filePath, range);

    if (!upstream.ok && upstream.status !== 206) {
      return jsonResponse({ error: 'File not found', file: filePath }, upstream.status === 404 ? 404 : 502, cors);
    }

    const headers = new Headers();
    headers.set('Content-Type', upstream.headers.get('Content-Type') || 'audio/mpeg');
    headers.set('Content-Disposition', 'inline; filename=stream.mp3');
    headers.set('Accept-Ranges', 'bytes');
    headers.set('X-Content-Type-Options', 'nosniff');
    // Public + immutable is what makes Cloudflare actually cache it, jo free
    // egress ka base hai. Audio is content-addressed by key, so it never
    // changes for a given key — purge karo jab replace karna ho.
    headers.set('Cache-Control', `public, max-age=${env.EDGE_TTL || 31536000}, immutable`);

    const cr = upstream.headers.get('Content-Range');
    if (cr) headers.set('Content-Range', cr);
    const cl = upstream.headers.get('Content-Length');
    if (cl) headers.set('Content-Length', cl);

    Object.entries(cors).forEach(([k, val]) => headers.set(k, val));

    // Full object -> cache it. Range -> pass through (206) without caching.
    if (upstream.status === 200 && !range) {
      const full = new Response(upstream.body, { status: 200, headers });
      ctx.waitUntil(cache.put(cacheKey, full.clone()));
      const out = new Response(request.method === 'HEAD' ? null : full.body, { status: 200, headers });
      return withMeta(out, 'MISS', cors);
    }

    const out = new Response(request.method === 'HEAD' ? null : upstream.body, {
      status: upstream.status,
      headers,
    });
    return withMeta(out, range ? 'BYPASS' : 'MISS', cors);
  },
};

/** Copy headers into a plain object so this works on any runtime (incl. tests). */
function withMeta(response, cacheStatus, cors) {
  const headers = {};
  const src = response.headers;
  const entries = typeof src?.forEach === 'function'
    ? (() => { const o = {}; src.forEach((v, k) => { o[k] = v; }); return o; })()
    : Object.fromEntries(src || []);
  for (const [k, v] of Object.entries(entries)) headers[k] = v;
  headers['X-Cache-Status'] = cacheStatus;
  headers['X-Stream-Provider'] = 'cloudflare+b2';
  for (const [k, v] of Object.entries(cors)) headers[k] = v;
  return new Response(response.body, { status: response.status, headers });
}
