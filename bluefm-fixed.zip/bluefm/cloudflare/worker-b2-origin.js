/**
 * B2 origin authorisation *inside* the worker.
 *
 * The bucket is private, so the worker (not the browser) proves it may read the
 * object. Tokens are cached in the worker isolate and refreshed before expiry —
 * this costs one auth call per isolate, not per request.
 *
 * Browser → Cloudflare → B2. The user's stream token never reaches Backblaze,
 * and the B2 key never reaches the browser.
 */
let cache = { token: null, apiUrl: null, expiresAt: 0, downloadToken: null, downloadExpiresAt: 0 };

export async function b2Authorize(env) {
  if (cache.token && Date.now() < cache.expiresAt - 60_000) return cache;

  const basic = btoa(`${env.B2_KEY_ID}:${env.B2_APP_KEY}`);
  const r = await fetch('https://api.backblazeb2.com/b2api/v3/b2_authorize_account', {
    headers: { Authorization: `Basic ${basic}` },
  });
  if (!r.ok) throw new Error(`b2 authorize ${r.status}`);
  const j = await r.json();

  cache = {
    token: j.authorizationToken,
    apiUrl: j.apiInfo?.storageApi?.apiUrl || j.apiUrl,
    expiresAt: Date.now() + 23 * 3600 * 1000,
    downloadToken: null,
    downloadExpiresAt: 0,
  };
  return cache;
}

/** Short-lived bucket-scoped download token, reused for many requests. */
export async function b2DownloadToken(env, ttl = 3600) {
  if (cache.downloadToken && Date.now() < cache.downloadExpiresAt - 60_000) {
    return cache.downloadToken;
  }
  const auth = await b2Authorize(env);
  const r = await fetch(`${auth.apiUrl}/b2api/v3/b2_get_download_authorization`, {
    method: 'POST',
    headers: { Authorization: auth.token, 'content-type': 'application/json' },
    body: JSON.stringify({
      bucketId: env.B2_BUCKET_ID,
      fileNamePrefix: '',
      validDurationInSeconds: ttl,
    }),
  });
  if (!r.ok) throw new Error(`b2 download auth ${r.status}`);
  const j = await r.json();
  cache.downloadToken = j.authorizationToken;
  cache.downloadExpiresAt = Date.now() + (j.validDurationInSeconds || ttl) * 1000;
  return cache.downloadToken;
}
