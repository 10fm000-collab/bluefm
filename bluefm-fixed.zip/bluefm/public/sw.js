/* BLUEFM service worker — app-shell caching only.
 *
 * SECURITY: paid audio is NEVER cached. /api/playback/* is always network-only,
 * so an expired entitlement can never be bypassed via the browser cache.
 * Audio responses are also served with Cache-Control: private, no-store.
 */
const VERSION = 'bluefm-v1';
const SHELL = `${VERSION}-shell`;
const STATIC = `${VERSION}-static`;

const SHELL_ASSETS = ['/', '/manifest.webmanifest', '/offline.html', '/icons/icon-192.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL).then((cache) => cache.addAll(SHELL_ASSETS)).then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  // Never cache or intercept audio, auth or payment traffic.
  if (url.pathname.startsWith('/api/')) return;

  // Immutable build assets: cache-first.
  if (url.pathname.startsWith('/assets/') || url.pathname.startsWith('/icons/')) {
    event.respondWith(
      caches.open(STATIC).then(async (cache) => {
        const hit = await cache.match(request);
        if (hit) return hit;
        const res = await fetch(request);
        if (res.ok) cache.put(request, res.clone());
        return res;
      }),
    );
    return;
  }

  // Cover art: stale-while-revalidate (public marketing assets, never audio).
  if (url.pathname.startsWith('/media/covers/')) {
    event.respondWith(
      caches.open(STATIC).then(async (cache) => {
        const hit = await cache.match(request);
        const network = fetch(request)
          .then((res) => { if (res.ok) cache.put(request, res.clone()); return res; })
          .catch(() => hit);
        return hit || network;
      }),
    );
    return;
  }

  // Navigations: network-first with offline fallback shell.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request).catch(async () => {
        const cache = await caches.open(SHELL);
        return (await cache.match('/offline.html')) || (await cache.match('/')) || Response.error();
      }),
    );
  }
});
