import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../lib/api.js';
import { useApi, useAuth, useToast } from '../lib/store.jsx';
import { EmptyState, Sheet, Spinner } from '../components/Ui.jsx';
import {
  IconChevronRight, IconLogout, IconMail, IconShield, IconUser, IconWallet,
  IconHeadphones, IconHeart, IconLock, IconCheck, IconInfo,
} from '../components/Icons.jsx';
import { countdown, formatDate, initials, money } from '../lib/format.js';

export default function Profile() {
  const { user, ready, logout, setUser } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const profile = useApi('/api/me', { enabled: Boolean(user) });
  const [sheet, setSheet] = useState(null); // 'name' | 'password' | null
  const [name, setName] = useState('');
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '' });
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  if (!ready) return <div className="page"><Spinner /></div>;

  if (!user) {
    return (
      <div className="page">
        <div className="page-head"><h1>Profile</h1></div>
        <EmptyState
          icon={<IconUser />}
          title="You’re browsing as a guest"
          body="Sign in to unlock stories, sync your listening position and keep your purchase history."
          action={<Link to="/signin" className="btn btn--primary">Sign in or create account</Link>}
        />
      </div>
    );
  }

  const stats = profile.data?.stats;
  const active = profile.data?.activePasses || [];

  const saveName = async () => {
    setBusy(true); setError(null);
    try {
      const d = await api.patch('/api/me', { name });
      setUser({ ...user, name: d.user.name });
      toast.success('Profile updated');
      setSheet(null);
      profile.refetch();
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };

  const savePassword = async () => {
    setBusy(true); setError(null);
    try {
      await api.post('/api/me/password', pw);
      toast.success('Password changed');
      setSheet(null);
      setPw({ currentPassword: '', newPassword: '' });
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };

  const doLogout = async () => {
    await logout();
    toast.info('Signed out');
    navigate('/');
  };

  return (
    <div className="page">
      <div className="page-head"><h1>Profile</h1></div>

      <div className="plan-card" style={{ padding: 18 }}>
        <div className="row" style={{ gap: 14 }}>
          <div
            className="avatar"
            style={{ width: 58, height: 58, fontSize: 20, cursor: 'default' }}
            aria-hidden="true"
          >
            {initials(user.name)}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 18, fontWeight: 800, letterSpacing: '-0.02em' }}>{user.name}</div>
            <div className="small dim row" style={{ gap: 5, marginTop: 3 }}>
              <IconMail width="13" height="13" /> {user.email}
            </div>
            {user.role === 'admin' && (
              <span className="pill pill--gold mt-8"><IconShield width="11" height="11" /> Administrator</span>
            )}
          </div>
        </div>

        <div className="row row--wrap mt-16" style={{ gap: 10 }}>
          <div style={{ flex: '1 1 90px' }}>
            <div className="tiny dim">Active passes</div>
            <div style={{ fontSize: 20, fontWeight: 800 }}>{stats?.activePassCount ?? '—'}</div>
          </div>
          <div style={{ flex: '1 1 90px' }}>
            <div className="tiny dim">Purchases</div>
            <div style={{ fontSize: 20, fontWeight: 800 }}>{stats?.purchaseCount ?? '—'}</div>
          </div>
          <div style={{ flex: '1 1 90px' }}>
            <div className="tiny dim">Spent</div>
            <div style={{ fontSize: 20, fontWeight: 800 }}>{stats ? money(stats.totalSpent) : '—'}</div>
          </div>
        </div>
      </div>

      {active.length > 0 && (
        <div className="plan-card mt-16">
          <div className="row row--between">
            <span className="plan-card__title">Your active access</span>
            <Link to="/library" className="section__link">Library <IconChevronRight width="12" height="12" /></Link>
          </div>
          <div className="stack mt-12">
            {active.map((s) => (
              <div key={s.id} className="row" style={{ gap: 10 }}>
                <img src={s.cover} alt="" width="34" height="51" style={{ borderRadius: 6, objectFit: 'cover' }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="small bold" style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.title}</div>
                  <div className="tiny dim">{s.access.plan} · until {formatDate(s.access.expiresAt)}</div>
                </div>
                <span className="pill pill--unlocked tiny">{countdown(Date.parse(s.access.expiresAt) - Date.now())}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="stack mt-16">
        <MenuItem icon={<IconHeadphones />} label="My library" sub="Passes, history, purchases" onClick={() => navigate('/library')} />
        <MenuItem icon={<IconHeart />} label="Favourites" sub="Stories you saved" onClick={() => navigate('/library')} />
        <MenuItem icon={<IconWallet />} label="Purchase history" sub="Receipts and expiry dates" onClick={() => navigate('/library')} />
        <MenuItem icon={<IconUser />} label="Edit name" sub={user.name} onClick={() => { setName(user.name); setError(null); setSheet('name'); }} />
        <MenuItem icon={<IconLock />} label="Change password" sub="Keep your account secure" onClick={() => { setError(null); setSheet('password'); }} />
        {user.role === 'admin' && (
          <MenuItem icon={<IconShield />} label="Admin dashboard" sub="Manage stories, episodes and payments" onClick={() => navigate('/admin')} />
        )}
      </div>

      <div className="banner-note mt-24">
        <IconInfo />
        <div>
          Passes are verified on our servers on every playback request using server time. Clearing your browser
          data will never unlock a story.
        </div>
      </div>

      <button type="button" className="btn btn--danger btn--block mt-24" onClick={doLogout}>
        <IconLogout width="16" height="16" /> Sign out
      </button>

      <p className="tiny dim center mt-24">BLUEFM · v1.0 · Member since {formatDate(user.createdAt)}</p>

      <Sheet open={sheet === 'name'} onClose={() => setSheet(null)} title="Edit your name">
        {error && <div className="form-error">{error}</div>}
        <div className="field">
          <label htmlFor="n">Display name</label>
          <input id="n" className="input" value={name} onChange={(e) => setName(e.target.value)} maxLength={60} />
        </div>
        <button type="button" className="btn btn--primary btn--block" onClick={saveName} disabled={busy}>Save</button>
      </Sheet>

      <Sheet open={sheet === 'password'} onClose={() => setSheet(null)} title="Change password" subtitle="You’ll stay signed in on this device.">
        {error && <div className="form-error">{error}</div>}
        <div className="field">
          <label htmlFor="cp">Current password</label>
          <input id="cp" className="input" type="password" autoComplete="current-password" value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} />
        </div>
        <div className="field">
          <label htmlFor="np">New password</label>
          <input id="np" className="input" type="password" autoComplete="new-password" value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} />
        </div>
        <button type="button" className="btn btn--primary btn--block" onClick={savePassword} disabled={busy}>Update password</button>
      </Sheet>
    </div>
  );
}

function MenuItem({ icon, label, sub, onClick }) {
  return (
    <button type="button" className="wide-card" onClick={onClick} style={{ padding: '13px 14px' }}>
      <span
        style={{
          width: 36, height: 36, borderRadius: 11, display: 'grid', placeItems: 'center',
          background: 'rgba(47,107,255,0.12)', border: '1px solid rgba(77,139,255,0.22)',
          color: 'var(--blue-bright)', flexShrink: 0,
        }}
      >
        {React.cloneElement(icon, { width: 17, height: 17 })}
      </span>
      <span className="wide-card__body">
        <span className="wide-card__title" style={{ display: 'block' }}>{label}</span>
        {sub && <span className="wide-card__sub" style={{ display: 'block' }}>{sub}</span>}
      </span>
      <IconChevronRight width="16" height="16" style={{ color: 'var(--text-3)', flexShrink: 0 }} />
    </button>
  );
}
