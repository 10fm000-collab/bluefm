import React from 'react';
import { Link } from 'react-router-dom';
import { EmptyState } from '../components/Ui.jsx';
import { IconCompass } from '../components/Icons.jsx';

export default function NotFound() {
  return (
    <div className="page">
      <div style={{ paddingTop: 40 }}>
        <EmptyState
          icon={<IconCompass />}
          title="Page not found"
          body="The page you’re looking for doesn’t exist or has moved."
          action={<Link to="/" className="btn btn--primary btn--sm">Back to home</Link>}
        />
      </div>
    </div>
  );
}
