import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, ApiError } from '../lib/api.js';
import { useApi, useAuth, usePlayer, useToast } from '../lib/store.jsx';
import {
  EmptyState, ErrorState, Section, Spinner, StoryCard, WideCard,
} from '../components/Ui.jsx';
import {
  IconClock, IconHeadphones, IconHeart, IconHistory, IconLock, IconUnlock,
  IconPlay, IconWallet, IconBookmark,
} from '../components/Icons.jsx';
import { countdown, formatDate, formatDateTime, money, timeAgo } from '../lib/format.js';

const TABS = [
  { id: 'passes', label: 'Active passes', icon: IconUnlock },
  { id: 'continue', label: 'Continue', icon: IconClock },
  { id: 'history', label: 'History', icon: IconHistory },
  { id: 'favorites', label: 'Favourites', icon: IconHeart },
  { id: 'purchases', label: 'Purchases', icon: IconWallet },
];

export default function Library() {
  const { user, ready } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState('passes');
  const player = usePlayer();
  const toast = useToast();

  const profile = useApi('/api/me', { enabled: Boolean(user) });
  const continueApi = useApi('/api/me/continue', { enabled: Boolean(user) });
  const historyApi = useApi('/api/me/history', { enabled: Boolean(user) });
  const favApi = useApi('/api/me/favorites', { enabled: Boolean(user) });

  if (!ready) return <div className="page"><Spinner /></div>;

  if (!user) {
    return (
      <div className="page">
        <div className="page-head"><h1>Your library</h1><p>Unlocked stories, listening history and purchases.</p></div>
        <EmptyState
          icon={<IconLock />}
          title="Sign in to see your library"
          body="Your passes, progress and purchases are stored against your account and sync across devices."
          action={<Link to="/signin" className="btn btn--primary">Sign in</Link>}
        />
      </div>
    );
  }

  const resume = async (item) => {
    try {
      const d = await api.get(`/api/stories/${item.storyId}`);
      const ep = d.episodes.find((e) => e.id === item.episodeId) || d.episodes[0];
      await player.play({ story: d.story, episode: ep, queue: d.episodes, resumeAt: item.position || 0 });
      player.setExpanded(true);
    } catch (err) {
      if (err.code === 'access_locked' || err.code === 'expired') {
        toast.error('Your pass for this story has expired — unlock it again to keep listening.');
        navigate(`/story/${item.storyId}`);
      } else toast.error(err.message);
    }
  };

  const p = profile.data;

  return (
    <div className={`page${player.track ? ' has-player' : ''}`}>
      <div className="page-head">
        <h1>Your library</h1>
        <p>{p ? `${p.stats.activePassCount} active ${p.stats.activePassCount === 1 ? 'pass' : 'passes'} · ${p.stats.purchaseCount} purchases` : 'Loading…'}</p>
      </div>

      <div className="chips" style={{ marginBottom: 18 }}>
        {TABS.map(({ id, label, icon: Icon }) => (
          <button key={id} type="button" className={`chip${tab === id ? ' active' : ''}`} onClick={() => setTab(id)}>
            <Icon width="14" height="14" /> {label}
          </button>
        ))}
      </div>

      {tab === 'passes' && (
        <>
          {profile.error && <ErrorState error={profile.error} onRetry={profile.refetch} />}
          {profile.data?.activePasses.length === 0 && (
            <EmptyState
              icon={<IconUnlock />}
              title="No active passes"
              body="Unlock a story from ₹1 and it will appear here with its exact expiry time."
              action={<Link to="/explore" className="btn btn--primary btn--sm">Explore stories</Link>}
            />
          )}
          {profile.data?.activePasses.length > 0 && (
            <div className="stack">
              {profile.data.activePasses.map((s) => (
                <div key={s.id} className="wide-card" style={{ alignItems: 'flex-start' }}>
                  <img className="wide-card__art" src={s.cover} alt="" style={{ width: 66, height: 99, borderRadius: 10 }} />
                  <div className="wide-card__body">
                    <Link to={`/story/${s.slug}`} className="wide-card__title" style={{ display: 'block' }}>{s.title}</Link>
                    <div className="wide-card__sub" style={{ marginBottom: 8 }}>
                      {s.access.plan} pass · expires {formatDate(s.access.expiresAt)}
                    </div>
                    <span className="pill pill--unlocked">{countdown(Date.parse(s.access.expiresAt) - Date.now())}</span>
                  </div>
                  <button
                    type="button"
                    className="wide-card__play"
                    aria-label={`Play ${s.title}`}
                    onClick={() => resume({ storyId: s.slug, episodeId: null, position: 0 })}
                  >
                    <IconPlay />
                  </button>
                </div>
              ))}
            </div>
          )}

          {profile.data?.expiredPasses.length > 0 && (
            <Section title="Expired passes" icon={<IconLock />}>
              <div className="story-grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))' }}>
                {profile.data.expiredPasses.map((s) => (
                  <Link key={s.id} to={`/story/${s.slug}`} className="wide-card" style={{ opacity: 0.75 }}>
                    <img className="wide-card__art" src={s.cover} alt="" style={{ width: 52, height: 78, borderRadius: 9 }} />
                    <div className="wide-card__body">
                      <div className="wide-card__title">{s.title}</div>
                      <div className="wide-card__sub">Expired {formatDate(s.access.expiresAt)}</div>
                      <span className="pill pill--expired mt-8">Renew to continue</span>
                    </div>
                  </Link>
                ))}
              </div>
            </Section>
          )}
        </>
      )}

      {tab === 'continue' && (
        <>
          {continueApi.data?.items.length === 0 && (
            <EmptyState icon={<IconClock />} title="Nothing in progress" body="Start an episode and your position will be saved here automatically." action={<Link to="/explore" className="btn btn--primary btn--sm">Find a story</Link>} />
          )}
          <div className="stack">
            {(continueApi.data?.items || []).map((item) => (
              <WideCard
                key={item.storyId + item.episodeId}
                item={item}
                onPlay={() => resume(item)}
                sub={`Ep ${item.episodeNumber} · ${item.episodeTitle} · ${item.percent}%`}
              />
            ))}
          </div>
        </>
      )}

      {tab === 'history' && (
        <>
          {historyApi.data?.history.length === 0 && (
            <EmptyState icon={<IconHistory />} title="No listening history yet" body="Episodes you play will appear here." />
          )}
          <div className="stack">
            {(historyApi.data?.history || []).map((h) => (
              <button
                key={h.id}
                type="button"
                className="wide-card"
                onClick={() => navigate(`/story/${h.storyId}`)}
              >
                <img className="wide-card__art" src={h.cover} alt="" style={{ width: 46, height: 46 }} />
                <div className="wide-card__body">
                  <div className="wide-card__title">{h.storyTitle}</div>
                  <div className="wide-card__sub">Ep {h.episodeNumber} · {h.episodeTitle}</div>
                </div>
                <span className="tiny dim">{timeAgo(h.at)}</span>
              </button>
            ))}
          </div>
        </>
      )}

      {tab === 'favorites' && (
        <>
          {favApi.data?.favorites.length === 0 && (
            <EmptyState icon={<IconHeart />} title="No favourites yet" body="Tap the heart on any story to save it here." action={<Link to="/explore" className="btn btn--primary btn--sm">Browse stories</Link>} />
          )}
          <div className="rail">
            {(favApi.data?.favorites || []).map((s) => (
              <StoryCard key={s.id} story={{ ...s, plays: 0, rating: 0 }} />
            ))}
          </div>
        </>
      )}

      {tab === 'purchases' && (
        <>
          {profile.data && (
            <div className="row row--wrap" style={{ gap: 10, marginBottom: 16 }}>
              <div className="plan-card" style={{ flex: '1 1 140px' }}>
                <div className="plan-card__hint">Total spent</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700 }}>{money(profile.data.stats.totalSpent)}</div>
              </div>
              <div className="plan-card" style={{ flex: '1 1 140px' }}>
                <div className="plan-card__hint">Successful purchases</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700 }}>{profile.data.stats.purchaseCount}</div>
              </div>
            </div>
          )}
          {profile.data?.purchases.length === 0 && (
            <EmptyState icon={<IconWallet />} title="No transactions yet" body="Your payment history — successful, failed and refunded — will appear here." />
          )}
          <div className="stack">
            {(profile.data?.purchases || []).map((pur) => (
              <div key={pur.id} className="wide-card" style={{ alignItems: 'flex-start' }}>
                {pur.cover && <img className="wide-card__art" src={pur.cover} alt="" style={{ width: 44, height: 44 }} />}
                <div className="wide-card__body">
                  <div className="wide-card__title">{pur.storyTitle}</div>
                  <div className="wide-card__sub">
                    {pur.plan} pass · {money(pur.amount)} · {formatDateTime(pur.createdAt)}
                  </div>
                  <div className="row mt-8" style={{ gap: 6, flexWrap: 'wrap' }}>
                    <span className={`pill ${pur.status === 'paid' ? 'pill--unlocked' : pur.status === 'failed' ? 'pill--trend' : 'pill--expired'}`}>
                      {pur.status}
                    </span>
                    {pur.expiresAt && <span className="pill">expires {formatDate(pur.expiresAt)}</span>}
                    <span className="pill"><span className="mono">{pur.id.slice(0, 12)}</span></span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
