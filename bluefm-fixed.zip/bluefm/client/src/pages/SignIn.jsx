import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth, useToast } from '../lib/store.jsx';
import { Logo, Sheet } from '../components/Ui.jsx';
import { IconAlert, IconGoogle, IconPhone, IconMail, IconLock, IconInfo } from '../components/Icons.jsx';

export default function SignIn() {
  const { login, register, user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToast();
  const [mode, setMode] = useState('signin');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState(null);

  const from = location.state?.from || '/';

  React.useEffect(() => {
    if (user) navigate(from, { replace: true });
  }, [user, from, navigate]);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (mode === 'signin') {
        const u = await login(form.email, form.password);
        toast.success(`Welcome back${u.name ? `, ${u.name.split(' ')[0]}` : ''}`);
      } else {
        const u = await register(form);
        toast.success(`Account created — welcome, ${u.name.split(' ')[0]}`);
      }
      navigate(from, { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const demo = async () => {
    setBusy(true);
    setError(null);
    try {
      await login('listener@bluefm.app', 'bluefm123');
      toast.success('Signed in as demo listener');
      navigate(from, { replace: true });
    } catch (err) {
      setError(err.message);
    } finally { setBusy(false); }
  };

  return (
    <div className="auth-page">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <Logo />
        <Link to="/" className="btn btn--ghost btn--sm">Browse as guest</Link>
      </div>

      <div className="auth-card">
        <h1 className="auth-title">{mode === 'signin' ? 'Welcome back' : 'Create your account'}</h1>
        <p className="auth-sub">
          {mode === 'signin'
            ? 'Sign in to continue listening to your unlocked series.'
            : 'One account for every story you unlock. Purchases are tied to your account, not your device.'}
        </p>

        <form onSubmit={submit} noValidate>
          {error && <div className="form-error" role="alert">{error}</div>}

          {mode === 'signup' && (
            <div className="field">
              <label htmlFor="name">Full name</label>
              <input
                id="name" className="input" autoComplete="name" required
                value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Aarav Sharma"
              />
            </div>
          )}

          <div className="field">
            <label htmlFor="email">Email address</label>
            <input
              id="email" className="input" type="email" inputMode="email" autoComplete="email" required
              value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="you@example.com"
            />
          </div>

          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password" className="input" type="password" required
              autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
              value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
              placeholder={mode === 'signup' ? 'At least 8 characters' : '••••••••'}
            />
          </div>

          <button type="submit" className="btn btn--primary btn--block btn--lg mt-8" disabled={busy}>
            {busy ? 'Please wait…' : mode === 'signin' ? 'Sign in' : 'Create account'}
          </button>
        </form>

        <div className="divider">or</div>

        <div className="stack">
          <button type="button" className="btn btn--glass btn--block" onClick={() => setNotice('google')}>
            <IconGoogle width="17" height="17" /> Continue with Google
          </button>
          <button type="button" className="btn btn--glass btn--block" onClick={() => setNotice('phone')}>
            <IconPhone width="16" height="16" /> Continue with phone
          </button>
        </div>

        <div className="divider">test accounts</div>
        <button type="button" className="btn btn--ghost btn--block btn--sm" onClick={demo} disabled={busy}>
          Sign in as demo listener
        </button>
        <p className="tiny dim center mt-8">
          Admin: <span className="mono">admin@bluefm.app</span> / <span className="mono">bluefm-admin-2026</span>
        </p>

        <p className="form-note">
          {mode === 'signin' ? (
            <>New to BLUEFM? <a href="#" onClick={(e) => { e.preventDefault(); setMode('signup'); setError(null); }}>Create an account</a></>
          ) : (
            <>Already have an account? <a href="#" onClick={(e) => { e.preventDefault(); setMode('signin'); setError(null); }}>Sign in</a></>
          )}
        </p>
      </div>

      <Sheet
        open={Boolean(notice)}
        onClose={() => setNotice(null)}
        title={notice === 'phone' ? 'Phone sign-in needs configuration' : 'Google sign-in needs configuration'}
        subtitle="This is a real integration point, not a placeholder button."
      >
        <div className="banner-note banner-note--warn" style={{ marginBottom: 14 }}>
          <IconInfo />
          <div>
            Google and phone sign-in require <b>Firebase Authentication</b> (a Firebase project with the Google and
            Phone providers enabled) plus a service account so the server can verify ID tokens.
          </div>
        </div>
        <div className="stack tiny muted">
          <div><b>Required env:</b> <span className="mono">AUTH_MODE=firebase</span>, <span className="mono">FIREBASE_PROJECT_ID</span>, <span className="mono">FIREBASE_SERVICE_ACCOUNT_JSON</span></div>
          <div><b>Server route:</b> <span className="mono">POST /api/auth/firebase</span> verifies the token with the Firebase Admin SDK before minting a BLUEFM session.</div>
          <div>Email + password sign-in is fully functional on this deployment.</div>
        </div>
        <button type="button" className="btn btn--primary btn--block mt-16" onClick={() => setNotice(null)}>Got it</button>
      </Sheet>
    </div>
  );
}
