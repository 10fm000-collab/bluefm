import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../lib/api.js';
import { useApi, useAuth, useToast } from '../lib/store.jsx';
import { Spinner, EmptyState, Sheet, Logo } from '../components/Ui.jsx';
import {
  IconChart, IconUsers, IconWallet, IconBook, IconHeadphones, IconPlus, IconEdit,
  IconTrash, IconUpload, IconCheck, IconX, IconAlert, IconRefresh, IconShield,
  IconArrowLeft, IconLock, IconPlay, IconClock, IconSearch,
} from '../components/Icons.jsx';
import { clock, compact, formatDate, formatDateTime, money, timeAgo } from '../lib/format.js';

const TABS = [
  { id: 'overview', label: 'Overview', icon: IconChart },
  { id: 'stories', label: 'Stories', icon: IconBook },
  { id: 'payments', label: 'Payments', icon: IconWallet },
  { id: 'users', label: 'Users', icon: IconUsers },
  { id: 'audit', label: 'Audit log', icon: IconShield },
];

export default function Admin() {
  const { user, ready } = useAuth();
  const [params, setParams] = useSearchParams();
  const tab = params.get('tab') || 'overview';

  if (!ready) return <div className="page"><Spinner /></div>;

  if (!user) {
    return (
      <div className="page">
        <EmptyState icon={<IconLock />} title="Sign in required" body="The admin dashboard is restricted to authorised administrators." action={<Link to="/signin" className="btn btn--primary">Sign in</Link>} />
      </div>
    );
  }

  if (user.role !== 'admin') {
    return (
      <div className="page">
        <EmptyState
          icon={<IconLock />}
          title="Administrator access required"
          body="Your account does not have admin privileges. Admin access is checked on the server for every admin API call — it can’t be enabled from the browser."
          action={<Link to="/" className="btn btn--primary btn--sm">Back to home</Link>}
        />
      </div>
    );
  }

  return (
    <div className="page page--wide">
      <div className="page-head row row--between row--wrap" style={{ gap: 12 }}>
        <div>
          <h1 className="row" style={{ gap: 9 }}><IconShield style={{ color: 'var(--blue-bright)', width: 22, height: 22 }} /> Admin</h1>
          <p>BLUEFM content, payments and access control.</p>
        </div>
        <Link to="/" className="btn btn--ghost btn--sm"><IconArrowLeft width="14" height="14" /> Back to app</Link>
      </div>

      <div className="chips" style={{ marginBottom: 20 }}>
        {TABS.map(({ id, label, icon: Icon }) => (
          <button key={id} type="button" className={`chip${tab === id ? ' active' : ''}`} onClick={() => setParams({ tab: id })}>
            <Icon width="14" height="14" /> {label}
          </button>
        ))}
      </div>

      {tab === 'overview' && <Overview />}
      {tab === 'stories' && <Stories />}
      {tab === 'payments' && <Payments />}
      {tab === 'users' && <Users />}
      {tab === 'audit' && <Audit />}
    </div>
  );
}

/* ------------------------------------------------------------- overview */
function Overview() {
  const { data, loading, error, refetch } = useApi('/api/admin/stats');

  if (loading) return <Spinner label="Loading dashboard" />;
  if (error) return <EmptyState icon={<IconAlert />} title="Couldn’t load stats" body={error.message} action={<button type="button" className="btn btn--primary btn--sm" onClick={refetch}>Retry</button>} />;
  const t = data.totals;

  const cards = [
    { label: 'Total users', value: t.users, sub: `${t.activeToday} active in 24h`, icon: IconUsers },
    { label: 'Active passes', value: t.activePasses, sub: `${t.expiredPasses} expired`, icon: IconCheck },
    { label: 'Purchases', value: t.purchases, sub: 'verified payments', icon: IconWallet },
    { label: 'Revenue today', value: money(t.revenueToday), sub: `${money(t.revenueWeek)} this week`, icon: IconChart },
    { label: 'Revenue (30d)', value: money(t.revenueMonth), sub: `${money(t.revenue)} lifetime`, icon: IconWallet },
    { label: 'Listens', value: compact(t.listens), sub: `${t.stories} stories · ${t.episodes} episodes`, icon: IconHeadphones },
  ];

  const maxRevenue = Math.max(1, ...data.trend.map((d) => d.revenue));

  return (
    <>
      {data.demoAnalytics && (
        <div className="banner-note banner-note--warn" style={{ marginBottom: 16 }}>
          <IconAlert />
          <div>Listening activity includes seeded demo events so the dashboard is meaningful in this preview. Real usage replaces them as users listen.</div>
        </div>
      )}

      <div className="story-grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(168px, 1fr))', gap: 12 }}>
        {cards.map((c) => (
          <div key={c.label} className="plan-card" style={{ padding: 14 }}>
            <div className="row row--between">
              <span className="tiny dim bold" style={{ textTransform: 'uppercase', letterSpacing: '0.06em' }}>{c.label}</span>
              <c.icon width="15" height="15" style={{ color: 'var(--blue-bright)' }} />
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700, margin: '8px 0 2px' }}>{c.value}</div>
            <div className="tiny dim">{c.sub}</div>
          </div>
        ))}
      </div>

      <div className="row mt-24" style={{ gap: 16, flexWrap: 'wrap', alignItems: 'stretch' }}>
        <div className="plan-card" style={{ flex: '1 1 340px' }}>
          <div className="row row--between" style={{ marginBottom: 14 }}>
            <span className="plan-card__title">Revenue · last 14 days</span>
            <span className="pill">{money(data.trend.reduce((s, d) => s + d.revenue, 0))}</span>
          </div>
          <div className="row" style={{ alignItems: 'flex-end', gap: 5, height: 120 }} role="img" aria-label="Revenue trend chart">
            {data.trend.map((d) => (
              <div key={d.date} style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', height: '100%' }} title={`${d.date}: ${money(d.revenue)} (${d.purchases} purchases)`}>
                <div
                  style={{
                    height: `${Math.max(3, (d.revenue / maxRevenue) * 100)}%`,
                    background: d.revenue ? 'var(--grad-brand)' : 'rgba(255,255,255,0.09)',
                    borderRadius: 4,
                    minHeight: 3,
                  }}
                />
              </div>
            ))}
          </div>
          <div className="row row--between tiny dim mt-8">
            <span>{data.trend[0]?.date.slice(5)}</span>
            <span>{data.trend.at(-1)?.date.slice(5)}</span>
          </div>
        </div>

        <div className="plan-card" style={{ flex: '1 1 240px' }}>
          <div className="plan-card__title" style={{ marginBottom: 12 }}>Plan mix</div>
          {Object.entries(data.planMix).map(([plan, count]) => {
            const total = Object.values(data.planMix).reduce((a, b) => a + b, 0) || 1;
            return (
              <div key={plan} style={{ marginBottom: 10 }}>
                <div className="row row--between tiny" style={{ marginBottom: 4 }}>
                  <span style={{ textTransform: 'capitalize', fontWeight: 700 }}>{plan}</span>
                  <span className="dim">{count}</span>
                </div>
                <div style={{ height: 6, borderRadius: 3, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
                  <div style={{ width: `${(count / total) * 100}%`, height: '100%', background: 'var(--grad-brand)' }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="row mt-16" style={{ gap: 16, flexWrap: 'wrap', alignItems: 'stretch' }}>
        <RankList title="Most purchased" rows={data.topStories} valueKey="purchases" suffix="purchases" />
        <RankList title="Most listened" rows={data.topListened} valueKey="listens" suffix="plays" />
      </div>
    </>
  );
}

function RankList({ title, rows, valueKey, suffix }) {
  return (
    <div className="plan-card" style={{ flex: '1 1 320px' }}>
      <div className="plan-card__title" style={{ marginBottom: 12 }}>{title}</div>
      {rows.length === 0 && <div className="tiny dim">No data yet.</div>}
      <div className="stack" style={{ gap: 9 }}>
        {rows.map((r, i) => (
          <div key={r.storyId} className="row" style={{ gap: 10 }}>
            <span className="tiny dim bold" style={{ width: 14 }}>{i + 1}</span>
            <img src={r.cover} alt="" width="28" height="42" style={{ borderRadius: 5, objectFit: 'cover' }} />
            <span className="small" style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontWeight: 600 }}>{r.title}</span>
            <span className="tiny bold">{r[valueKey]} <span className="dim" style={{ fontWeight: 600 }}>{suffix}</span></span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* -------------------------------------------------------------- stories */
function Stories() {
  const { data, loading, refetch } = useApi('/api/admin/stories');
  const [editing, setEditing] = useState(null); // story object | 'new'
  const [episodesFor, setEpisodesFor] = useState(null);
  const [busy, setBusy] = useState(false);
  const toast = useToast();

  const remove = async (story) => {
    if (!window.confirm(`Delete “${story.title}” and all its episodes? This cannot be undone.`)) return;
    setBusy(true);
    try {
      await api.del(`/api/admin/stories/${story.id}`);
      toast.success('Story deleted');
      refetch();
    } catch (err) {
      if (err.status === 409) {
        const archive = window.confirm(`${err.message}\n\nArchive it instead (hide from the app, keep transactions)?`);
        if (archive) {
          try {
            await api.patch(`/api/admin/stories/${story.id}`, { status: 'draft' });
            toast.success('Story archived');
            refetch();
          } catch (e) { toast.error(e.message); }
        }
      } else toast.error(err.message);
    } finally { setBusy(false); }
  };

  if (loading) return <Spinner label="Loading stories" />;

  return (
    <>
      <div className="row row--between row--wrap" style={{ marginBottom: 14, gap: 10 }}>
        <div className="small muted">{data.stories.length} stories · {data.stories.reduce((s, x) => s + x.episodeCount, 0)} published episodes</div>
        <button type="button" className="btn btn--primary btn--sm" onClick={() => setEditing('new')}>
          <IconPlus width="15" height="15" /> Add story
        </button>
      </div>

      <div className="stack">
        {data.stories.map((s) => (
          <div key={s.id} className="wide-card" style={{ alignItems: 'flex-start', padding: 12 }}>
            <img className="wide-card__art" src={s.cover} alt="" style={{ width: 50, height: 75, borderRadius: 8 }} />
            <div className="wide-card__body">
              <div className="wide-card__title">{s.title}</div>
              <div className="wide-card__sub">{s.author} · {s.genre.join(', ')} · {s.episodeCount} episodes</div>
              <div className="row mt-8" style={{ gap: 5, flexWrap: 'wrap' }}>
                <span className={`pill ${s.status === 'published' ? 'pill--unlocked' : 'pill--expired'}`}>{s.status}</span>
                {s.featuredRank > 0 && <span className="pill pill--gold">Featured #{s.featuredRank}</span>}
                {s.trending && <span className="pill pill--trend">Trending</span>}
                {s.isNew && <span className="pill pill--new">New</span>}
                <span className="pill">{compact(0)}</span>
              </div>
            </div>
            <div className="row" style={{ gap: 4, flexShrink: 0 }}>
              <button type="button" className="icon-btn" onClick={() => setEpisodesFor(s)} aria-label={`Manage episodes of ${s.title}`} title="Episodes">
                <IconHeadphones width="16" height="16" />
              </button>
              <button type="button" className="icon-btn" onClick={() => setEditing(s)} aria-label={`Edit ${s.title}`} title="Edit">
                <IconEdit width="15" height="15" />
              </button>
              <button type="button" className="icon-btn" onClick={() => remove(s)} disabled={busy} aria-label={`Delete ${s.title}`} title="Delete">
                <IconTrash width="15" height="15" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <StoryEditor
        story={editing}
        onClose={() => setEditing(null)}
        onSaved={() => { setEditing(null); refetch(); }}
      />
      <EpisodeManager
        story={episodesFor}
        onClose={() => { setEpisodesFor(null); refetch(); }}
      />
    </>
  );
}

function StoryEditor({ story, onClose, onSaved }) {
  const isNew = story === 'new';
  const toast = useToast();
  const [form, setForm] = useState({});
  const [cover, setCover] = useState(null);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!story) return;
    setForm(isNew
      ? { title: '', author: '', narrator: '', tagline: '', synopsis: '', description: '', genre: 'drama', language: 'Hindi + English', tags: '', status: 'published', featuredRank: 0, trending: false, isNew: true, publishedAt: new Date().toISOString().slice(0, 10) }
      : { ...story, genre: story.genre.join(','), tags: '' });
    setCover(null);
    setError(null);
  }, [story, isNew]);

  if (!story) return null;

  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => {
        if (v !== undefined && v !== null && k !== 'cover' && k !== 'id' && k !== 'coverKey') fd.append(k, String(v));
      });
      if (cover) fd.append('cover', cover);
      if (isNew) await api.post('/api/admin/stories', fd);
      else await api.patch(`/api/admin/stories/${story.id}`, fd);
      toast.success(isNew ? 'Story created' : 'Story updated');
      onSaved();
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };

  const F = ({ label, name, type = 'text', placeholder, rows }) => (
    <div className="field">
      <label htmlFor={name}>{label}</label>
      {rows ? (
        <textarea id={name} className="input" rows={rows} value={form[name] || ''} placeholder={placeholder} onChange={(e) => setForm({ ...form, [name]: e.target.value })} />
      ) : (
        <input id={name} className="input" type={type} value={form[name] ?? ''} placeholder={placeholder} onChange={(e) => setForm({ ...form, [name]: e.target.value })} />
      )}
    </div>
  );

  return (
    <Sheet open onClose={onClose} title={isNew ? 'Add a story' : 'Edit story'} subtitle={isNew ? 'Publish a new series without touching code.' : story.title}>
      {error && <div className="form-error">{error}</div>}
      <F label="Title *" name="title" placeholder="The Last Metro" />
      <div className="row" style={{ gap: 10 }}>
        <div style={{ flex: 1 }}><F label="Author" name="author" /></div>
        <div style={{ flex: 1 }}><F label="Narrator" name="narrator" /></div>
      </div>
      <F label="Tagline" name="tagline" placeholder="One line hook" />
      <F label="Short synopsis" name="synopsis" rows={3} />
      <F label="Full description" name="description" rows={4} />
      <div className="row" style={{ gap: 10 }}>
        <div style={{ flex: 1 }}><F label="Genres (comma separated)" name="genre" placeholder="mystery,thriller" /></div>
        <div style={{ flex: 1 }}><F label="Language" name="language" /></div>
      </div>
      <F label="Tags (comma separated)" name="tags" placeholder="urban mystery, mumbai" />
      <div className="row" style={{ gap: 10 }}>
        <div style={{ flex: 1 }}><F label="Release date" name="publishedAt" type="date" /></div>
        <div style={{ flex: 1 }}>
          <div className="field">
            <label htmlFor="status">Status</label>
            <select id="status" className="input" value={form.status || 'published'} onChange={(e) => setForm({ ...form, status: e.target.value })}>
              <option value="published">Published</option>
              <option value="draft">Draft / archived</option>
            </select>
          </div>
        </div>
      </div>
      <div className="row" style={{ gap: 16, marginBottom: 14 }}>
        <label className="row" style={{ gap: 7, fontSize: 12.5, fontWeight: 700 }}>
          <input type="checkbox" checked={Boolean(form.trending)} onChange={(e) => setForm({ ...form, trending: e.target.checked })} style={{ width: 16, height: 16, accentColor: 'var(--blue)' }} /> Trending
        </label>
        <label className="row" style={{ gap: 7, fontSize: 12.5, fontWeight: 700 }}>
          <input type="checkbox" checked={Boolean(form.isNew)} onChange={(e) => setForm({ ...form, isNew: e.target.checked })} style={{ width: 16, height: 16, accentColor: 'var(--blue)' }} /> New
        </label>
        <label className="row" style={{ gap: 7, fontSize: 12.5, fontWeight: 700 }}>
          Featured #
          <input type="number" min="0" max="9" className="input" value={form.featuredRank ?? 0} onChange={(e) => setForm({ ...form, featuredRank: e.target.value })} style={{ width: 64, height: 34 }} />
        </label>
      </div>
      <div className="field">
        <label htmlFor="cover">Cover image (JPEG/PNG/WebP · 2:3 recommended)</label>
        <input id="cover" className="input" type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setCover(e.target.files?.[0] || null)} />
      </div>
      <button type="button" className="btn btn--primary btn--block" onClick={save} disabled={busy}>
        {busy ? 'Saving…' : isNew ? 'Create story' : 'Save changes'}
      </button>
    </Sheet>
  );
}

function EpisodeManager({ story, onClose }) {
  const toast = useToast();
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ title: '', number: '', description: '' });
  const [file, setFile] = useState(null);
  const [error, setError] = useState(null);

  const load = async () => {
    if (!story) return;
    setLoading(true);
    try {
      const d = await api.get(`/api/admin/stories/${story.id}/episodes`);
      setList(d.episodes);
    } catch (err) { setError(err.message); } finally { setLoading(false); }
  };

  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [story]);

  if (!story) return null;

  const upload = async () => {
    if (!form.title.trim()) return setError('Episode title is required.');
    if (!file) return setError('Choose an MP3 file to upload.');
    setBusy(true); setError(null);
    const fd = new FormData();
    fd.append('title', form.title);
    if (form.number) fd.append('number', form.number);
    if (form.description) fd.append('description', form.description);
    fd.append('audio', file);
    try {
      const d = await api.post(`/api/admin/stories/${story.id}/episodes`, fd);
      toast.success(`Episode ${d.episode.number} added (${clock(d.episode.duration)})`);
      setForm({ title: '', number: '', description: '' });
      setFile(null);
      load();
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };

  const togglePublish = async (ep) => {
    try {
      await api.patch(`/api/admin/episodes/${ep.id}`, { status: ep.status === 'published' ? 'draft' : 'published' });
      load();
    } catch (err) { toast.error(err.message); }
  };

  const removeEp = async (ep) => {
    if (!window.confirm(`Delete episode ${ep.number} “${ep.title}” and its audio file?`)) return;
    try {
      await api.del(`/api/admin/episodes/${ep.id}`);
      toast.success('Episode deleted');
      load();
    } catch (err) { toast.error(err.message); }
  };

  const move = async (index, dir) => {
    const next = [...list];
    const j = index + dir;
    if (j < 0 || j >= next.length) return;
    [next[index], next[j]] = [next[j], next[index]];
    setList(next);
    try {
      await api.post(`/api/admin/stories/${story.id}/episodes/reorder`, { order: next.map((e) => e.id) });
    } catch (err) { toast.error(err.message); load(); }
  };

  return (
    <Sheet open onClose={onClose} title={`Episodes · ${story.title}`} subtitle={`${list.length} episodes · upload audio, reorder, publish`}>
      {error && <div className="form-error">{error}</div>}
      {loading && <Spinner label="Loading episodes" />}

      <div className="stack" style={{ gap: 6, marginBottom: 18 }}>
        {list.map((ep, i) => (
          <div key={ep.id} className="episode" style={{ padding: '9px 10px' }}>
            <span className="episode__num">{ep.number}</span>
            <span className="episode__body">
              <span className="episode__title">{ep.title}</span>
              <span className="episode__meta">
                {clock(ep.duration)} · {ep.hasAudio ? 'audio attached' : 'no audio'} · {ep.status}
              </span>
            </span>
            <span className="row" style={{ gap: 2, flexShrink: 0 }}>
              <button type="button" className="icon-btn" style={{ width: 30, height: 30 }} onClick={() => move(i, -1)} aria-label="Move up" title="Move up">↑</button>
              <button type="button" className="icon-btn" style={{ width: 30, height: 30 }} onClick={() => move(i, 1)} aria-label="Move down" title="Move down">↓</button>
              <button type="button" className="icon-btn" style={{ width: 30, height: 30 }} onClick={() => togglePublish(ep)} aria-label="Toggle publish" title={ep.status === 'published' ? 'Unpublish' : 'Publish'}>
                {ep.status === 'published' ? <IconCheck width="14" height="14" /> : <IconX width="14" height="14" />}
              </button>
              <button type="button" className="icon-btn" style={{ width: 30, height: 30 }} onClick={() => removeEp(ep)} aria-label="Delete episode" title="Delete">
                <IconTrash width="14" height="14" />
              </button>
            </span>
          </div>
        ))}
        {!loading && list.length === 0 && <div className="tiny dim center" style={{ padding: 20 }}>No episodes yet.</div>}
      </div>

      <div style={{ borderTop: '1px solid var(--line)', paddingTop: 16 }}>
        <div className="plan-card__title" style={{ marginBottom: 10 }}>Add episode</div>
        <div className="row" style={{ gap: 10 }}>
          <div style={{ flex: 2 }}>
            <div className="field"><label htmlFor="et">Title *</label><input id="et" className="input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="The 1:07 AM Local" /></div>
          </div>
          <div style={{ flex: 1 }}>
            <div className="field"><label htmlFor="en">Episode #</label><input id="en" className="input" type="number" min="1" value={form.number} onChange={(e) => setForm({ ...form, number: e.target.value })} placeholder={String(list.length + 1)} /></div>
          </div>
        </div>
        <div className="field">
          <label htmlFor="af">Audio file (MP3) *</label>
          <input id="af" className="input" type="file" accept="audio/mpeg,audio/mp3,audio/mp4,audio/x-m4a,audio/wav" onChange={(e) => setFile(e.target.files?.[0] || null)} />
        </div>
        <button type="button" className="btn btn--primary btn--block" onClick={upload} disabled={busy}>
          <IconUpload width="15" height="15" /> {busy ? 'Uploading…' : 'Upload episode'}
        </button>
        <p className="form-note">Duration is read from the file server-side with ffprobe. Audio is served only through signed, entitlement-checked URLs.</p>
      </div>
    </Sheet>
  );
}

/* ------------------------------------------------------------- payments */
function Payments() {
  const toast = useToast();
  const [filters, setFilters] = useState({ q: '', status: '', plan: '', page: 1 });
  const [query, setQuery] = useState('');
  const { data, loading, refetch } = useApi(`/api/admin/payments?${new URLSearchParams({ ...filters, page: String(filters.page) }).toString()}`);
  const webhooks = useApi('/api/admin/webhook-events');
  const [detail, setDetail] = useState(null);

  useEffect(() => {
    const t = setTimeout(() => setFilters((f) => ({ ...f, q: query, page: 1 })), 300);
    return () => clearTimeout(t);
  }, [query]);

  return (
    <>
      <div className="row row--wrap" style={{ gap: 10, marginBottom: 14 }}>
        <div className="search-box" style={{ display: 'flex', maxWidth: 320, flex: '1 1 220px' }}>
          <IconSearch />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search tx, email, story, order id" aria-label="Search payments" />
        </div>
        <select className="input" style={{ width: 140, height: 42 }} value={filters.status} onChange={(e) => setFilters({ ...filters, status: e.target.value, page: 1 })} aria-label="Filter by status">
          <option value="">All statuses</option>
          {['paid', 'created', 'failed', 'cancelled', 'refunded'].map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <select className="input" style={{ width: 130, height: 42 }} value={filters.plan} onChange={(e) => setFilters({ ...filters, plan: e.target.value, page: 1 })} aria-label="Filter by plan">
          <option value="">All plans</option>
          {['daily', 'weekly', 'monthly'].map((p) => <option key={p} value={p}>{p}</option>)}
        </select>
        <button type="button" className="btn btn--ghost btn--sm" onClick={refetch}><IconRefresh width="14" height="14" /> Refresh</button>
      </div>

      <div className="row row--between" style={{ marginBottom: 10 }}>
        <span className="small muted">{data ? `${data.total} transactions` : 'Loading…'}</span>
        <span className="pill pill--gold">{data ? `${money(data.revenue)} matched` : ''}</span>
      </div>

      <div className="table-wrap">
        <table className="data">
          <thead>
            <tr>
              <th>Transaction</th><th>User</th><th>Story</th><th>Plan</th><th>Amount</th>
              <th>Status</th><th>Paid</th><th>Expires</th>
            </tr>
          </thead>
          <tbody>
            {loading && !data && <tr><td colSpan="8"><Spinner label="Loading" /></td></tr>}
            {data?.payments.map((p) => (
              <tr key={p.id} onClick={() => setDetail(p)} style={{ cursor: 'pointer' }}>
                <td><span className="mono">{p.id}</span></td>
                <td>{p.userEmail}</td>
                <td>{p.storyTitle}</td>
                <td style={{ textTransform: 'capitalize' }}>{p.plan}</td>
                <td className="bold">{money(p.amount)}</td>
                <td>
                  <span className={`pill ${p.status === 'paid' ? 'pill--unlocked' : p.status === 'failed' ? 'pill--trend' : p.status === 'refunded' ? 'pill--expired' : ''}`}>
                    {p.status}
                  </span>
                </td>
                <td className="tiny dim">{p.paidAt ? formatDateTime(p.paidAt) : '—'}</td>
                <td className="tiny dim">{p.expiresAt ? formatDate(p.expiresAt) : '—'}</td>
              </tr>
            ))}
            {data?.payments.length === 0 && <tr><td colSpan="8" className="center dim" style={{ padding: 30 }}>No transactions match these filters.</td></tr>}
          </tbody>
        </table>
      </div>

      {data?.hasMore && (
        <div className="load-more">
          <button type="button" className="btn btn--ghost btn--sm" onClick={() => setFilters({ ...filters, page: filters.page + 1 })}>Next page</button>
        </div>
      )}

      <div className="plan-card mt-24">
        <div className="row row--between" style={{ marginBottom: 10 }}>
          <span className="plan-card__title">Webhook events</span>
          <span className="pill">{webhooks.data?.events.length || 0}</span>
        </div>
        <p className="tiny dim" style={{ marginBottom: 10 }}>
          Every provider notification is verified against its signature and de-duplicated by event id before it can grant access.
        </p>
        <div className="stack" style={{ gap: 6 }}>
          {(webhooks.data?.events || []).slice(0, 8).map((e) => (
            <div key={e.id} className="row row--between" style={{ gap: 8, fontSize: 11.5 }}>
              <span className="mono" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '45%' }}>{e.id}</span>
              <span className={`pill ${e.result === 'entitlement_granted' ? 'pill--unlocked' : e.result?.startsWith('error') ? 'pill--trend' : ''}`}>{e.result}</span>
              <span className="dim">{timeAgo(e.receivedAt)}</span>
            </div>
          ))}
          {webhooks.data?.events.length === 0 && <span className="tiny dim">No webhook events yet.</span>}
        </div>
      </div>

      <Sheet open={Boolean(detail)} onClose={() => setDetail(null)} title="Transaction detail" subtitle={detail?.id}>
        {detail && (
          <dl className="meta-table">
            {[
              ['User', `${detail.userName} · ${detail.userEmail}`],
              ['User ID', detail.userId],
              ['Story', detail.storyTitle],
              ['Plan', detail.plan],
              ['Amount', money(detail.amount)],
              ['Status', detail.status],
              ['Provider', detail.provider],
              ['Provider order', detail.providerOrderId],
              ['Provider payment', detail.providerPaymentId || '—'],
              ['Created', formatDateTime(detail.createdAt)],
              ['Verified', detail.paidAt ? formatDateTime(detail.paidAt) : '—'],
              ['Signature verified', detail.signatureVerified ? 'yes' : 'no'],
              ['Webhook verified', detail.webhookVerified ? 'yes' : 'no'],
              ['Access expires', detail.expiresAt ? formatDateTime(detail.expiresAt) : '—'],
              ['Failure reason', detail.failureReason || '—'],
            ].map(([k, v]) => (
              <div className="meta-row" key={k}><dt>{k}</dt><dd style={{ maxWidth: '62%', wordBreak: 'break-all' }}>{v}</dd></div>
            ))}
          </dl>
        )}
      </Sheet>
    </>
  );
}

/* ---------------------------------------------------------------- users */
function Users() {
  const [q, setQ] = useState('');
  const { data, loading } = useApi(`/api/admin/users?q=${encodeURIComponent(q)}`);
  return (
    <>
      <div className="search-box" style={{ display: 'flex', maxWidth: 320, marginBottom: 14 }}>
        <IconSearch />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search users by name or email" aria-label="Search users" />
      </div>
      <div className="table-wrap">
        <table className="data">
          <thead><tr><th>User</th><th>Email</th><th>Role</th><th>Purchases</th><th>Active passes</th><th>Last active</th></tr></thead>
          <tbody>
            {loading && !data && <tr><td colSpan="6"><Spinner /></td></tr>}
            {data?.users.map((u) => (
              <tr key={u.id}>
                <td className="bold">{u.name}</td>
                <td>{u.email}</td>
                <td><span className={`pill ${u.role === 'admin' ? 'pill--gold' : ''}`}>{u.role}</span></td>
                <td>{u.purchases}</td>
                <td>{u.activePasses}</td>
                <td className="tiny dim">{timeAgo(u.lastActiveAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

/* ---------------------------------------------------------------- audit */
function Audit() {
  const { data, loading } = useApi('/api/admin/audit');
  if (loading) return <Spinner label="Loading audit log" />;
  return (
    <div className="stack" style={{ gap: 6 }}>
      {data.logs.map((l) => (
        <div key={l.id} className="row row--between" style={{ gap: 10, padding: '9px 12px', borderRadius: 10, background: 'rgba(255,255,255,0.03)', border: '1px solid var(--line)' }}>
          <span className="pill" style={{ textTransform: 'none' }}>{l.action}</span>
          <span className="tiny muted" style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis' }}>{l.actorEmail || 'system'} → {l.target}</span>
          <span className="tiny dim" style={{ flexShrink: 0 }}>{formatDateTime(l.at)}</span>
        </div>
      ))}
      {data.logs.length === 0 && <EmptyState icon={<IconShield />} title="No audit entries yet" />}
    </div>
  );
}
