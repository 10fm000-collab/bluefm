import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api } from '../lib/api.js';
import { useApi } from '../lib/store.jsx';
import { StoryCard, SkeletonCard, ErrorState, EmptyState } from '../components/Ui.jsx';
import { IconSearch, IconX, IconFilter, IconCompass } from '../components/Icons.jsx';
import { plural } from '../lib/format.js';

const SORTS = [
  { id: 'trending', label: 'Trending' },
  { id: 'popular', label: 'Most popular' },
  { id: 'latest', label: 'Latest releases' },
  { id: 'updated', label: 'Recently updated' },
  { id: 'az', label: 'A–Z' },
];

const FILTERS = [
  { id: '', label: 'All' },
  { id: 'trending', label: 'Trending now' },
  { id: 'new', label: 'New' },
  { id: 'purchased', label: 'Unlocked' },
];

export default function Explore() {
  const [params, setParams] = useSearchParams();
  const q = params.get('q') || '';
  const genre = params.get('genre') || '';
  const sort = params.get('sort') || 'trending';
  const filter = params.get('filter') || '';
  const focus = params.get('focus');

  const [input, setInput] = useState(q);
  const inputRef = useRef(null);
  const [page, setPage] = useState(1);
  const [items, setItems] = useState([]);
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggest, setShowSuggest] = useState(false);

  const { data: cats } = useApi('/api/categories');

  const query = useMemo(() => {
    const p = new URLSearchParams();
    if (q) p.set('q', q);
    if (genre) p.set('genre', genre);
    p.set('sort', sort);
    if (filter) p.set('filter', filter);
    p.set('page', String(page));
    p.set('limit', '18');
    return p.toString();
  }, [q, genre, sort, filter, page]);

  const { data, loading, error, refetch } = useApi(`/api/stories?${query}`);

  useEffect(() => { setPage(1); }, [q, genre, sort, filter]);

  useEffect(() => {
    if (!data) return;
    setItems((prev) => (page === 1 ? data.stories : [...prev, ...data.stories]));
  }, [data, page]);

  useEffect(() => {
    setInput(q);
  }, [q]);

  useEffect(() => {
    if (focus && inputRef.current) {
      inputRef.current.focus();
      const next = new URLSearchParams(params);
      next.delete('focus');
      setParams(next, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focus]);

  /* debounce search input into the URL (single source of truth) */
  useEffect(() => {
    if (input === q) return undefined;
    const t = setTimeout(() => {
      const next = new URLSearchParams(params);
      if (input.trim()) next.set('q', input.trim()); else next.delete('q');
      setParams(next, { replace: true });
    }, 320);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [input]);

  /* suggestions */
  useEffect(() => {
    if (input.trim().length < 2) { setSuggestions([]); return undefined; }
    const controller = new AbortController();
    const t = setTimeout(() => {
      api.get(`/api/search/suggest?q=${encodeURIComponent(input.trim())}`, { signal: controller.signal })
        .then((d) => setSuggestions(d.suggestions || []))
        .catch(() => {});
    }, 160);
    return () => { clearTimeout(t); controller.abort(); };
  }, [input]);

  const setParam = (key, value) => {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value); else next.delete(key);
    if (key !== 'page') next.delete('page');
    setParams(next);
  };

  const activeFilterCount = (genre ? 1 : 0) + (filter ? 1 : 0) + (sort !== 'trending' ? 1 : 0);

  return (
    <div className="page">
      <div className="page-head">
        <h1>Explore</h1>
        <p>{data ? `${data.total} ${data.total === 1 ? 'story' : 'stories'}${q ? ` for “${q}”` : ''}` : 'Find your next obsession'}</p>
      </div>

      {/* --------------------------------------------------- search */}
      <div style={{ position: 'relative', marginBottom: 14 }}>
        <div className="search-box" style={{ display: 'flex', maxWidth: '100%' }}>
          <IconSearch />
          <input
            ref={inputRef}
            type="search"
            value={input}
            onChange={(e) => { setInput(e.target.value); setShowSuggest(true); }}
            onFocus={() => setShowSuggest(true)}
            onBlur={() => setTimeout(() => setShowSuggest(false), 140)}
            placeholder="Search by title, author, genre or tag"
            aria-label="Search stories"
            enterKeyHint="search"
          />
          {input && (
            <button
              type="button"
              onClick={() => setInput('')}
              aria-label="Clear search"
              style={{ position: 'absolute', right: 8, background: 'none', border: 0, color: 'var(--text-3)', padding: 8, cursor: 'pointer' }}
            >
              <IconX width="16" height="16" />
            </button>
          )}
        </div>
        {showSuggest && suggestions.length > 0 && (
          <div
            style={{
              position: 'absolute', top: 48, left: 0, right: 0, zIndex: 30,
              background: '#101830', border: '1px solid var(--line-strong)', borderRadius: 14,
              overflow: 'hidden', boxShadow: '0 24px 50px -20px #000',
            }}
          >
            {suggestions.map((s, i) => (
              <button
                key={i}
                type="button"
                onClick={() => {
                  if (s.type === 'story') window.location.assign(`/story/${s.slug}`);
                  else setParam('genre', s.id);
                  setShowSuggest(false);
                }}
                style={{
                  display: 'flex', alignItems: 'center', gap: 10, width: '100%', padding: '10px 13px',
                  background: 'none', border: 0, borderBottom: '1px solid var(--line)',
                  color: 'var(--text)', fontSize: 13, fontWeight: 600, cursor: 'pointer', textAlign: 'left',
                }}
              >
                {s.cover ? <img src={s.cover} alt="" width="30" height="30" style={{ borderRadius: 7, objectFit: 'cover' }} /> : <IconCompass width="16" height="16" style={{ color: 'var(--blue-bright)' }} />}
                <span style={{ flex: 1 }}>{s.label}</span>
                <span className="tiny dim">{s.type === 'genre' ? 'Genre' : 'Story'}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* -------------------------------------------------- filters */}
      <div className="row row--between" style={{ marginBottom: 10 }}>
        <span className="tiny dim bold" style={{ letterSpacing: '0.08em', textTransform: 'uppercase' }}>
          <IconFilter width="13" height="13" style={{ verticalAlign: '-2px' }} /> Filters{activeFilterCount ? ` (${activeFilterCount})` : ''}
        </span>
        {activeFilterCount > 0 && (
          <button
            type="button"
            className="tiny"
            onClick={() => setParams(new URLSearchParams())}
            style={{ background: 'none', border: 0, color: 'var(--blue-bright)', fontWeight: 700, cursor: 'pointer' }}
          >
            Reset
          </button>
        )}
      </div>

      <div className="chips" style={{ marginBottom: 10 }}>
        {FILTERS.map((f) => (
          <button
            key={f.id || 'all'}
            type="button"
            className={`chip${filter === f.id ? ' active' : ''}`}
            onClick={() => setParam('filter', f.id)}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="chips" style={{ marginBottom: 10 }}>
        <button type="button" className={`chip${!genre ? ' active' : ''}`} onClick={() => setParam('genre', '')}>All genres</button>
        {(cats?.categories || []).filter((c) => c.count > 0).map((c) => (
          <button
            key={c.id}
            type="button"
            className={`chip${genre === c.id ? ' active' : ''}`}
            onClick={() => setParam('genre', genre === c.id ? '' : c.id)}
          >
            {c.name}
            <span className="tiny dim">{c.count}</span>
          </button>
        ))}
      </div>

      <div className="chips" style={{ marginBottom: 18 }}>
        {SORTS.map((s) => (
          <button
            key={s.id}
            type="button"
            className={`chip${sort === s.id ? ' active' : ''}`}
            onClick={() => setParam('sort', s.id)}
          >
            {s.label}
          </button>
        ))}
      </div>

      {/* --------------------------------------------------- results */}
      {error && <ErrorState error={error} onRetry={refetch} />}

      {!error && items.length === 0 && loading && (
        <div className="story-grid">
          {Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      )}

      {!error && items.length === 0 && !loading && (
        <EmptyState
          icon={<IconSearch />}
          title="No stories found"
          body={q ? `Nothing matched “${q}”. Try a different title, author or genre.` : 'Try removing a filter or choosing another genre.'}
          action={
            <button type="button" className="btn btn--primary btn--sm" onClick={() => setParams(new URLSearchParams())}>
              Clear all filters
            </button>
          }
        />
      )}

      <div className="story-grid">
        {items.map((s) => <StoryCard key={s.id} story={s} />)}
      </div>

      {data?.hasMore && (
        <div className="load-more">
          <button
            type="button"
            className="btn btn--ghost"
            disabled={loading}
            onClick={() => setPage((p) => p + 1)}
          >
            {loading ? 'Loading…' : 'Load more stories'}
          </button>
        </div>
      )}

      {items.length > 0 && (
        <p className="tiny dim center mt-24">
          Showing {items.length} of {data?.total || items.length} {plural(data?.total || 0, 'story').replace('storys', 'stories')}
        </p>
      )}
    </div>
  );
}
