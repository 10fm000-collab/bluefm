import React, { useEffect, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { Logo } from './Ui.jsx';
import { useAuth } from '../lib/store.jsx';
import {
  IconCompass, IconHome, IconLibrary, IconSearch, IconUser, IconShield, IconDownloadApp,
} from './Icons.jsx';
import { initials } from '../lib/format.js';

const NAV = [
  { to: '/', label: 'Home', icon: IconHome, end: true },
  { to: '/explore', label: 'Explore', icon: IconCompass },
  { to: '/library', label: 'Library', icon: IconLibrary },
  { to: '/profile', label: 'Profile', icon: IconUser },
];

export function TopBar({ onSearchFocus }) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const onExplore = location.pathname.startsWith('/explore');

  return (
    <header className={`topbar${scrolled ? ' is-scrolled' : ''}`}>
      <div className="topbar__inner">
        <Logo />
        <nav className="topnav" aria-label="Primary">
          <NavLink to="/" end>Home</NavLink>
          <NavLink to="/explore">Explore</NavLink>
          <NavLink to="/library">Library</NavLink>
          <NavLink to="/profile">Profile</NavLink>
          {user?.role === 'admin' && <NavLink to="/admin">Admin</NavLink>}
        </nav>

        <div className="search-box">
          <IconSearch />
          <input
            type="search"
            placeholder="Search stories, authors, genres"
            aria-label="Search stories"
            onFocus={() => { if (!onExplore) navigate('/explore?focus=1'); else onSearchFocus?.(); }}
            readOnly={!onExplore}
          />
        </div>

        <div className="topbar__actions">
          <Link to="/explore" className="icon-btn" aria-label="Search" style={{ display: onExplore ? 'none' : 'grid' }}>
            <IconSearch />
          </Link>
          {user?.role === 'admin' && (
            <Link to="/admin" className="icon-btn" aria-label="Admin dashboard" title="Admin dashboard">
              <IconShield />
            </Link>
          )}
          {user ? (
            <Link to="/profile" className="avatar" aria-label="Your profile">
              {initials(user.name)}
            </Link>
          ) : (
            <Link to="/signin" className="btn btn--primary btn--sm" style={{ height: 38 }}>
              Sign in
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}

export function BottomNav({ hidden }) {
  return (
    <nav className={`bottom-nav${hidden ? ' hidden' : ''}`} aria-label="Primary">
      {NAV.map(({ to, label, icon: Icon, end }) => (
        <NavLink key={to} to={to} end={end} className={({ isActive }) => (isActive ? 'active' : '')}>
          <Icon />
          <span>{label}</span>
        </NavLink>
      ))}
    </nav>
  );
}

export function InstallBanner() {
  const [evt, setEvt] = useState(null);
  const [hidden, setHidden] = useState(() => localStorage.getItem('bluefm.install.dismissed') === '1');

  useEffect(() => {
    const handler = (e) => { e.preventDefault(); setEvt(e); };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  if (!evt || hidden) return null;

  const dismiss = () => {
    localStorage.setItem('bluefm.install.dismissed', '1');
    setHidden(true);
  };

  return (
    <div className="banner-note" style={{ marginTop: 16 }}>
      <IconDownloadApp />
      <div style={{ flex: 1 }}>
        <b>Install BLUEFM</b>
        <div className="tiny dim" style={{ marginTop: 2 }}>
          Add it to your home screen for a full-screen, app-like experience.
        </div>
      </div>
      <button
        type="button"
        className="btn btn--primary btn--sm"
        onClick={async () => { evt.prompt(); const r = await evt.userChoice; if (r.outcome === 'accepted') dismiss(); else dismiss(); }}
      >
        Install
      </button>
      <button type="button" className="btn btn--ghost btn--sm" onClick={dismiss} aria-label="Dismiss">Later</button>
    </div>
  );
}

/** Scrolls to top on route change (except when a hash is present). */
export function ScrollToTop() {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) return;
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
  }, [pathname, hash]);
  return null;
}
