const S = ({ children, ...p }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
    {...p}
  >
    {children}
  </svg>
);

export const IconHome = (p) => (
  <S {...p}><path d="M3 10.5 12 3l9 7.5" /><path d="M5 9.5V21h14V9.5" /><path d="M9.5 21v-6h5v6" /></S>
);
export const IconCompass = (p) => (
  <S {...p}><circle cx="12" cy="12" r="9" /><path d="m15.5 8.5-2.2 5.3-5.3 2.2 2.2-5.3z" /></S>
);
export const IconLibrary = (p) => (
  <S {...p}><path d="M4 4h5v16H4z" /><path d="M11 4h5v16h-5z" /><path d="m18.2 4.7 3.3 14.6" /></S>
);
export const IconUser = (p) => (
  <S {...p}><circle cx="12" cy="8" r="4" /><path d="M4.5 21c1.3-4 4.1-6 7.5-6s6.2 2 7.5 6" /></S>
);
export const IconSearch = (p) => (
  <S {...p}><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></S>
);
export const IconPlay = (p) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}><path d="M8 5.5v13a1 1 0 0 0 1.53.85l10-6.5a1 1 0 0 0 0-1.7l-10-6.5A1 1 0 0 0 8 5.5Z" /></svg>
);
export const IconPause = (p) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}><rect x="6" y="5" width="4" height="14" rx="1.2" /><rect x="14" y="5" width="4" height="14" rx="1.2" /></svg>
);
export const IconNext = (p) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}><path d="M6 5.5v13a1 1 0 0 0 1.53.85L16 14v4a1 1 0 0 0 2 0V6a1 1 0 0 0-2 0v4L7.53 4.65A1 1 0 0 0 6 5.5Z" /></svg>
);
export const IconPrev = (p) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}><path d="M18 5.5v13a1 1 0 0 1-1.53.85L8 14v4a1 1 0 0 1-2 0V6a1 1 0 0 1 2 0v4l8.47-5.35A1 1 0 0 1 18 5.5Z" /></svg>
);
export const IconRewind15 = (p) => (
  <S {...p}><path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1" /><path d="M3 4v5h5" /><text x="12" y="16" fontSize="8" fontWeight="800" fill="currentColor" stroke="none" textAnchor="middle">15</text></S>
);
export const IconForward15 = (p) => (
  <S {...p}><path d="M20.5 12a8.5 8.5 0 1 1-2.6-6.1" /><path d="M21 4v5h-5" /><text x="12" y="16" fontSize="8" fontWeight="800" fill="currentColor" stroke="none" textAnchor="middle">15</text></S>
);
export const IconChevronDown = (p) => (<S {...p}><path d="m6 9 6 6 6-6" /></S>);
export const IconChevronRight = (p) => (<S {...p}><path d="m9 6 6 6-6 6" /></S>);
export const IconChevronLeft = (p) => (<S {...p}><path d="m15 6-6 6 6 6" /></S>);
export const IconArrowLeft = (p) => (<S {...p}><path d="M19 12H5" /><path d="m11 6-6 6 6 6" /></S>);
export const IconLock = (p) => (
  <S {...p}><rect x="4.5" y="10.5" width="15" height="10" rx="2.5" /><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3" /></S>
);
export const IconUnlock = (p) => (
  <S {...p}><rect x="4.5" y="10.5" width="15" height="10" rx="2.5" /><path d="M8 10.5V7.5a4 4 0 0 1 7.4-2" /></S>
);
export const IconUserCircle = IconUser;
export const IconClock = (p) => (<S {...p}><circle cx="12" cy="12" r="9" /><path d="M12 7.5V12l3 2" /></S>);
export const IconStar = (p) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}><path d="m12 3.5 2.6 5.4 5.9.8-4.3 4.2 1.05 5.9L12 17l-5.25 2.8L7.8 13.9 3.5 9.7l5.9-.8z" /></svg>
);
export const IconHeart = ({ filled, ...p }) => (
  <svg viewBox="0 0 24 24" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...p}>
    <path d="M12 20s-7.5-4.6-7.5-9.4A4.1 4.1 0 0 1 12 8a4.1 4.1 0 0 1 7.5 2.6C19.5 15.4 12 20 12 20Z" />
  </svg>
);
export const IconBell = (p) => (<S {...p}><path d="M18 8a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7" /><path d="M10.3 20a2 2 0 0 0 3.4 0" /></S>);
export const IconHeadphones = (p) => (<S {...p}><path d="M4 15v-3a8 8 0 0 1 16 0v3" /><rect x="2.5" y="14" width="4" height="7" rx="2" /><rect x="17.5" y="14" width="4" height="7" rx="2" /></S>);
export const IconList = (p) => (<S {...p}><path d="M8 6h13M8 12h13M8 18h13" /><circle cx="3.5" cy="6" r="1" fill="currentColor" /><circle cx="3.5" cy="12" r="1" fill="currentColor" /><circle cx="3.5" cy="18" r="1" fill="currentColor" /></S>);
export const IconShield = (p) => (<S {...p}><path d="M12 3 5 6v6c0 4.3 3 7.6 7 9 4-1.4 7-4.7 7-9V6l-7-3Z" /><path d="m9 12 2 2 4-4" /></S>);
export const IconBolt = (p) => (<S {...p}><path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z" /></S>);
export const IconSparkle = (p) => (
  <S {...p}><path d="M12 3v4M12 17v4M5 12H3M21 12h-2M6.3 6.3 4.9 4.9M19.1 19.1l-1.4-1.4M6.3 17.7 4.9 19.1M19.1 4.9l-1.4 1.4" /><circle cx="12" cy="12" r="3" /></S>
);
export const IconCheck = (p) => (<S {...p}><path d="m4.5 12.5 5 5 10-11" /></S>);
export const IconCheckCircle = (p) => (<S {...p}><circle cx="12" cy="12" r="9" /><path d="m8 12.5 2.5 2.5 5.5-6" /></S>);
export const IconX = (p) => (<S {...p}><path d="m6 6 12 12M18 6 6 18" /></S>);
export const IconAlert = (p) => (<S {...p}><path d="M12 3.5 2.8 19.5h18.4L12 3.5Z" /><path d="M12 9.5v4" /><circle cx="12" cy="16.6" r=".9" fill="currentColor" /></S>);
export const IconInfo = (p) => (<S {...p}><circle cx="12" cy="12" r="9" /><path d="M12 11v5" /><circle cx="12" cy="8" r=".9" fill="currentColor" /></S>);
export const IconShare = (p) => (<S {...p}><path d="M12 16V4" /><path d="m8 8 4-4 4 4" /><path d="M5 15v4a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-4" /></S>);
export const IconDownload = (p) => (<S {...p}><path d="M12 4v12" /><path d="m7 11 5 5 5-5" /><path d="M5 20h14" /></S>);
export const IconGrid = (p) => (<S {...p}><rect x="3.5" y="3.5" width="7" height="7" rx="1.6" /><rect x="13.5" y="3.5" width="7" height="7" rx="1.6" /><rect x="3.5" y="13.5" width="7" height="7" rx="1.6" /><rect x="13.5" y="13.5" width="7" height="7" rx="1.6" /></S>);
export const IconUsers = (p) => (<S {...p}><circle cx="9" cy="8" r="3.4" /><path d="M3 20c.9-3.2 3.2-4.8 6-4.8s5.1 1.6 6 4.8" /><path d="M16 5.2a3.4 3.4 0 0 1 0 6.6" /><path d="M17.5 15.4c2 .6 3.3 2.1 3.9 4.6" /></S>);
export const IconWallet = (p) => (<S {...p}><rect x="3" y="6" width="18" height="13" rx="3" /><path d="M3 10h18" /><circle cx="16.5" cy="14.5" r="1.2" fill="currentColor" /></S>);
export const IconChart = (p) => (<S {...p}><path d="M4 20V4" /><path d="M4 20h16" /><path d="M8 16v-4M12.5 16V8M17 16v-7" /></S>);
export const IconPlus = (p) => (<S {...p}><path d="M12 5v14M5 12h14" /></S>);
export const IconEdit = (p) => (<S {...p}><path d="M4 20h4l10.5-10.5a2.5 2.5 0 0 0-3.5-3.5L4.5 16.5 4 20Z" /></S>);
export const IconTrash = (p) => (<S {...p}><path d="M4 7h16" /><path d="M9 7V4.5h6V7" /><path d="M6.5 7 7.5 20h9l1-13" /><path d="M10.5 11v5M13.5 11v5" /></S>);
export const IconLogout = (p) => (<S {...p}><path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3" /><path d="M10 8l-4 4 4 4" /><path d="M6 12h9" /></S>);
export const IconSettings = (p) => (<S {...p}><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1V21a2 2 0 1 1-4 0v-.1A1.6 1.6 0 0 0 7.5 19.4l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.6 1.6 0 0 0 3 15H3a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 4.6 8.5l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.6 1.6 0 0 0 10 4.6V4a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 2.7 1.1l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0 1.1 2.7H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1.3Z" /></S>);
export const IconFilter = (p) => (<S {...p}><path d="M3 5h18l-7 8v6l-4-2v-4L3 5Z" /></S>);
export const IconBookmark = (p) => (<S {...p}><path d="M6 3.5h12v17l-6-4-6 4v-17Z" /></S>);
export const IconMicrophone = (p) => (<S {...p}><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0" /><path d="M12 18v3" /></S>);
export const IconUpload = (p) => (<S {...p}><path d="M12 16V4" /><path d="m7 9 5-5 5 5" /><path d="M5 20h14" /></S>);
export const IconRefresh = (p) => (<S {...p}><path d="M20 11a8 8 0 1 0-2.3 5.7" /><path d="M20 4v7h-7" /></S>);
export const IconVolume = (p) => (<S {...p}><path d="M11 5 6.5 9H3v6h3.5L11 19V5Z" /><path d="M15.5 9a4 4 0 0 1 0 6" /><path d="M18 6.5a8 8 0 0 1 0 11" /></S>);
export const IconPhone = (p) => (<S {...p}><rect x="7" y="2.5" width="10" height="19" rx="2.5" /><path d="M11 18.5h2" /></S>);
export const IconMail = (p) => (<S {...p}><rect x="3" y="5" width="18" height="14" rx="2.5" /><path d="m4 7 8 6 8-6" /></S>);
export const IconGoogle = (p) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" {...p}>
    <path fill="#4285F4" d="M21.6 12.2c0-.7-.06-1.4-.18-2H12v3.9h5.4a4.6 4.6 0 0 1-2 3v2.5h3.2c1.9-1.7 3-4.3 3-7.4Z" />
    <path fill="#34A853" d="M12 22c2.7 0 4.9-.9 6.6-2.4l-3.2-2.5c-.9.6-2 1-3.4 1-2.6 0-4.8-1.7-5.6-4.1H3.1v2.6A10 10 0 0 0 12 22Z" />
    <path fill="#FBBC05" d="M6.4 14a6 6 0 0 1 0-3.9V7.5H3.1a10 10 0 0 0 0 9.1L6.4 14Z" />
    <path fill="#EA4335" d="M12 5.9c1.5 0 2.8.5 3.8 1.5l2.8-2.8A10 10 0 0 0 3.1 7.5l3.3 2.6C7.2 7.6 9.4 5.9 12 5.9Z" />
  </svg>
);
export const IconSpinner = (p) => (
  <svg viewBox="0 0 24 24" aria-hidden="true" className="spin" {...p}>
    <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.5" opacity="0.2" fill="none" />
    <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="2.5" fill="none" strokeLinecap="round" />
  </svg>
);
export const IconTrend = (p) => (<S {...p}><path d="m3 17 5.5-5.5 3.5 3.5L21 6" /><path d="M15 6h6v6" /></S>);
export const IconHistory = (p) => (<S {...p}><path d="M3.5 12a8.5 8.5 0 1 0 2.9-6.4" /><path d="M3 4v5h5" /><path d="M12 8v4.5l3 1.8" /></S>);
export const IconWave = (p) => (<S {...p}><path d="M3 12h2M7 8v8M11 5v14M15 9v6M19 7v10M21.5 12h.5" /></S>);
export const IconGlobe = (p) => (<S {...p}><circle cx="12" cy="12" r="9" /><path d="M3 12h18" /><path d="M12 3c2.5 2.5 3.8 5.7 3.8 9S14.5 18.5 12 21c-2.5-2.5-3.8-5.7-3.8-9S9.5 5.5 12 3Z" /></S>);
export const IconBook = (p) => (<S {...p}><path d="M4 4.5h6a2.5 2.5 0 0 1 2 2.5v13a2 2 0 0 0-2-2H4v-13Z" /><path d="M20 4.5h-6a2.5 2.5 0 0 0-2 2.5v13a2 2 0 0 1 2-2h6v-13Z" /></S>);
export const IconDownloadApp = (p) => (<S {...p}><rect x="6" y="2.5" width="12" height="19" rx="2.5" /><path d="M12 7v6" /><path d="m9.5 10.5 2.5 2.5 2.5-2.5" /><path d="M10.5 17.5h3" /></S>);

export const GenreIcon = ({ id, ...p }) => {
  const map = {
    drama: IconBook, romance: IconHeart, thriller: IconBolt, fantasy: IconSparkle,
    comedy: IconWave, scifi: IconGlobe, mystery: IconSearch, crime: IconShield,
    motivation: IconStar, historical: IconClock,
  };
  const C = map[id] || IconHeadphones;
  return <C {...p} />;
};
