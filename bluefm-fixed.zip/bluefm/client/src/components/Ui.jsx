import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { IconChevronRight, IconHeadphones, IconLock, IconPlay, IconStar, IconUnlock } from './Icons.jsx';
import { compact } from '../lib/format.js';

/* ---------------------------------------------------------------- logo */
export function Logo({ to = '/' }) {
  return (
    <Link to={to} className="logo" aria-label="BLUEFM home">
      <span className="logo__mark" aria-hidden="true">
        <svg viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.6" strokeLinecap="round">
          <path d="M4 14v-4M8.5 18V6M13 16.5v-9M17.5 19V5M21 13.5v-3" />
        </svg>
      </span>
      <span className="logo__word">
        BLUE<span>FM</span>
      </span>
    </Link>
  );
}

/* ------------------------------------------------------------- section */
export function Section({ title, icon, action, children, href }) {
  return (
    <section className="section">
      <div className="section__head">
        <h2 className="section__title">
          {icon}
          {title}
        </h2>
        {href && (
          <Link to={href} className="section__link">
            {action || 'See all'} <IconChevronRight />
          </Link>
        )}
      </div>
      {children}
    </section>
  );
}

/* ---------------------------------------------------------- story card */
export function StoryCard({ story, priority = false }) {
  const navigate = useNavigate();
  const access = story.access?.status || 'locked';
  const locked = access !== 'active';
  const badge = story.trending ? 'trending' : story.isNew ? 'new' : null;

  return (
    <button
      type="button"
      className="story-card"
      onClick={() => navigate(`/story/${story.slug}`)}
      aria-label={`${story.title}, ${story.episodeCount} episodes, ${locked ? 'locked' : 'unlocked'}`}
    >
      <span className="story-card__art">
        <img
          src={story.cover}
          alt={story.title}
          loading={priority ? 'eager' : 'lazy'}
          decoding="async"
          width="600"
          height="900"
          fetchPriority={priority ? 'high' : 'auto'}
          style={story.lqip ? { backgroundImage: `url(${story.lqip})`, backgroundSize: 'cover' } : undefined}
        />
        <span className="story-card__badges">
          {badge === 'trending' && <span className="pill pill--trend">Trending</span>}
          {badge === 'new' && <span className="pill pill--new">New</span>}
        </span>
        {access === 'active' ? (
          <span className="story-card__unlocked pill pill--unlocked">
            <IconUnlock width="11" height="11" /> Unlocked
          </span>
        ) : access === 'expired' ? (
          <span className="story-card__unlocked pill pill--expired">Expired</span>
        ) : (
          <span className="story-card__lock" aria-hidden="true" title="Locked">
            <IconLock />
          </span>
        )}
        <span className="story-card__eps">
          <IconHeadphones width="11" height="11" style={{ display: 'inline', verticalAlign: '-1px' }} />{' '}
          {story.episodeCount} eps
        </span>
      </span>
      <span className="story-card__title">{story.title}</span>
      <span className="story-card__meta">
        <IconStar width="11" height="11" className="star" style={{ color: 'var(--gold)' }} />
        {story.rating?.toFixed(1)} <span aria-hidden="true">·</span> {compact(story.plays)} plays
      </span>
      <span className="story-card__genres">{story.genre?.[0]}</span>
    </button>
  );
}

/* ------------------------------------------------------- wide card row */
export function WideCard({ item, onPlay, cta = 'Play', sub }) {
  return (
    <div className="wide-card">
      <img className="wide-card__art" src={item.cover || item.thumb} alt="" loading="lazy" decoding="async" />
      <div className="wide-card__body">
        <div className="wide-card__title">{item.storyTitle || item.title}</div>
        <div className="wide-card__sub">
          {sub || (item.episodeTitle ? `Ep ${item.episodeNumber} · ${item.episodeTitle}` : item.author)}
        </div>
        {typeof item.percent === 'number' && item.percent > 0 && (
          <div className="wide-card__progress" aria-hidden="true">
            <i style={{ width: `${item.percent}%` }} />
          </div>
        )}
      </div>
      <button
        type="button"
        className="wide-card__play"
        onClick={onPlay}
        aria-label={`${cta} ${item.storyTitle || item.title}`}
      >
        <IconPlay />
      </button>
    </div>
  );
}

/* ------------------------------------------------------------- states */
export function Spinner({ label = 'Loading' }) {
  return (
    <div className="center" style={{ padding: '60px 0', color: 'var(--text-3)' }} role="status">
      <svg width="26" height="26" viewBox="0 0 24 24" style={{ animation: 'spin 0.9s linear infinite' }}>
        <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.4" opacity="0.2" fill="none" />
        <path d="M21 12a9 9 0 0 0-9-9" stroke="var(--blue-bright)" strokeWidth="2.4" fill="none" strokeLinecap="round" />
      </svg>
      <div className="small mt-12">{label}…</div>
      <style>{'@keyframes spin{to{transform:rotate(360deg)}}'}</style>
    </div>
  );
}

export function ErrorState({ error, onRetry }) {
  return (
    <div className="empty-state">
      <div className="empty-state__icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
          <path d="M12 3.5 2.8 19.5h18.4L12 3.5Z" /><path d="M12 9.5v4" /><circle cx="12" cy="16.6" r=".9" fill="currentColor" />
        </svg>
      </div>
      <h3>We couldn’t load this</h3>
      <p>{error?.message || 'Something went wrong. Please try again.'}</p>
      {onRetry && (
        <button type="button" className="btn btn--primary btn--sm" onClick={onRetry}>Try again</button>
      )}
    </div>
  );
}

export function EmptyState({ title, body, action, icon }) {
  return (
    <div className="empty-state">
      <div className="empty-state__icon">
        {icon || <IconHeadphones />}
      </div>
      <h3>{title}</h3>
      {body && <p>{body}</p>}
      {action}
    </div>
  );
}

export function SkeletonCard() {
  return (
    <div>
      <div className="skel skel-card" />
      <div className="skel skel-line" />
      <div className="skel skel-line short" />
    </div>
  );
}

export function SkeletonRail({ count = 6 }) {
  return (
    <div className="rail" aria-hidden="true">
      {Array.from({ length: count }).map((_, i) => <SkeletonCard key={i} />)}
    </div>
  );
}

/* -------------------------------------------------------------- sheet */
export function Sheet({ open, onClose, title, subtitle, children, labelledBy = 'sheet-title' }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return undefined;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div
      className="sheet-overlay"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      role="dialog"
      aria-modal="true"
      aria-labelledby={labelledBy}
    >
      <div className="sheet" ref={ref}>
        <div className="sheet__handle" />
        {title && <h2 className="sheet__title" id={labelledBy}>{title}</h2>}
        {subtitle && <p className="sheet__sub">{subtitle}</p>}
        {children}
      </div>
    </div>
  );
}
