import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePlayer } from '../lib/store.jsx';
import { clock } from '../lib/format.js';
import {
  IconChevronDown, IconForward15, IconList, IconNext, IconPause, IconPlay,
  IconPrev, IconRewind15, IconX, IconAlert, IconHeadphones, IconLock,
} from './Icons.jsx';

const SPEEDS = [0.75, 1, 1.25, 1.5, 2];

/* ---------------------------------------------------------- mini player */
export function MiniPlayer() {
  const p = usePlayer();
  const navigate = useNavigate();
  if (!p.track) return null;
  const { story, episode } = p.track;
  const pct = p.duration ? Math.min(100, (p.position / p.duration) * 100) : 0;

  return (
    <div className="mini-player" role="region" aria-label="Now playing">
      <div className="mini-player__progress" aria-hidden="true"><i style={{ width: `${pct}%` }} /></div>
      <img
        className="mini-player__art"
        src={story.thumb || story.cover}
        alt=""
        onClick={() => p.setExpanded(true)}
        style={{ cursor: 'pointer' }}
      />
      <button
        type="button"
        className="mini-player__body"
        onClick={() => p.setExpanded(true)}
        style={{ background: 'none', border: 0, textAlign: 'left', cursor: 'pointer', padding: 0, minWidth: 0 }}
        aria-label="Open full player"
      >
        <div className="mini-player__title">{episode.title}</div>
        <div className="mini-player__sub">{story.title} · Ep {episode.number}</div>
      </button>
      <button type="button" className="icon-btn" onClick={p.toggle} aria-label={p.playing ? 'Pause' : 'Play'}>
        {p.buffering ? <SpinnerIcon /> : p.playing ? <IconPause /> : <IconPlay />}
      </button>
      <button type="button" className="icon-btn" onClick={p.next} aria-label="Next episode" disabled={!p.hasNext}>
        <IconNext />
      </button>
      <button type="button" className="icon-btn" onClick={p.close} aria-label="Close player">
        <IconX />
      </button>
    </div>
  );
}

function SpinnerIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.4" opacity="0.25" fill="none" />
      <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="2.4" fill="none" strokeLinecap="round">
        <animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur="0.9s" repeatCount="indefinite" />
      </path>
    </svg>
  );
}

/* ------------------------------------------------------ full-screen UI */
export function FullPlayer() {
  const p = usePlayer();
  const navigate = useNavigate();
  const [showQueue, setShowQueue] = useState(false);
  const seekRef = useRef(null);
  const [scrub, setScrub] = useState(null);

  useEffect(() => {
    if (!p.expanded) return undefined;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e) => { if (e.key === 'Escape') p.setExpanded(false); };
    window.addEventListener('keydown', onKey);
    return () => { document.body.style.overflow = prev; window.removeEventListener('keydown', onKey); };
  }, [p.expanded, p]);

  if (!p.expanded || !p.track) return null;
  const { story, episode, queue = [] } = p.track;
  const dur = p.duration || episode.duration || 0;
  const pos = scrub ?? p.position;
  const pct = dur ? Math.min(100, (pos / dur) * 100) : 0;

  const onSeekInput = (e) => {
    const v = Number(e.target.value);
    setScrub(v);
  };
  const commitSeek = () => {
    if (scrub != null) { p.seek(scrub); setScrub(null); }
  };

  const goStory = () => { p.setExpanded(false); navigate(`/story/${story.slug}`); };

  return (
    <div className="player-sheet" role="dialog" aria-modal="true" aria-label="Audio player">
      <div className="player-sheet__bg" style={{ backgroundImage: `url(${story.cover})` }} />
      <div className="player-sheet__scrim" />

      <div className="player-sheet__head">
        <button type="button" className="icon-btn" onClick={() => p.setExpanded(false)} aria-label="Minimise player">
          <IconChevronDown />
        </button>
        <div className="player-sheet__eyebrow">Episode {episode.number} · Now playing</div>
        <button type="button" className="icon-btn" onClick={() => { p.close(); }} aria-label="Close player">
          <IconX />
        </button>
      </div>

      <div className="player-sheet__body">
        <div className="player-art">
          <img src={story.cover} alt={`${story.title} cover`} />
          <div className={`player-art__wave${p.playing ? '' : ' paused'}`} aria-hidden="true">
            {Array.from({ length: 6 }).map((_, i) => <i key={i} />)}
          </div>
        </div>

        <div className="player-titles">
          <h2>{episode.title}</h2>
          <button
            type="button"
            onClick={goStory}
            style={{ background: 'none', border: 0, color: 'var(--text-2)', fontSize: 12.5, fontWeight: 600, cursor: 'pointer' }}
          >
            {story.title} · {story.author}
          </button>
        </div>

        {p.error && (
          <div className="banner-note banner-note--warn" role="alert">
            <IconAlert />
            <div style={{ flex: 1 }}>
              {p.error.message}
              {(p.error.code === 'access_locked' || p.error.code === 'access_expired') && (
                <div className="mt-8">
                  <button
                    type="button"
                    className="btn btn--primary btn--sm"
                    onClick={() => { p.setExpanded(false); navigate(`/story/${story.slug}`); }}
                  >
                    <IconLock width="14" height="14" /> Unlock story
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        <div className="seek">
          <input
            ref={seekRef}
            type="range"
            min="0"
            max={Math.max(1, Math.floor(dur))}
            step="1"
            value={Math.floor(pos)}
            onChange={onSeekInput}
            onPointerUp={commitSeek}
            onKeyUp={commitSeek}
            onBlur={commitSeek}
            aria-label="Seek"
            style={{ '--fill': `${pct}%` }}
          />
          <div className="seek__times">
            <span>{clock(pos)}</span>
            <span>{dur ? clock(dur) : '--:--'}</span>
          </div>
        </div>

        <div className="player-controls">
          <button type="button" onClick={() => p.skip(-15)} aria-label="Rewind 15 seconds"><IconRewind15 /></button>
          <button type="button" onClick={p.prev} aria-label="Previous episode"><IconPrev /></button>
          <button type="button" className="is-main" onClick={p.toggle} aria-label={p.playing ? 'Pause' : 'Play'}>
            {p.buffering ? <SpinnerIcon /> : p.playing ? <IconPause /> : <IconPlay />}
          </button>
          <button type="button" onClick={p.next} aria-label="Next episode" disabled={!p.hasNext}><IconNext /></button>
          <button type="button" onClick={() => p.skip(15)} aria-label="Forward 15 seconds"><IconForward15 /></button>
        </div>

        <div className="player-extra">
          <div className="player-extra__label"><IconHeadphones /> {queue.length} episodes in this story</div>
          <div className="row" style={{ gap: 8 }}>
            <button type="button" className="speed-btn" onClick={() => {
              const idx = SPEEDS.indexOf(p.rate);
              p.setSpeed(SPEEDS[(idx + 1) % SPEEDS.length]);
            }} aria-label={`Playback speed ${p.rate}x. Change speed`}>
              {p.rate}x
            </button>
            <button
              type="button"
              className="speed-btn"
              onClick={() => setShowQueue((v) => !v)}
              style={showQueue ? { background: 'rgba(47,107,255,0.28)', borderColor: 'rgba(77,139,255,0.5)' } : undefined}
              aria-expanded={showQueue}
            >
              <IconList width="14" height="14" style={{ verticalAlign: '-2px' }} /> Episodes
            </button>
          </div>
        </div>

        {showQueue && (
          <div className="player-queue">
            {queue.map((e) => (
              <button
                key={e.id}
                type="button"
                className={`episode${e.id === episode.id ? ' is-current' : ''}`}
                onClick={() => p.play({ story, episode: e, queue, resumeAt: e.progress?.position || 0 })}
              >
                <span className="episode__num">{e.number}</span>
                <span className="episode__body">
                  <span className="episode__title">{e.title}</span>
                  <span className="episode__meta">{clock(e.duration)}{e.progress?.completed ? ' · Played' : ''}</span>
                </span>
                <span className="episode__action">
                  {e.id === episode.id && p.playing ? <IconPause width="15" height="15" /> : <IconPlay width="14" height="14" />}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
