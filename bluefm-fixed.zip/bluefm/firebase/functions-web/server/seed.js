#!/usr/bin/env node
/**
 * BLUEFM seed — builds covers, episodes and real narration audio, then inserts
 * demo content + demo accounts. Safe to re-run: use `npm run seed` (-> --reset)
 * during development, or `node server/seed.js` to top-up missing media only.
 */
import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import sharp from 'sharp';
import { config } from './config.js';
import { db, commit } from './db.js';
import { GENRES, STORIES, EPISODE_TITLES } from './catalog.js';
import { NARRATION_TEMPLATES } from './narration.js';
import { hashPassword, uid } from './lib/crypto.js';
import { iso, serverNow } from './lib/time.js';

const exec = promisify(execFile);
const RESET = process.argv.includes('--reset');

const VOICES = [
  { id: 'kavya-rao', name: 'Kavya Rao', espeak: 'en+f4', wpm: 172, pitch: 46 },
  { id: 'arjun-nair', name: 'Arjun Nair', espeak: 'en+m3', wpm: 160, pitch: 38 },
  { id: 'aditi-menon', name: 'Aditi Menon', espeak: 'en+f3', wpm: 165, pitch: 52 },
];

const log = (...a) => console.log('[seed]', ...a);

/* ------------------------------------------------------------------ covers */
async function buildCovers() {
  const variants = [
    { suffix: '', width: 600 },
    { suffix: '@2x', width: 900 },
  ];
  for (const story of STORIES) {
    const src = path.join(config.coversDir, `raw-${story.id}.jpg`);
    if (!fs.existsSync(src)) {
      log(`cover missing for ${story.id}`);
      continue;
    }
    for (const v of variants) {
      const out = path.join(config.coversDir, `${story.id}${v.suffix}.webp`);
      if (fs.existsSync(out) && !RESET) continue;
      await sharp(src)
        .resize({ width: v.width, height: Math.round(v.width * 1.5), fit: 'cover', position: 'centre' })
        .webp({ quality: 82, effort: 4 })
        .toFile(out);
    }
    // small square thumb for compact rows / player
    const thumb = path.join(config.coversDir, `${story.id}-thumb.webp`);
    if (!fs.existsSync(thumb) || RESET) {
      await sharp(src)
        .resize({ width: 240, height: 240, fit: 'cover', position: 'centre' })
        .webp({ quality: 80 })
        .toFile(thumb);
    }
    // tiny blurred placeholder (LQIP) inlined into API responses
    const lqip = await sharp(src).resize({ width: 16 }).webp({ quality: 30 }).toBuffer();
    story._lqip = `data:image/webp;base64,${lqip.toString('base64')}`;
  }
  log('covers built');
}

/* ------------------------------------------------------------------ audio */
async function voiceFor(name) {
  return VOICES.find((v) => v.name === name) || VOICES[0];
}

async function probeDuration(file) {
  const { stdout } = await exec('ffprobe', [
    '-v', 'error', '-show_entries', 'format=duration',
    '-of', 'default=noprint_wrappers=1:nokey=1', file,
  ]);
  const val = Number.parseFloat(stdout.trim());
  return Number.isFinite(val) ? Math.round(val) : 0;
}

async function buildEpisodes() {
  const episodes = [];
  const scripts = NARRATION_TEMPLATES;

  for (const story of STORIES) {
    const titles = EPISODE_TITLES[story.id] || [];
    const blocks = scripts[story.id] || [];
    const voice = await voiceFor(story.narrator);

    for (let i = 0; i < story.episodes; i += 1) {
      const episodeId = `${story.id}-e${i + 1}`;
      const outFile = path.join(config.audioDir, `${episodeId}.mp3`);
      // rotate narration blocks so every episode has speech
      const block = blocks[(i + Math.floor(i / blocks.length)) % blocks.length] || '';
      const intro = `Episode ${i + 1}. ${titles[i] || 'Untitled'}. ${story.title}, written by ${story.author}. Narrated by ${story.narrator}. `;
      const script = (intro + block).slice(0, 1500);

      if (!fs.existsSync(outFile) || RESET) {
        const wav = path.join('/tmp', `${episodeId}.wav`);
        await exec('espeak-ng', [
          '-v', voice.espeak, '-s', String(voice.wpm), '-p', String(voice.pitch),
          '-g', '8', '-a', '170', '-w', wav, script,
        ], { maxBuffer: 1024 * 1024 * 8 });

        await exec('ffmpeg', [
          '-y', '-loglevel', 'error', '-i', wav,
          // gentle night-time bed + light compression for a "produced" feel
          '-af', 'highpass=f=70,acompressor=threshold=-18dB:ratio=3:attack=8:release=180,'
               + 'aecho=0.55:0.28:520:0.16,volume=1.12,'
               + 'loudnorm=I=-18:TP=-1.5:LRA=9',
          '-codec:a', 'libmp3lame', '-b:a', '48k', '-ar', '24000', '-ac', '1',
          '-metadata', `title=${titles[i] || episodeId}`,
          '-metadata', `artist=${story.narrator}`,
          '-metadata', `album=${story.title}`,
          outFile,
        ], { maxBuffer: 1024 * 1024 * 4 });
        fs.rmSync(wav, { force: true });
      }

      const duration = await probeDuration(outFile);
      const size = fs.statSync(outFile).size;
      episodes.push({
        id: episodeId,
        storyId: story.id,
        number: i + 1,
        title: titles[i] || `Episode ${i + 1}`,
        description: block.split('. ')[0] ? `${block.split('. ')[0]}.` : `Episode ${i + 1} of ${story.title}.`,
        audioKey: `${episodeId}.mp3`,
        duration,
        bytes: size,
        narrator: story.narrator,
        publishedAt: story.publishedAt,
        status: 'published',
      });
    }
    log(`audio ready: ${story.id} (${story.episodes} episodes)`);
  }
  return episodes;
}

/* ------------------------------------------------------------------- data */
function clearTables() {
  for (const table of Object.values(db)) {
    for (const id of Object.keys(table.rows)) delete table.rows[id];
    table.invalidate();
  }
  commit();
}

async function seedData(episodes) {
  if (RESET) clearTables();

  const now = serverNow();

  // categories
  for (const g of GENRES) {
    db.categories.set(g.id, { id: g.id, ...g });
  }

  // stories
  for (const story of STORIES) {
    const storyEps = episodes.filter((e) => e.storyId === story.id);
    const totalSeconds = storyEps.reduce((s, e) => s + e.duration, 0);
    db.stories.set(story.id, {
      id: story.id,
      slug: story.slug,
      title: story.title,
      author: story.author,
      narrator: story.narrator,
      tagline: story.tagline,
      synopsis: story.synopsis,
      description: story.description,
      genre: story.genre,
      language: story.language,
      tags: story.tags,
      coverKey: `${story.id}.jpg`,
      lqip: story._lqip || '',
      rating: story.rating,
      plays: story.plays,
      featuredRank: story.featured,
      trending: story.trending,
      isNew: story.new,
      episodeCount: story.episodes,
      totalDuration: totalSeconds,
      publishedAt: story.publishedAt,
      status: 'published',
      createdAt: iso(now - 1000 * 60 * 60 * 24 * 120),
      updatedAt: iso(now - 1000 * 60 * 60 * 24 * Math.floor(Math.random() * 20)),
    });
  }

  // episodes
  for (const ep of episodes) db.episodes.set(ep.id, ep);

  // demo accounts (password: bluefm123)
  if (!db.users.findOne((u) => u.email === 'listener@bluefm.app')) {
    const pw = await hashPassword('bluefm123');
    const demoUser = {
      id: 'u_demo_listener',
      email: 'listener@bluefm.app',
      name: 'Aarav Sharma',
      passwordHash: pw,
      role: 'user',
      avatarColor: '#2f6bff',
      createdAt: iso(now - 1000 * 60 * 60 * 24 * 30),
      lastActiveAt: iso(now),
      firebaseUid: null,
      phone: null,
    };
    db.users.set(demoUser.id, demoUser);
  }

  // admin (bootstrap credentials come from env in production)
  const adminEmail = config.admin.bootstrapEmail;
  const adminPassword = config.admin.bootstrapPassword || 'bluefm-admin-2026';
  if (!db.users.findOne((u) => u.email === adminEmail)) {
    db.users.set('u_admin', {
      id: 'u_admin',
      email: adminEmail,
      name: 'BLUEFM Admin',
      passwordHash: await hashPassword(adminPassword),
      role: 'admin',
      avatarColor: '#00a3ff',
      createdAt: iso(now - 1000 * 60 * 60 * 24 * 200),
      lastActiveAt: iso(now),
      firebaseUid: null,
      phone: null,
    });
    if (!config.admin.bootstrapPassword) {
      log(`admin account created: ${adminEmail} / ${adminPassword} (set ADMIN_PASSWORD to change)`);
    }
  }

  // Give the demo listener an active weekly pass + a couple of progress rows so
  // "My Purchases" and "Continue listening" are populated on first login.
  const demo = db.users.get('u_demo_listener');
  // Document id MUST match lib/access.js `entitlementId()` or the access layer
  // will never find this row.
  const demoEntId = `ent_${demo?.id}_last-metro`;
  if (demo && !db.entitlements.has(demoEntId)) {
    const purchaseId = 'pur_demo_last_metro';
    const expires = now + 5 * 24 * 3600 * 1000;
    db.purchases.set(purchaseId, {
      id: purchaseId,
      userId: demo.id,
      storyId: 'last-metro',
      plan: 'weekly',
      amount: config.plans.weekly.amount,
      currency: 'INR',
      status: 'paid',
      provider: 'sandbox',
      providerOrderId: 'order_seed_demo_1',
      providerPaymentId: 'pay_seed_demo_1',
      createdAt: iso(now - 2 * 24 * 3600 * 1000),
      paidAt: iso(now - 2 * 24 * 3600 * 1000),
      updatedAt: iso(now - 2 * 24 * 3600 * 1000),
      verifiedAt: iso(now - 2 * 24 * 3600 * 1000),
      signatureVerified: true,
      webhookVerified: true,
    });
    db.entitlements.set(demoEntId, {
      id: demoEntId,
      userId: demo.id,
      storyId: 'last-metro',
      purchaseId,
      plan: 'weekly',
      amount: config.plans.weekly.amount,
      startsAt: iso(now - 2 * 24 * 3600 * 1000),
      expiresAt: iso(expires),
      status: 'active',
      createdAt: iso(now - 2 * 24 * 3600 * 1000),
      updatedAt: iso(now - 2 * 24 * 3600 * 1000),
      lastVerifiedAt: iso(now),
    });
    db.progress.set(`${demo.id}_last-metro-e2`, {
      id: `${demo.id}_last-metro-e2`,
      userId: demo.id,
      storyId: 'last-metro',
      episodeId: 'last-metro-e2',
      position: 12,
      duration: 0,
      completed: false,
      updatedAt: iso(now - 3600 * 1000 * 5),
    });
    db.progress.set(`${demo.id}_monsoon-hearts-e1`, {
      id: `${demo.id}_monsoon-hearts-e1`,
      userId: demo.id,
      storyId: 'monsoon-hearts',
      episodeId: 'monsoon-hearts-e1',
      position: 18,
      duration: 0,
      completed: false,
      updatedAt: iso(now - 3600 * 1000 * 26),
    });
  }

  commit();
  log(`seeded ${db.stories.count()} stories, ${db.episodes.count()} episodes, ${db.users.count()} users`);
}

/**
 * Sample listening events so the admin dashboard has a realistic 14-day trend.
 * Clearly marked as demo analytics in the UI.
 */
function seedAnalytics() {
  if (db.history.count() > 0) return;
  const users = db.users.all().filter((u) => u.role === 'user');
  const eps = db.episodes.all();
  let n = 0;
  for (let d = 0; d < 14; d += 1) {
    const dayStart = serverNow() - d * 24 * 3600 * 1000;
    const events = 6 + Math.floor(Math.random() * 14);
    for (let i = 0; i < events; i += 1) {
      const ep = eps[Math.floor(Math.random() * eps.length)];
      const u = users[Math.floor(Math.random() * Math.max(1, users.length))];
      if (!u) continue;
      n += 1;
      db.history.set(`hist_seed_${n}`, {
        id: `hist_seed_${n}`,
        userId: u.id,
        storyId: ep.storyId,
        episodeId: ep.id,
        playedSeconds: 20 + Math.floor(Math.random() * 90),
        at: iso(dayStart - Math.floor(Math.random() * 86000000)),
      });
    }
  }
  commit();
  log(`seeded ${n} listening events`);
}

async function main() {
  await buildCovers();
  const episodes = await buildEpisodes();
  await seedData(episodes);
  seedAnalytics();
  log('done');
  process.exit(0);
}

main().catch((err) => {
  console.error('[seed] failed:', err);
  process.exit(1);
});
