import crypto from 'node:crypto';
import { config } from '../config.js';
import { db } from '../db.js';
import { iso, serverNow } from '../lib/time.js';

/**
 * Payment provider abstraction.
 *
 * `sandbox`  — a real order → checkout → server-verify → webhook flow with
 *              cryptographic signatures, so every security control is exercised.
 *              No money moves. The UI labels it "Test mode".
 * `razorpay` — production adapter. Requires RAZORPAY_KEY_ID / KEY_SECRET /
 *              WEBHOOK_SECRET and a merchant account approved for ₹1 payments.
 */

const SANDBOX_KEY = crypto.createHash('sha256').update(config.session.secret).digest('hex').slice(0, 24);

function sandboxSign(orderId, paymentId) {
  return crypto
    .createHmac('sha256', `${config.session.secret}:sandbox`)
    .update(`${orderId}|${paymentId}`)
    .digest('hex');
}

export const sandboxProvider = {
  id: 'sandbox',
  label: 'BLUEFM Sandbox (test mode)',
  enabled: true,

  async createOrder({ amount, currency, receipt, notes }) {
    const orderId = `order_sbx_${crypto.randomBytes(8).toString('hex')}`;
    return {
      orderId,
      amount,
      currency,
      receipt,
      notes,
      checkout: {
        kind: 'sandbox',
        orderId,
        amount,
        currency,
        keyId: SANDBOX_KEY,
      },
    };
  },

  /** Simulates the gateway calling back the client with a signature. */
  sandboxSignature(orderId, paymentId) {
    return sandboxSign(orderId, paymentId);
  },

  async verifyPayment({ orderId, paymentId, signature }) {
    if (!orderId || !paymentId || !signature) {
      return { ok: false, reason: 'missing_fields' };
    }
    const expected = sandboxSign(orderId, paymentId);
    const a = Buffer.from(String(signature));
    const b = Buffer.from(expected);
    const ok = a.length === b.length && crypto.timingSafeEqual(a, b);
    return ok ? { ok: true, paymentId } : { ok: false, reason: 'signature_mismatch' };
  },

  /** Raw-body HMAC verification, constant-time. */
  verifyWebhook(rawBody, headers) {
    const sig = headers['x-sandbox-signature'];
    if (!sig) return { ok: false, reason: 'missing_signature' };
    const expected = crypto
      .createHmac('sha256', `${config.session.secret}:webhook`)
      .update(rawBody)
      .digest('hex');
    const a = Buffer.from(String(sig));
    const b = Buffer.from(expected);
    return a.length === b.length && crypto.timingSafeEqual(a, b)
      ? { ok: true }
      : { ok: false, reason: 'bad_signature' };
  },

  signWebhook(rawBody) {
    return crypto
      .createHmac('sha256', `${config.session.secret}:webhook`)
      .update(rawBody)
      .digest('hex');
  },
};


/**
 * Cashfree Payments (Orders API v2025-01-01).
 *
 * Mirrors the scheme already used in your Firebase functions:
 *   create order -> return payment_session_id -> client opens Cashfree Checkout
 *   -> server calls GET /orders/{id} and only grants access when
 *      order_status === "PAID" (never trusts the client).
 *   Webhook: x-webhook-signature = base64(HMAC-SHA256(clientSecret, `${ts}.${rawBody}`))
 *
 * Env: CASHFREE_CLIENT_ID, CASHFREE_CLIENT_SECRET, CASHFREE_ENV=sandbox|production
 */
export const cashfreeProvider = {
  id: 'cashfree',
  label: 'Cashfree',
  get enabled() {
    return Boolean(config.payment.cashfree.clientId && config.payment.cashfree.clientSecret);
  },
  get baseUrl() {
    // CASHFREE_BASE_URL exists so the integration test can point at a local
    // mock; production/sandbox behaviour is unchanged.
    if (process.env.CASHFREE_BASE_URL) return process.env.CASHFREE_BASE_URL.replace(/\/$/, '');
    return config.payment.cashfree.env === 'production'
      ? 'https://api.cashfree.com/pg'
      : 'https://sandbox.cashfree.com/pg';
  },
  headers() {
    const { clientId, clientSecret } = config.payment.cashfree;
    if (!clientId || !clientSecret) {
      throw new Error('Cashfree keys missing (CASHFREE_CLIENT_ID / CASHFREE_CLIENT_SECRET).');
    }
    return {
      'content-type': 'application/json',
      'x-api-version': '2025-01-01',
      'x-client-id': clientId,
      'x-client-secret': clientSecret,
    };
  },

  async createOrder({ amount, currency, receipt, notes }) {
    const body = {
      order_id: receipt,
      order_amount: amount / 100,          // Cashfree wants rupees
      order_currency: currency,
      customer_details: {
        customer_id: notes.userId,
        customer_email: notes.email || 'na@example.com',
        customer_phone: notes.phone,
      },
      order_meta: {
        return_url: `${config.appUrl}/payment/return?order_id={order_id}`,
        notify_url: process.env.CASHFREE_NOTIFY_URL || `${config.appUrl}/api/payments/webhooks/cashfree`,
      },
      order_note: `BLUEFM ${config.plans[notes.plan]?.label || notes.plan} · ${notes.storyId}`,
    };
    const r = await fetch(`${this.baseUrl}/orders`, {
      method: 'POST', headers: this.headers(), body: JSON.stringify(body),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) {
      throw new Error(`Cashfree order failed (${r.status}): ${j.message || JSON.stringify(j).slice(0, 200)}`);
    }
    return {
      orderId: j.order_id || receipt,
      amount: Math.round(Number(j.order_amount || amount / 100) * 100),
      currency: j.order_currency || currency,
      receipt,
      notes,
      checkout: {
        kind: 'cashfree',
        orderId: j.order_id || receipt,
        paymentSessionId: j.payment_session_id,
        env: config.payment.cashfree.env,
      },
    };
  },

  /** Trusted server-side status check — the source of truth for access. */
  async verifyPayment({ orderId }) {
    if (!orderId) return { ok: false, reason: 'missing_order' };
    const r = await fetch(`${this.baseUrl}/orders/${encodeURIComponent(orderId)}`, {
      method: 'GET', headers: this.headers(),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return { ok: false, reason: `lookup_failed_${r.status}` };
    const status = String(j.order_status || '').toUpperCase();
    if (status !== 'PAID') return { ok: false, reason: `order_status_${status || 'unknown'}` };
    return { ok: true, paymentId: null, orderStatus: status, amount: Math.round(Number(j.order_amount || 0) * 100) };
  },

  verifyWebhook(rawBody, headers) {
    const ts = headers['x-webhook-timestamp'];
    const sig = headers['x-webhook-signature'];
    const secret = config.payment.cashfree.clientSecret;
    if (!ts || !sig || !secret) return { ok: false, reason: 'missing_signature' };
    const expected = crypto
      .createHmac('sha256', secret)
      .update(`${ts}.${rawBody.toString('utf8')}`)
      .digest('base64');
    const a = Buffer.from(expected);
    const b = Buffer.from(String(sig));
    return a.length === b.length && crypto.timingSafeEqual(a, b)
      ? { ok: true }
      : { ok: false, reason: 'bad_signature' };
  },
};

export const razorpayProvider = {
  id: 'razorpay',
  label: 'Razorpay',
  enabled: Boolean(config.payment.razorpay.keyId && config.payment.razorpay.keySecret),

  async createOrder({ amount, currency, receipt, notes }) {
    if (!this.enabled) throw new Error('Razorpay is not configured (RAZORPAY_KEY_ID/KEY_SECRET missing).');
    const auth = Buffer.from(
      `${config.payment.razorpay.keyId}:${config.payment.razorpay.keySecret}`,
    ).toString('base64');
    const resp = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: { Authorization: `Basic ${auth}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount, currency, receipt, notes }),
    });
    if (!resp.ok) {
      const text = await resp.text();
      throw new Error(`Razorpay order failed (${resp.status}): ${text.slice(0, 300)}`);
    }
    const order = await resp.json();
    return {
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      receipt,
      notes,
      checkout: {
        kind: 'razorpay',
        orderId: order.id,
        amount: order.amount,
        currency: order.currency,
        keyId: config.payment.razorpay.keyId,
      },
    };
  },

  async verifyPayment({ orderId, paymentId, signature }) {
    const expected = crypto
      .createHmac('sha256', config.payment.razorpay.keySecret)
      .update(`${orderId}|${paymentId}`)
      .digest('hex');
    const a = Buffer.from(String(signature || ''));
    const b = Buffer.from(expected);
    const ok = a.length === b.length && crypto.timingSafeEqual(a, b);
    return ok ? { ok: true, paymentId } : { ok: false, reason: 'signature_mismatch' };
  },

  verifyWebhook(rawBody, headers) {
    const sig = headers['x-razorpay-signature'];
    if (!sig || !config.payment.razorpay.webhookSecret) {
      return { ok: false, reason: 'missing_signature' };
    }
    const expected = crypto
      .createHmac('sha256', config.payment.razorpay.webhookSecret)
      .update(rawBody)
      .digest('hex');
    const a = Buffer.from(String(sig));
    const b = Buffer.from(expected);
    return a.length === b.length && crypto.timingSafeEqual(a, b)
      ? { ok: true }
      : { ok: false, reason: 'bad_signature' };
  },
};

export function provider() {
  const p = config.payment.provider;
  if (p === 'cashfree') return cashfreeProvider;
  if (p === 'razorpay') return razorpayProvider;
  return sandboxProvider;
}

/**
 * Test-mode settlements are wall-clock shifted so the full lifecycle
 * (active → expired → re-purchase) can be demonstrated without waiting a day.
 * Real providers always use real time.
 */
export function planDurationMsFor(payment, planHours) {
  const accelerate = payment.provider === 'sandbox' && payment.testAccelerated;
  if (!accelerate) return planHours * 3600 * 1000;
  return Math.max(45 * 1000, Math.round((planHours * 3600 * 1000) / 600));
}
