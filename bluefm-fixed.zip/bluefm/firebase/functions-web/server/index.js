/**
 * Local bootstrap. Windows-friendly: no env-prefix syntax needed.
 *
 *   npm start            → production
 *   npm run dev          → development
 *
 * On Cloud Functions this file is never used — firebase-web/api.js builds the
 * same app from server/app.js.
 */
import { config } from './config.js';
import { createApp } from './app.js';
import { commit, initDb, driverName } from './db.js';

const app = createApp();

const server = app.listen(config.port, '0.0.0.0', async () => {
  console.log(`[bluefm] listening on 0.0.0.0:${config.port} (${config.isProd ? 'production' : 'development'})`);
  console.log(`[bluefm] payment provider: ${config.payment.provider} | db: ${driverName()}`);
  const init = await initDb();
  if (init.driver === 'firestore') console.log(`[bluefm] firestore warm: ${init.warmed} docs`);
});

function shutdown() {
  console.log('[bluefm] shutting down, flushing store…');
  commit();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

export default app;
