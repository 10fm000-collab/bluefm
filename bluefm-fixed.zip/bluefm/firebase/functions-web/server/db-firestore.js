/**
 * Firestore driver — same Table API as server/db.js.
 *
 * WHY A WARM IN-MEMORY MIRROR:
 * This app's reads are relational-ish (story → episodes, user → purchases →
 * entitlements) and the collections are small (a few hundred docs). Loading them
 * once per Cloud Functions instance keeps every handler synchronous and fast,
 * and Firestore becomes the durable source of truth:
 *
 *   read  → memory mirror (instant, no Firestore read cost)
 *   write → memory mirror + Firestore write (awaited, so it is durable)
 *
 * If a write fails the promise rejects and the caller sees the error — nothing
 * is silently lost. For a catalogue of this size this is the pragmatic choice;
 * at 100k+ docs the pattern to move to is per-request Firestore queries.
 */
/**
 * firebase-admin is imported lazily so the file driver (local dev, CI, tests)
 * never needs it installed. Cloud Functions always has it.
 */
let adminMod = null;
async function adminLib() {
  if (!adminMod) adminMod = (await import('firebase-admin')).default;
  return adminMod;
}

let appPromise = null;

/** One admin app per process; uses ADC when no service account is provided. */
async function getDb() {
  if (!appPromise) {
    appPromise = (async () => {
      const admin = await adminLib();
      if (!admin.apps.length) {
        const projectId = process.env.GCLOUD_PROJECT || process.env.FIREBASE_PROJECT_ID;
        const json = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
        admin.initializeApp({
          ...(json ? { credential: admin.credential.cert(JSON.parse(json)) } : {}),
          ...(projectId ? { projectId } : {}),
        });
      }
      // preferRest keeps the client on HTTP/JSON: fewer moving parts behind
      // strict egress rules, and it is what the cloud-parity test talks to.
      const preferRest = String(process.env.FIRESTORE_PREFER_REST || '') === 'true';
      if (preferRest) {
        const { getFirestore } = await import('firebase-admin/firestore');
        return getFirestore(admin.app(), { preferRest: true, ignoreUndefinedProperties: true });
      }
      return admin.firestore();
    })();
  }
  return appPromise;
}

export async function firestore() {
  return getDb();
}

/** Firestore rejects undefined values; strip them recursively. */
function clean(value) {
  if (Array.isArray(value)) return value.map(clean);
  if (value && typeof value === 'object' && !(value instanceof Date)) {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      if (v === undefined) continue;
      out[k] = clean(v);
    }
    return out;
  }
  return value;
}

export class FirestoreTable {
  constructor(name) {
    this.name = name;
    this.cache = new Map();
    this.loaded = false;
    this.pending = [];
  }

  /* ------------------------------------------------------------- loading */
  async load() {
    const fs = await getDb();
    const snap = await fs.collection(this.name).get();
    this.cache.clear();
    for (const doc of snap.docs) {
      this.cache.set(doc.id, { id: doc.id, ...doc.data() });
    }
    this.loaded = true;
    return this.cache.size;
  }

  async reload() {
    return this.load();
  }

  /* ------------------------------------------------------------ sync API */
  get(id) {
    const doc = this.cache.get(String(id));
    return doc ? structuredClone(doc) : null;
  }

  has(id) {
    return this.cache.has(String(id));
  }

  set(id, doc) {
    const key = String(id);
    const record = { ...doc, id: key };
    this.cache.set(key, record);
    this.enqueue('set', key, record);
    return structuredClone(record);
  }

  patch(id, partial) {
    const key = String(id);
    const current = this.cache.get(key);
    if (!current) return null;
    const next = { ...current, ...partial, id: key };
    this.cache.set(key, next);
    this.enqueue('patch', key, partial);
    return structuredClone(next);
  }

  delete(id) {
    const key = String(id);
    if (!this.cache.has(key)) return false;
    this.cache.delete(key);
    this.enqueue('delete', key, null);
    return true;
  }

  all() {
    return [...this.cache.values()].map((d) => structuredClone(d));
  }

  count() {
    return this.cache.size;
  }

  where(field, value) {
    const target = String(value);
    return this.all().filter((doc) => String(doc[field]) === target);
  }

  find(predicate) {
    return this.all().filter(predicate);
  }

  findOne(predicate) {
    for (const doc of this.cache.values()) {
      if (predicate(doc)) return structuredClone(doc);
    }
    return null;
  }

  invalidate() {
    /* no lazily built indexes here */
  }

  /**
   * Firestore writes are async but the route handlers are sync. We queue them
   * and flush on the next tick; `flush()` is awaited by initDb()'s sibling
   * helper and by the Cloud Functions wrapper before responding, so a request
   * never returns success before its write is durable.
   */
  enqueue(op, id, data) {
    this.pending.push({ op, id, data });
    if (this.pending.length === 1) {
      this.scheduled = this.scheduled || this._schedule();
    }
  }

  _schedule() {
    return Promise.resolve().then(() => this.flush());
  }

  async flush() {
    const ops = this.pending.splice(0, this.pending.length);
    this.scheduled = null;
    if (!ops.length) return;
    const fs = await getDb();
    const batch = fs.batch();
    for (const { op, id, data } of ops) {
      const ref = fs.collection(this.name).doc(id);
      if (op === 'delete') batch.delete(ref);
      else batch.set(ref, clean(data), { merge: op === 'patch' });
    }
    await batch.commit();
  }
}

/** Flush every table's queued writes. Called before a response is sent. */
export async function flushAllTables(tables) {
  await Promise.all(Object.values(tables).map((t) => (t.flush ? t.flush() : null)));
}
