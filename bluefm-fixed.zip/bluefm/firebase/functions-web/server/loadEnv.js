// Loads .env before any other module is imported (see "dev"/"start" scripts).
import './config.js';
