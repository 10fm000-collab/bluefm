import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';
import { FirestoreTable } from './db-firestore.js';

/**
 * Document store with a Firestore-shaped API.
 *
 * TWO DRIVERS, ONE API:
 *   DB_DRIVER=file       → ./data/db.json      (local dev, zero setup)
 *   DB_DRIVER=firestore  → Firestore            (Cloud Functions on Firebase)
 *
 * Why the file driver looks like Firestore: the app only ever talks to these
 * Table methods (get/set/patch/where/find/all/count), so the same routes run
 * unchanged on a laptop and on Cloud Functions. `initDb()` must be awaited once
 * before serving when the Firestore driver is selected.
 */

const DRIVER = (process.env.DB_DRIVER || 'file').toLowerCase();

/* ------------------------------------------------------------------ file */
const DB_FILE = path.join(config.dataDir, 'db.json');
const TMP_FILE = `${DB_FILE}.tmp`;
const WRITE_DEBOUNCE_MS = 40;

class Store {
  constructor() {
    this.data = {};
    this.timers = new Map();
    this.load();
  }

  load() {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf8');
      this.data = raw.trim() ? JSON.parse(raw) : {};
    }
  }

  flushAll() {
    fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
    fs.writeFileSync(TMP_FILE, JSON.stringify(this.data, null, 0));
    fs.renameSync(TMP_FILE, DB_FILE);
  }

  schedule(table) {
    if (this.timers.has(table)) return;
    this.timers.set(
      table,
      setTimeout(() => {
        this.timers.delete(table);
        try {
          this.flushAll();
        } catch (err) {
          console.error('[store] write failed', err.message);
        }
      }, WRITE_DEBOUNCE_MS),
    );
  }

  flushNow() {
    for (const t of this.timers.values()) clearTimeout(t);
    this.timers.clear();
    this.flushAll();
  }
}

export const store = DRIVER === 'file' ? new Store() : null;

export class Table {
  constructor(name) {
    this.name = name;
    if (store && !store.data[name]) store.data[name] = {};
    this.indexes = new Map();
  }

  get rows() {
    return store ? store.data[this.name] : {};
  }

  get(id) {
    const doc = this.rows[id];
    return doc ? structuredClone(doc) : null;
  }

  has(id) {
    return Boolean(this.rows[id]);
  }

  set(id, doc) {
    this.rows[id] = doc;
    store?.schedule(this.name);
    return structuredClone(doc);
  }

  patch(id, partial) {
    const current = this.rows[id];
    if (!current) return null;
    this.rows[id] = { ...current, ...partial };
    store?.schedule(this.name);
    return structuredClone(this.rows[id]);
  }

  delete(id) {
    if (!this.rows[id]) return false;
    delete this.rows[id];
    store?.schedule(this.name);
    return true;
  }

  all() {
    return Object.values(this.rows).map((d) => structuredClone(d));
  }

  count() {
    return Object.keys(this.rows).length;
  }

  _index(field) {
    if (this.indexes.has(field)) return this.indexes.get(field);
    const idx = new Map();
    for (const doc of Object.values(this.rows)) {
      const key = doc[field];
      if (key === undefined || key === null) continue;
      const k = String(key);
      if (!idx.has(k)) idx.set(k, new Set());
      idx.get(k).add(doc.id);
    }
    this.indexes.set(field, idx);
    return idx;
  }

  /** O(1) lookup on an equality field (indexes are lazily rebuilt per field). */
  where(field, value) {
    const ids = this._index(field).get(String(value));
    if (!ids) return [];
    return [...ids].map((id) => structuredClone(this.rows[id])).filter(Boolean);
  }

  find(predicate) {
    return this.all().filter(predicate);
  }

  findOne(predicate) {
    for (const doc of Object.values(this.rows)) {
      if (predicate(doc)) return structuredClone(doc);
    }
    return null;
  }

  /** invalidate lazily built indexes after schema-shifting writes */
  invalidate() {
    this.indexes.clear();
  }
}

const TABLE_NAMES = [
  'users',
  'sessions',
  'stories',
  'episodes',
  'categories',
  'purchases',
  'entitlements',
  'progress',
  'favorites',
  'history',
  'audit',
  'webhookEvents',
  'rateLimits',
];

/**
 * Firestore collection names. Defaults match the local table names exactly, so
 * the migration script and the running app can never drift apart (that drift
 * was why a migrated Firestore still rendered an empty catalogue).
 *
 * Set FIRESTORE_PREFIX=web_ to namespace them inside a shared project.
 */
export function collectionName(table) {
  const prefix = process.env.FIRESTORE_PREFIX || '';
  return prefix ? `${prefix}${table}` : table;
}

function buildTables() {
  const out = {};
  for (const name of TABLE_NAMES) {
    out[name] = DRIVER === 'firestore' ? new FirestoreTable(collectionName(name)) : new Table(name);
  }
  return out;
}

export const db = buildTables();

/**
 * Must be awaited before the app handles requests when DB_DRIVER=firestore.
 * With the file driver it is a no-op, so existing tests are unaffected.
 */
export async function initDb() {
  if (DRIVER !== 'firestore') return { driver: DRIVER, warmed: 0 };
  let warmed = 0;
  for (const name of TABLE_NAMES) {
    await db[name].load();
    warmed += db[name].count();
  }
  return { driver: DRIVER, warmed };
}

export function driverName() {
  return DRIVER;
}

export function commit() {
  store?.flushNow();
}
