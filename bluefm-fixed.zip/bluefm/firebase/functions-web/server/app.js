import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { config } from './config.js';
import { attachUser } from './lib/auth.js';
import apiRouter from './routes/index.js';
import { commit } from './db.js';

/**
 * Builds the Express app. Exported so the same app can run:
 *   • locally              → server/index.js  (node)
 *   • on Cloud Functions   → firebase-web/api.js (webApi)
 *
 * Nothing in here assumes a writable disk except the optional static client
 * build, which is skipped when it is absent (Cloud Functions).
 */
export function createApp() {
const app = express();

app.disable('x-powered-by');
app.set('trust proxy', 1);

/* --------------------------------------------------------------- headers */
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});

/* ------------------------------------------------------------ body parse */
app.use(
  express.json({
    limit: '1mb',
    verify: (req, _res, buf) => {
      // raw body kept for constant-time webhook signature verification
      if (req.originalUrl.includes('/webhooks/')) req.rawBody = buf;
    },
  }),
);

/* -------------------------------------------------------------- cookies */
app.use((req, _res, next) => {
  req.cookies = {};
  const header = req.headers.cookie;
  if (header) {
    for (const part of header.split(';')) {
      const idx = part.indexOf('=');
      if (idx === -1) continue;
      const k = part.slice(0, idx).trim();
      const v = part.slice(idx + 1).trim();
      if (k) req.cookies[k] = decodeURIComponent(v);
    }
  }
  next();
});

/* ------------------------------------------------------------------ CORS */
/**
 * The site may live on a different origin than the API (Vercel frontend +
 * Firebase functions). Credentials are allowed only for explicitly trusted
 * origins listed in ALLOWED_ORIGINS — never a wildcard with cookies.
 */
const ALLOWED_ORIGINS = String(process.env.ALLOWED_ORIGINS || '')
  .split(',').map((s) => s.trim()).filter(Boolean);

app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && (ALLOWED_ORIGINS.length === 0 || ALLOWED_ORIGINS.includes(origin))) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,PUT,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Range');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range, Accept-Ranges');
  }
  if (req.method === 'OPTIONS') return res.status(204).end();
  next();
});

app.use(attachUser);

/* ---------------------------------------------------------------- media */
// Covers are public marketing assets. Audio is NOT served from disk: it is only
// reachable through /api/playback with a server-signed, entitlement-scoped token.
app.use(
  '/media/covers',
  express.static(config.coversDir, {
    maxAge: '30d',
    immutable: true,
    setHeaders(res) {
      res.setHeader('Cache-Control', 'public, max-age=2592000, immutable');
    },
  }),
);

// Hard-stop: audio files are never served from disk by path. Even if DATA_DIR
// were misconfigured inside a static root, requests here cannot read audio.
app.use(['/media/audio', '/data/media/audio'], (_req, res) => {
  res.status(403).json({ error: 'Audio is only available through authorised playback.', code: 'direct_audio_forbidden' });
});

/* ------------------------------------------------------------------ api */
app.use('/api', apiRouter);

/* ----------------------------------------------------------------- static */
const distDir = path.join(config.root, 'dist', 'client');
if (fs.existsSync(distDir)) {
  app.use(
    express.static(distDir, {
      index: false,
      setHeaders(res, filePath) {
        if (/_assets\//.test(filePath)) {
          res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        } else if (/sw\.js$|manifest\.webmanifest$/.test(filePath)) {
          res.setHeader('Cache-Control', 'no-cache');
        }
      },
    }),
  );
}

// SPA fallback (client-side routing)
app.use((req, res, next) => {
  if (req.method !== 'GET' || req.path.startsWith('/api/')) return next();
  const index = path.join(distDir, 'index.html');
  if (fs.existsSync(index)) return res.sendFile(index);
  return next();
});

/* ------------------------------------------------------------- 404 / 500 */
app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Not found' });
  res.status(404).send('Not found');
});

app.use((err, req, res, _next) => {
  const status = err.status || 500;
  if (status >= 500) console.error('[error]', req.method, req.path, err.message);
  if (res.headersSent) return;
  res.status(status).json({
    error: status >= 500 ? 'Something went wrong on our side.' : err.message,
    code: err.code || undefined,
  });
});

  return app;
}

export default createApp;
