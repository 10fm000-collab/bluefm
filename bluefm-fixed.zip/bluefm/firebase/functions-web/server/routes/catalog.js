import { Router } from 'express';
import { db } from '../db.js';
import { accessSummaryFor, publicStory, publicEpisode, episodeOrder, progressFor, plansPublic } from '../services/catalog.js';
import { activeEntitlementMap } from '../lib/access.js';
import { config } from '../config.js';

const router = Router();

function withAccess(stories, userId) {
  const map = activeEntitlementMap(userId);
  return stories.map((s) =>
    publicStory(s, {
      access: map.get(s.id)
        ? accessSummaryFor(userId, s.id)
        : { status: accessSummaryFor(userId, s.id).status },
    }),
  );
}

const published = () => db.stories.all().filter((s) => s.status === 'published');

function categoriesWithCounts() {
  const counts = new Map();
  for (const s of published()) {
    for (const g of s.genre) counts.set(g, (counts.get(g) || 0) + 1);
  }
  return db.categories
    .all()
    .map((c) => ({ ...c, count: counts.get(c.id) || 0 }))
    .sort((a, b) => b.count - a.count);
}

router.get('/categories', (req, res) => res.json({ categories: categoriesWithCounts() }));

router.get('/plans', (_req, res) => res.json({ plans: plansPublic() }));

/** Home payload — one request instead of eight waterfalls on mobile networks. */
router.get('/home', (req, res) => {
  const user = req.user;
  const stories = published();
  const ent = activeEntitlementMap(user?.id);

  const byPlays = [...stories].sort((a, b) => b.plays - a.plays);
  const byDate = [...stories].sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt));

  const featured = stories
    .filter((s) => s.featuredRank > 0)
    .sort((a, b) => a.featuredRank - b.featuredRank)
    .slice(0, 4);

  const purchased = user ? stories.filter((s) => ent.has(s.id)) : [];

  // Continue listening: most recent progress rows for this user
  let continueListening = [];
  let recentlyPlayed = [];
  if (user) {
    const rows = db.progress
      .where('userId', user.id)
      .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    continueListening = rows
      .filter((r) => !r.completed)
      .slice(0, 6)
      .map((r) => decorateProgress(r));
    recentlyPlayed = rows.slice(0, 8).map((r) => decorateProgress(r));
  }

  res.json({
    featured: featured.map((s) => ({
      ...publicStory(s, { access: { status: ent.has(s.id) ? 'active' : 'locked' } }),
    })),
    // "Trending" = the titles currently flagged trending, topped up with the
    // most-played series so the row never looks half-empty.
    trending: withAccess(
      [...stories]
        .sort((a, b) => Number(b.trending) - Number(a.trending) || b.plays - a.plays)
        .slice(0, 6),
      user?.id,
    ),
    recentlyAdded: withAccess(byDate.slice(0, 8), user?.id),
    popular: withAccess(byPlays.slice(0, 8), user?.id),
    recommended: withAccess(recommendedFor(user, stories), user?.id),
    continueListening,
    recentlyPlayed,
    myPurchased: withAccess(purchased, user?.id),
    plans: plansPublic(),
    categories: categoriesWithCounts(),
  });
});

function recommendedFor(user, stories) {
  if (!user) return [...stories].sort((a, b) => b.rating - a.rating).slice(0, 8);
  const owned = new Set(db.entitlements.where('userId', user.id).map((e) => e.storyId));
  const likedGenres = new Set();
  for (const p of db.progress.where('userId', user.id)) {
    const st = db.stories.get(p.storyId);
    if (st) st.genre.forEach((g) => likedGenres.add(g));
  }
  for (const f of db.favorites.where('userId', user.id)) {
    const st = db.stories.get(f.storyId);
    if (st) st.genre.forEach((g) => likedGenres.add(g));
  }
  return [...stories]
    .map((s) => ({
      s,
      score:
        (likedGenres.size ? s.genre.filter((g) => likedGenres.has(g)).length * 2 : 0) +
        s.rating +
        (owned.has(s.id) ? -0.5 : 0),
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 8)
    .map((x) => x.s);
}

function decorateProgress(row) {
  const story = db.stories.get(row.storyId);
  const ep = db.episodes.get(row.episodeId);
  if (!story || !ep) return null;
  return {
    storyId: story.id,
    storyTitle: story.title,
    cover: `/media/covers/${story.id}.webp`,
    thumb: `/media/covers/${story.id}-thumb.webp`,
    episodeId: ep.id,
    episodeNumber: ep.number,
    episodeTitle: ep.title,
    episodeDuration: ep.duration,
    position: row.position,
    completed: Boolean(row.completed),
    updatedAt: row.updatedAt,
    percent: ep.duration ? Math.min(100, Math.round((row.position / ep.duration) * 100)) : 0,
  };
}

/** Explore / search / filters. Real database queries, server-side sorting. */
router.get('/stories', (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  const genres = String(req.query.genre || '').split(',').map((g) => g.trim()).filter(Boolean);
  const sort = String(req.query.sort || 'trending');
  const filter = String(req.query.filter || '');
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(48, Math.max(1, Number(req.query.limit) || 24));

  let list = published();

  if (q) {
    list = list.filter((s) => {
      const hay = [s.title, s.author, s.narrator, s.synopsis, s.tagline, ...(s.tags || []), ...(s.genre || [])]
        .join(' ')
        .toLowerCase();
      return hay.includes(q);
    });
  }
  if (genres.length) list = list.filter((s) => s.genre.some((g) => genres.includes(g)));
  if (filter === 'new') list = list.filter((s) => s.isNew);
  if (filter === 'trending') list = list.filter((s) => s.trending);
  if (filter === 'purchased') {
    const map = activeEntitlementMap(req.user?.id);
    list = list.filter((s) => map.has(s.id));
  }

  const sorters = {
    trending: (a, b) => b.plays - a.plays,
    popular: (a, b) => b.rating - a.rating || b.plays - a.plays,
    latest: (a, b) => new Date(b.publishedAt) - new Date(a.publishedAt),
    updated: (a, b) => new Date(b.updatedAt) - new Date(a.updatedAt),
    az: (a, b) => a.title.localeCompare(b.title),
  };
  list.sort(sorters[sort] || sorters.trending);

  const total = list.length;
  const slice = list.slice((page - 1) * limit, page * limit);

  res.json({
    stories: withAccess(slice, req.user?.id),
    total,
    page,
    limit,
    hasMore: page * limit < total,
    query: { q, genres, sort, filter },
  });
});

/** Search suggestions (story titles + genres + authors). */
router.get('/search/suggest', (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  if (q.length < 2) return res.json({ suggestions: [] });
  const seen = new Set();
  const out = [];
  for (const s of published()) {
    if (s.title.toLowerCase().includes(q) && !seen.has(s.title)) {
      seen.add(s.title);
      out.push({ type: 'story', label: s.title, slug: s.slug, cover: `/media/covers/${s.id}-thumb.webp` });
    }
  }
  for (const c of db.categories.all()) {
    if (c.name.toLowerCase().includes(q) && !seen.has(c.name)) {
      seen.add(c.name);
      out.push({ type: 'genre', label: c.name, id: c.id });
    }
  }
  res.json({ suggestions: out.slice(0, 8) });
});

/** Story detail + episode list (episode metadata is public, audio is not). */
router.get('/stories/:slug', (req, res) => {
  const story = db.stories.findOne((s) => s.slug === req.params.slug && s.status === 'published');
  if (!story) return res.status(404).json({ error: 'Story not found' });
  const access = accessSummaryFor(req.user?.id, story.id);
  const eps = episodeOrder(story.id);
  const progress = progressFor(req.user?.id, story.id);
  const unlocked = access.status === 'active';

  const related = published()
    .filter((s) => s.id !== story.id && s.genre.some((g) => story.genre.includes(g)))
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 6);

  const favorite = req.user
    ? Boolean(db.favorites.get(`fav_${req.user.id}_${story.id}`))
    : false;

  res.json({
    story: publicStory(story, { access }),
    episodes: eps.map((e) =>
      publicEpisode(e, { unlocked, progress: progress.get(e.id) || null }),
    ),
    plans: plansPublic(),
    related: withAccess(related, req.user?.id),
    favorite,
    purchase: req.user ? latestPurchase(req.user.id, story.id) : null,
  });
});

function latestPurchase(userId, storyId) {
  const rows = db.purchases
    .where('userId', userId)
    .filter((p) => p.storyId === storyId)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const p = rows[0];
  if (!p) return null;
  return {
    id: p.id,
    plan: p.plan,
    amount: p.amount,
    currency: p.currency,
    status: p.status,
    createdAt: p.createdAt,
    paidAt: p.paidAt,
  };
}

export default router;
