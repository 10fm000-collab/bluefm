import { Router } from 'express';
import multer from 'multer';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
import { execFile } from 'node:child_process';
/**
 * sharp is a native module. It is loaded lazily so the API still boots on
 * Cloud Functions (where we skip it to keep the bundle small) — only the cover
 * processing route degrades, with a clear error instead of a crash.
 */
let sharpMod = null;
async function getSharp() {
  if (!sharpMod) sharpMod = (await import('sharp')).default;
  return sharpMod;
}
import { config } from '../config.js';
import { db } from '../db.js';
import { requireAdmin, publicUser } from '../lib/auth.js';
import { rateLimit } from '../lib/rateLimit.js';
import { iso, serverNow, DAY } from '../lib/time.js';
import { uid } from '../lib/crypto.js';
import { planPublic } from '../services/catalog.js';
import { b2Configured, uploadFromPath } from '../lib/b2.js';

const router = Router();
const exec = promisify(execFile);

router.use(requireAdmin);
router.use(rateLimit('write', config.limits.write));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 40 * 1024 * 1024 },
});

function auditLog(req, action, target, meta = {}) {
  db.audit.set(uid('aud_'), {
    id: uid('aud_'),
    actorId: req.user.id,
    actorEmail: req.user.email,
    action,
    target,
    meta,
    at: iso(),
  });
}

const startOfDay = (ms) => {
  const d = new Date(ms);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
};

/* ------------------------------------------------------------- dashboard */
router.get('/stats', (req, res) => {
  const now = serverNow();
  const users = db.users.all().filter((u) => u.role === 'user');
  const purchases = db.purchases.all();
  const paid = purchases.filter((p) => p.status === 'paid');
  const ents = db.entitlements.all();
  const active = ents.filter((e) => e.status === 'active' && Date.parse(e.expiresAt) > now);
  const expired = ents.filter((e) => e.status !== 'active' || Date.parse(e.expiresAt) <= now);

  const sum = (rows) => rows.reduce((s, p) => s + p.amount, 0);
  const today = startOfDay(now);
  const weekAgo = now - 7 * DAY;
  const monthAgo = now - 30 * DAY;

  const dailyActive = new Set(
    db.history.all().filter((h) => Date.parse(h.at) >= now - DAY).map((h) => h.userId),
  ).size;
  const dau = new Set(db.history.all().filter((h) => Date.parse(h.at) >= today).map((h) => h.userId)).size;

  // revenue trend, last 14 days
  const trend = [];
  for (let i = 13; i >= 0; i -= 1) {
    const dayEnd = startOfDay(now - i * DAY) + DAY;
    const dayStart = dayEnd - DAY;
    const rows = paid.filter((p) => {
      const t = Date.parse(p.paidAt || p.createdAt);
      return t >= dayStart && t < dayEnd;
    });
    trend.push({
      date: new Date(dayStart).toISOString().slice(0, 10),
      revenue: sum(rows),
      purchases: rows.length,
    });
  }

  const perStory = new Map();
  for (const p of paid) {
    const row = perStory.get(p.storyId) || { purchases: 0, revenue: 0 };
    row.purchases += 1;
    row.revenue += p.amount;
    perStory.set(p.storyId, row);
  }
  const topStories = [...perStory.entries()]
    .map(([storyId, v]) => ({
      storyId,
      title: db.stories.get(storyId)?.title || storyId,
      cover: `/media/covers/${storyId}-thumb.webp`,
      ...v,
    }))
    .sort((a, b) => b.purchases - a.purchases)
    .slice(0, 6);

  const listensByStory = new Map();
  for (const h of db.history.all()) {
    listensByStory.set(h.storyId, (listensByStory.get(h.storyId) || 0) + 1);
  }
  const topListened = [...listensByStory.entries()]
    .map(([storyId, listens]) => ({
      storyId,
      title: db.stories.get(storyId)?.title || storyId,
      cover: `/media/covers/${storyId}-thumb.webp`,
      listens,
    }))
    .sort((a, b) => b.listens - a.listens)
    .slice(0, 6);

  const planMix = Object.fromEntries(
    Object.keys(config.plans).map((id) => [id, paid.filter((p) => p.plan === id).length]),
  );

  res.json({
    currency: 'INR',
    totals: {
      users: users.length,
      activeToday: dailyActive || dau,
      purchases: paid.length,
      revenue: sum(paid),
      revenueToday: sum(paid.filter((p) => Date.parse(p.paidAt || p.createdAt) >= today)),
      revenueWeek: sum(paid.filter((p) => Date.parse(p.paidAt || p.createdAt) >= weekAgo)),
      revenueMonth: sum(paid.filter((p) => Date.parse(p.paidAt || p.createdAt) >= monthAgo)),
      activePasses: active.length,
      expiredPasses: expired.length,
      stories: db.stories.count(),
      episodes: db.episodes.count(),
      listens: db.history.count(),
    },
    trend,
    topStories,
    topListened,
    planMix,
    demoAnalytics: db.history.all().some((h) => String(h.id).startsWith('hist_seed_')),
  });
});

/* --------------------------------------------------------------- stories */
router.get('/stories', (_req, res) => {
  const stories = db.stories.all().map((s) => ({
    id: s.id, slug: s.slug, title: s.title, author: s.author, genre: s.genre,
    status: s.status, featuredRank: s.featuredRank, trending: s.trending, isNew: s.isNew,
    episodeCount: db.episodes.where('storyId', s.id).filter((e) => e.status === 'published').length,
    cover: `/media/covers/${s.id}-thumb.webp`,
    publishedAt: s.publishedAt, updatedAt: s.updatedAt,
  }));
  res.json({ stories: stories.sort((a, b) => a.title.localeCompare(b.title)) });
});

const slugify = (v) =>
  String(v).toLowerCase().trim().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').slice(0, 60);

router.post('/stories', upload.single('cover'), async (req, res, next) => {
  try {
    const b = req.body || {};
    const title = String(b.title || '').trim();
    if (title.length < 2) return res.status(400).json({ error: 'Title is required.' });
    const id = slugify(b.id || title);
    if (!id) return res.status(400).json({ error: 'Could not derive a story id from the title.' });
    if (db.stories.has(id)) return res.status(409).json({ error: 'A story with this id already exists.' });

    let coverFile = null;
    if (req.file) coverFile = await saveCover(id, req.file.buffer);

    const genre = Array.isArray(b.genre) ? b.genre : String(b.genre || '').split(',').map((g) => g.trim()).filter(Boolean);
    const story = {
      id,
      slug: slugify(b.slug || title),
      title,
      author: String(b.author || 'BLUEFM Studios').trim(),
      narrator: String(b.narrator || 'BLUEFM Narrator').trim(),
      tagline: String(b.tagline || '').trim(),
      synopsis: String(b.synopsis || '').trim(),
      description: String(b.description || b.synopsis || '').trim(),
      genre: genre.length ? genre : ['drama'],
      language: String(b.language || 'Hindi + English'),
      tags: String(b.tags || '').split(',').map((t) => t.trim()).filter(Boolean),
      coverKey: coverFile ? `${id}.jpg` : null,
      lqip: '',
      rating: Number(b.rating) || 4.5,
      plays: 0,
      featuredRank: Number(b.featuredRank) || 0,
      trending: b.trending === 'true' || b.trending === true,
      isNew: true,
      episodeCount: 0,
      totalDuration: 0,
      publishedAt: b.publishedAt || new Date().toISOString().slice(0, 10),
      status: b.status === 'draft' ? 'draft' : 'published',
      createdAt: iso(),
      updatedAt: iso(),
    };
    db.stories.set(id, story);
    auditLog(req, 'story.created', id, { title, status: story.status });
    res.status(201).json({ story: story });
  } catch (err) { next(err); }
});

router.patch('/stories/:id', upload.single('cover'), async (req, res, next) => {
  try {
    const story = db.stories.get(req.params.id);
    if (!story) return res.status(404).json({ error: 'Story not found' });
    const b = req.body || {};
    const patch = {};
    for (const key of ['title', 'author', 'narrator', 'tagline', 'synopsis', 'description', 'language', 'publishedAt', 'status', 'slug']) {
      if (b[key] !== undefined) patch[key] = String(b[key]).trim();
    }
    if (b.genre !== undefined) {
      patch.genre = Array.isArray(b.genre)
        ? b.genre
        : String(b.genre).split(',').map((g) => g.trim()).filter(Boolean);
    }
    if (b.tags !== undefined) {
      patch.tags = String(b.tags).split(',').map((t) => t.trim()).filter(Boolean);
    }
    if (b.rating !== undefined) patch.rating = Number(b.rating) || story.rating;
    if (b.featuredRank !== undefined) patch.featuredRank = Number(b.featuredRank) || 0;
    if (b.trending !== undefined) patch.trending = b.trending === 'true' || b.trending === true;
    if (b.isNew !== undefined) patch.isNew = b.isNew === 'true' || b.isNew === true;
    if (req.file) {
      patch.coverKey = await saveCover(story.id, req.file.buffer);
    }
    patch.updatedAt = iso();
    const updated = db.stories.patch(story.id, patch);
    auditLog(req, 'story.updated', story.id, { fields: Object.keys(patch) });
    res.json({ story: updated });
  } catch (err) { next(err); }
});

router.delete('/stories/:id', (req, res) => {
  const story = db.stories.get(req.params.id);
  if (!story) return res.status(404).json({ error: 'Story not found' });
  const eps = db.episodes.where('storyId', story.id);
  const hasPaid = db.purchases.findOne((p) => p.storyId === story.id && p.status === 'paid');
  if (hasPaid && req.query.force !== 'true') {
    return res.status(409).json({
      error: 'This story has paid purchases. Archive it instead (status=draft) or pass force=true to delete content while keeping transactions.',
      code: 'has_purchases',
    });
  }
  for (const ep of eps) db.episodes.delete(ep.id);
  db.stories.delete(story.id);
  auditLog(req, 'story.deleted', story.id, { episodes: eps.length, forced: req.query.force === 'true' });
  res.json({ ok: true, deletedEpisodes: eps.length });
});

async function saveCover(id, buffer) {
  const sharp = await getSharp();
  const meta = await sharp(buffer).metadata();
  if (!meta.format || !['jpeg', 'png', 'webp'].includes(meta.format)) {
    const err = new Error('Cover must be a JPEG, PNG or WebP image.');
    err.status = 400;
    throw err;
  }
  const src = path.join(config.coversDir, `raw-${id}.${meta.format}`);
  fs.writeFileSync(src, buffer);
  for (const [suffix, width] of [['', 600], ['@2x', 900]]) {
    await sharp(buffer)
      .resize({ width, height: Math.round(width * 1.5), fit: 'cover' })
      .webp({ quality: 82 })
      .toFile(path.join(config.coversDir, `${id}${suffix}.webp`));
  }
  await sharp(buffer).resize({ width: 240, height: 240, fit: 'cover' }).webp({ quality: 80 })
    .toFile(path.join(config.coversDir, `${id}-thumb.webp`));
  const lqip = await sharp(buffer).resize({ width: 16 }).webp({ quality: 30 }).toBuffer();
  db.stories.patch(id, { lqip: `data:image/webp;base64,${lqip.toString('base64')}` });
  return `${id}.jpg`;
}

/* -------------------------------------------------------------- episodes */
router.get('/stories/:id/episodes', (req, res) => {
  const story = db.stories.get(req.params.id);
  if (!story) return res.status(404).json({ error: 'Story not found' });
  const eps = db.episodes
    .where('storyId', story.id)
    .sort((a, b) => a.number - b.number);
  res.json({ episodes: eps.map(({ audioKey, ...rest }) => ({ ...rest, hasAudio: Boolean(audioKey) })) });
});

router.post('/stories/:id/episodes', upload.single('audio'), async (req, res, next) => {
  try {
    const story = db.stories.get(req.params.id);
    if (!story) return res.status(404).json({ error: 'Story not found' });
    const b = req.body || {};
    const title = String(b.title || '').trim();
    if (!title) return res.status(400).json({ error: 'Episode title is required.' });
    if (!req.file) return res.status(400).json({ error: 'An audio file (MP3) is required.' });

    const eps = db.episodes.where('storyId', story.id);
    const number = Number(b.number) || eps.length + 1;
    const id = `${story.id}-e${number}-${Math.random().toString(36).slice(2, 6)}`;
    const { duration, key } = await saveAudio(id, req.file.buffer);

    const ep = {
      id,
      storyId: story.id,
      number,
      title,
      description: String(b.description || '').trim(),
      audioKey: key,
      duration,
      bytes: req.file.size,
      narrator: String(b.narrator || story.narrator),
      publishedAt: b.publishedAt || new Date().toISOString().slice(0, 10),
      status: b.status === 'draft' ? 'draft' : 'published',
      createdAt: iso(),
    };
    db.episodes.set(id, ep);

    const publishedEps = db.episodes.where('storyId', story.id).filter((e) => e.status === 'published');
    db.stories.patch(story.id, {
      episodeCount: publishedEps.length,
      totalDuration: publishedEps.reduce((s, e) => s + e.duration, 0),
      updatedAt: iso(),
    });
    auditLog(req, 'episode.created', id, { storyId: story.id, number, duration });
    const { audioKey, ...safe } = ep;
    res.status(201).json({ episode: safe });
  } catch (err) { next(err); }
});

router.patch('/episodes/:id', upload.single('audio'), async (req, res, next) => {
  try {
    const ep = db.episodes.get(req.params.id);
    if (!ep) return res.status(404).json({ error: 'Episode not found' });
    const b = req.body || {};
    const patch = {};
    if (b.title !== undefined) patch.title = String(b.title).trim();
    if (b.description !== undefined) patch.description = String(b.description).trim();
    if (b.number !== undefined) patch.number = Number(b.number) || ep.number;
    if (b.status !== undefined) patch.status = b.status === 'draft' ? 'draft' : 'published';
    if (b.narrator !== undefined) patch.narrator = String(b.narrator);
    if (b.publishedAt !== undefined) patch.publishedAt = String(b.publishedAt);
    if (req.file) {
      const { duration, key } = await saveAudio(ep.id, req.file.buffer);
      patch.duration = duration;
      patch.audioKey = key;
      patch.bytes = req.file.size;
    }
    const updated = db.episodes.patch(ep.id, patch);
    const publishedEps = db.episodes.where('storyId', ep.storyId).filter((e) => e.status === 'published');
    db.stories.patch(ep.storyId, {
      episodeCount: publishedEps.length,
      totalDuration: publishedEps.reduce((s, e) => s + e.duration, 0),
      updatedAt: iso(),
    });
    auditLog(req, 'episode.updated', ep.id, { fields: Object.keys(patch) });
    const { audioKey, ...safe } = updated;
    res.json({ episode: safe });
  } catch (err) { next(err); }
});

router.delete('/episodes/:id', (req, res) => {
  const ep = db.episodes.get(req.params.id);
  if (!ep) return res.status(404).json({ error: 'Episode not found' });
  db.episodes.delete(ep.id);
  const file = path.join(config.audioDir, path.basename(ep.audioKey || ''));
  if (ep.audioKey && fs.existsSync(file)) fs.rmSync(file, { force: true });
  const publishedEps = db.episodes.where('storyId', ep.storyId).filter((e) => e.status === 'published');
  db.stories.patch(ep.storyId, {
    episodeCount: publishedEps.length,
    totalDuration: publishedEps.reduce((s, e) => s + e.duration, 0),
  });
  auditLog(req, 'episode.deleted', ep.id, { storyId: ep.storyId });
  res.json({ ok: true });
});

/** Reorder: array of episode ids in the desired order. */
router.post('/stories/:id/episodes/reorder', (req, res) => {
  const story = db.stories.get(req.params.id);
  if (!story) return res.status(404).json({ error: 'Story not found' });
  const ids = Array.isArray(req.body?.order) ? req.body.order : [];
  const existing = new Set(db.episodes.where('storyId', story.id).map((e) => e.id));
  if (!ids.length || ids.some((id) => !existing.has(id))) {
    return res.status(400).json({ error: 'Order must contain every episode id of this story.' });
  }
  ids.forEach((id, idx) => db.episodes.patch(id, { number: idx + 1 }));
  auditLog(req, 'episode.reordered', story.id, { order: ids });
  res.json({ ok: true });
});

async function saveAudio(id, buffer) {
  const tmp = path.join('/tmp', `${id}-upload.mp3`);
  fs.writeFileSync(tmp, buffer);
  try {
    const { stdout } = await exec('ffprobe', [
      '-v', 'error', '-show_entries', 'format=duration',
      '-of', 'default=noprint_wrappers=1:nokey=1', tmp,
    ]);
    const duration = Math.round(Number.parseFloat(stdout.trim()));
    if (!Number.isFinite(duration) || duration <= 0) {
      const err = new Error('Could not read audio duration. Upload a valid MP3/M4A file.');
      err.status = 400;
      throw err;
    }
    const key = `${id}.mp3`;
    const localPath = path.join(config.audioDir, key);
    fs.copyFileSync(tmp, localPath);

    // Mirror to B2 when configured. A failed upload must not lose the episode:
    // the local copy stays and playback falls back to the guarded proxy.
    if (config.audio.storageDriver === 'b2' && b2Configured()) {
      try {
        await uploadFromPath(key, localPath);
      } catch (err) {
        console.warn('[admin] B2 upload failed, episode kept locally:', err.message);
      }
    }
    return { duration, key };
  } finally {
    fs.rmSync(tmp, { force: true });
  }
}

/* ---------------------------------------------------------- transactions */
router.get('/payments', (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase();
  const status = String(req.query.status || '');
  const plan = String(req.query.plan || '');
  const storyId = String(req.query.storyId || '');
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Number(req.query.limit) || 25);

  let rows = db.purchases.all();
  if (status) rows = rows.filter((p) => p.status === status);
  if (plan) rows = rows.filter((p) => p.plan === plan);
  if (storyId) rows = rows.filter((p) => p.storyId === storyId);

  const decorated = rows.map((p) => {
    const user = db.users.get(p.userId);
    const story = db.stories.get(p.storyId);
    const ent = db.entitlements.get(`ent_${p.userId}_${p.storyId}`);
    return {
      id: p.id,
      userId: p.userId,
      userEmail: user?.email || '(deleted user)',
      userName: user?.name || '',
      storyId: p.storyId,
      storyTitle: story?.title || p.storyId,
      plan: p.plan,
      amount: p.amount,
      currency: p.currency,
      status: p.status,
      provider: p.provider,
      providerOrderId: p.providerOrderId,
      providerPaymentId: p.providerPaymentId,
      createdAt: p.createdAt,
      paidAt: p.paidAt,
      expiresAt: ent && ent.purchaseId === p.id ? ent.expiresAt : null,
      signatureVerified: p.signatureVerified,
      webhookVerified: p.webhookVerified,
      failureReason: p.failureReason,
    };
  });

  const filtered = q
    ? decorated.filter((p) =>
        [p.id, p.userEmail, p.storyTitle, p.providerOrderId, p.providerPaymentId, p.userId]
          .join(' ').toLowerCase().includes(q))
    : decorated;

  filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({
    payments: filtered.slice((page - 1) * limit, page * limit),
    total: filtered.length,
    page,
    limit,
    hasMore: page * limit < filtered.length,
    revenue: filtered.filter((p) => p.status === 'paid').reduce((s, p) => s + p.amount, 0),
  });
});

router.get('/webhook-events', (_req, res) => {
  res.json({
    events: db.webhookEvents.all().sort((a, b) => new Date(b.receivedAt) - new Date(a.receivedAt)).slice(0, 50),
  });
});

/* ----------------------------------------------------------------- users */
router.get('/users', (req, res) => {
  const q = String(req.query.q || '').toLowerCase();
  const users = db.users.all()
    .filter((u) => !q || u.email.includes(q) || (u.name || '').toLowerCase().includes(q))
    .map((u) => ({
      ...publicUser(u),
      lastActiveAt: u.lastActiveAt,
      disabled: Boolean(u.disabled),
      purchases: db.purchases.where('userId', u.id).filter((p) => p.status === 'paid').length,
      activePasses: db.entitlements.where('userId', u.id)
        .filter((e) => e.status === 'active' && Date.parse(e.expiresAt) > serverNow()).length,
    }));
  res.json({ users });
});

/* ----------------------------------------------------------------- audit */
router.get('/audit', (_req, res) => {
  const logs = db.audit.all()
    .sort((a, b) => new Date(b.at) - new Date(a.at))
    .slice(0, 200);
  res.json({ logs });
});

export default router;
