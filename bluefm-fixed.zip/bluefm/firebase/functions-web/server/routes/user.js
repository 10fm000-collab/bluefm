import { Router } from 'express';
import { db } from '../db.js';
import { requireAuth, publicUser } from '../lib/auth.js';
import { accessSummaryFor, planPublic } from '../services/catalog.js';
import { getEntitlement, latestEntitlementMap } from '../lib/access.js';
import { iso, serverNow } from '../lib/time.js';
import { rateLimit } from '../lib/rateLimit.js';
import { config } from '../config.js';
import { uid } from '../lib/crypto.js';

const router = Router();

function storyCard(story, access) {
  return {
    id: story.id,
    slug: story.slug,
    title: story.title,
    author: story.author,
    cover: `/media/covers/${story.id}.webp`,
    thumb: `/media/covers/${story.id}-thumb.webp`,
    genre: story.genre,
    episodeCount: story.episodeCount,
    access,
  };
}

/** Profile + active/expired passes + purchase history. */
router.get('/', requireAuth, (req, res) => {
  const ents = db.entitlements.where('userId', req.user.id);
  const active = [];
  const expired = [];
  for (const ent of ents) {
    const story = db.stories.get(ent.storyId);
    if (!story) continue;
    const summary = accessSummaryFor(req.user.id, story.id);
    const card = storyCard(story, summary);
    if (summary.status === 'active') active.push(card);
    else expired.push(card);
  }
  active.sort((a, b) => new Date(a.access.expiresAt) - new Date(b.access.expiresAt));
  expired.sort((a, b) => new Date(b.access.expiresAt) - new Date(a.access.expiresAt));

  const purchases = db.purchases
    .where('userId', req.user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map((p) => {
      const story = db.stories.get(p.storyId);
      const ent = getEntitlement(req.user.id, p.storyId);
      return {
        id: p.id,
        storyId: p.storyId,
        storyTitle: story?.title || p.storyId,
        cover: story ? `/media/covers/${p.storyId}-thumb.webp` : '',
        plan: p.plan,
        amount: p.amount,
        currency: p.currency,
        status: p.status,
        provider: p.provider,
        createdAt: p.createdAt,
        paidAt: p.paidAt,
        expiresAt: ent && ent.purchaseId === p.id ? ent.expiresAt : undefined,
      };
    });

  const spent = purchases.filter((p) => p.status === 'paid').reduce((s, p) => s + p.amount, 0);

  res.json({
    user: publicUser(req.user),
    activePasses: active,
    expiredPasses: expired,
    purchases,
    stats: {
      activePassCount: active.length,
      purchaseCount: purchases.filter((p) => p.status === 'paid').length,
      totalSpent: spent,
      currency: 'INR',
    },
  });
});

router.patch('/', requireAuth, rateLimit('write', config.limits.write), (req, res) => {
  const name = String(req.body?.name || '').trim();
  if (name.length < 2 || name.length > 60) {
    return res.status(400).json({ error: 'Name must be 2–60 characters.' });
  }
  const updated = db.users.patch(req.user.id, { name, updatedAt: iso() });
  res.json({ user: publicUser(updated) });
});

router.post('/password', requireAuth, rateLimit('login', config.limits.login), async (req, res, next) => {
  try {
    const { verifyPassword, hashPassword } = await import('../lib/crypto.js');
    const current = String(req.body?.currentPassword || '');
    const next_ = String(req.body?.newPassword || '');
    if (next_.length < 8) return res.status(400).json({ error: 'New password must be at least 8 characters.' });
    if (!(await verifyPassword(current, req.user.passwordHash))) {
      return res.status(401).json({ error: 'Current password is incorrect.' });
    }
    db.users.patch(req.user.id, { passwordHash: await hashPassword(next_), updatedAt: iso() });
    res.json({ ok: true });
  } catch (err) { next(err); }
});

/* ------------------------------------------------------------- history */
router.get('/history', requireAuth, (req, res) => {
  const rows = db.history
    .where('userId', req.user.id)
    .sort((a, b) => new Date(b.at) - new Date(a.at))
    .slice(0, 100);
  const seen = new Set();
  const out = [];
  for (const r of rows) {
    const story = db.stories.get(r.storyId);
    const ep = db.episodes.get(r.episodeId);
    if (!story || !ep) continue;
    out.push({
      id: r.id,
      storyId: story.id,
      storyTitle: story.title,
      cover: `/media/covers/${story.id}-thumb.webp`,
      episodeId: ep.id,
      episodeNumber: ep.number,
      episodeTitle: ep.title,
      at: r.at,
      inProgress: !seen.has(story.id),
    });
    seen.add(story.id);
  }
  res.json({ history: out });
});

/* ----------------------------------------------------------- favorites */
router.get('/favorites', requireAuth, (req, res) => {
  const rows = db.favorites.where('userId', req.user.id);
  const stories = rows
    .map((r) => db.stories.get(r.storyId))
    .filter(Boolean)
    .map((s) => storyCard(s, accessSummaryFor(req.user.id, s.id)));
  res.json({ favorites: stories });
});

router.put('/favorites/:storyId', requireAuth, (req, res) => {
  const story = db.stories.get(req.params.storyId);
  if (!story) return res.status(404).json({ error: 'Story not found.' });
  const id = `fav_${req.user.id}_${story.id}`;
  db.favorites.set(id, { id, userId: req.user.id, storyId: story.id, createdAt: iso() });
  res.json({ favorite: true });
});

router.delete('/favorites/:storyId', requireAuth, (req, res) => {
  db.favorites.delete(`fav_${req.user.id}_${req.params.storyId}`);
  res.json({ favorite: false });
});

/* ------------------------------------------------------- continue rows */
router.get('/continue', requireAuth, (req, res) => {
  const rows = db.progress
    .where('userId', req.user.id)
    .filter((r) => !r.completed)
    .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
    .slice(0, 10);
  res.json({
    items: rows.map((r) => {
      const story = db.stories.get(r.storyId);
      const ep = db.episodes.get(r.episodeId);
      if (!story || !ep) return null;
      return {
        storyId: story.id,
        storyTitle: story.title,
        cover: `/media/covers/${story.id}-thumb.webp`,
        episodeId: ep.id,
        episodeNumber: ep.number,
        episodeTitle: ep.title,
        position: r.position,
        duration: ep.duration,
        percent: ep.duration ? Math.min(100, Math.round((r.position / ep.duration) * 100)) : 0,
        updatedAt: r.updatedAt,
        access: accessSummaryFor(req.user.id, story.id),
      };
    }).filter(Boolean),
  });
});

export default router;
