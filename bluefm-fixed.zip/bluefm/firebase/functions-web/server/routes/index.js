import { Router } from 'express';
import authRoutes from './auth.js';
import catalogRoutes from './catalog.js';
import playbackRoutes from './playback.js';
import paymentRoutes from './payments.js';
import userRoutes from './user.js';
import adminRoutes from './admin.js';

const router = Router();

router.get('/health', (_req, res) => res.json({ ok: true, ts: new Date().toISOString() }));

router.use('/auth', authRoutes);
router.use('/', catalogRoutes);      // /stories, /stories/:slug, /categories, /home, /search
router.use('/playback', playbackRoutes);
router.use('/payments', paymentRoutes);
router.use('/me', userRoutes);
router.use('/admin', adminRoutes);

export default router;
