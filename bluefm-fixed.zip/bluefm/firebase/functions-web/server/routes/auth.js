import { Router } from 'express';
import { config } from '../config.js';
import { db } from '../db.js';
import { hashPassword, verifyPassword, uid } from '../lib/crypto.js';
import {
  createSession, setSessionCookie, clearSessionCookie, destroySession,
  requireAuth, publicUser, readSession,
} from '../lib/auth.js';
import { rateLimit } from '../lib/rateLimit.js';
import { iso } from '../lib/time.js';
import { customTokenFor, setAdminClaim, firebaseAuthEnabled } from '../lib/firebaseAuth.js';

const router = Router();

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function normaliseEmail(email) {
  return String(email || '').trim().toLowerCase();
}

function audit(user, action, meta = {}) {
  db.audit.set(uid('aud_'), {
    id: uid('aud_'),
    actorId: user?.id || null,
    actorEmail: user?.email || null,
    action,
    target: user?.id || null,
    meta,
    at: iso(),
  });
}

router.post('/register', rateLimit('register', config.limits.register), async (req, res, next) => {
  try {
    const email = normaliseEmail(req.body?.email);
    const password = String(req.body?.password || '');
    const name = String(req.body?.name || '').trim();

    if (!emailRe.test(email)) return res.status(400).json({ error: 'Enter a valid email address.', code: 'bad_email' });
    if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters.', code: 'weak_password' });
    if (name.length < 2) return res.status(400).json({ error: 'Please enter your name.', code: 'bad_name' });
    if (db.users.findOne((u) => u.email === email)) {
      return res.status(409).json({ error: 'An account with this email already exists. Try signing in.', code: 'email_taken' });
    }

    const user = {
      id: uid('u_'),
      email,
      name,
      passwordHash: await hashPassword(password),
      role: 'user', // role is server-assigned only
      avatarColor: '#2f6bff',
      phone: null,
      firebaseUid: null,
      createdAt: iso(),
      lastActiveAt: iso(),
    };
    db.users.set(user.id, user);
    audit(user, 'auth.register');
    const token = createSession(user);
    setSessionCookie(res, token);
    const firebaseToken = await customTokenFor(user);
    res.status(201).json({ user: publicUser(user), token, firebaseToken, firebaseAuth: firebaseAuthEnabled() });
  } catch (err) { next(err); }
});

router.post('/login', rateLimit('login', config.limits.login), async (req, res, next) => {
  try {
    const email = normaliseEmail(req.body?.email);
    const password = String(req.body?.password || '');
    const user = db.users.findOne((u) => u.email === email);
    // constant-ish work whether or not the account exists
    const ok = user ? await verifyPassword(password, user.passwordHash) : await verifyPassword(password, 'scrypt$00$00');
    if (!user || !ok || user.disabled) {
      return res.status(401).json({ error: 'Email or password is incorrect.', code: 'bad_credentials' });
    }
    db.users.patch(user.id, { lastActiveAt: iso() });
    audit(user, 'auth.login');
    const token = createSession(user);
    setSessionCookie(res, token);
    const firebaseToken = await customTokenFor(user);
    res.json({ user: publicUser(user), token, firebaseToken, firebaseAuth: firebaseAuthEnabled() });
  } catch (err) { next(err); }
});

router.post('/logout', (req, res) => {
  const s = readSession(req);
  if (s) destroySession(s.session.id);
  clearSessionCookie(res);
  res.json({ ok: true });
});

router.get('/me', (req, res) => {
  res.json({ user: publicUser(req.user) });
});

/**
 * Google / phone sign-in.
 * These require a Firebase project + enabled sign-in providers. When Firebase
 * config is present the client exchanges the Firebase ID token here, and the
 * server verifies it with the Admin SDK before creating a session. Until that
 * configuration exists this endpoint reports the exact requirement instead of
 * faking a login.
 */
router.post('/firebase', rateLimit('login', config.limits.login), async (req, res) => {
  if (!config.firebase.usedForAuth || !config.firebase.projectId) {
    return res.status(501).json({
      error: 'Google and phone sign-in need Firebase Authentication configured (FIREBASE_PROJECT_ID + service account, AUTH_MODE=firebase).',
      code: 'firebase_not_configured',
      requirement: {
        env: ['AUTH_MODE=firebase', 'FIREBASE_PROJECT_ID', 'FIREBASE_SERVICE_ACCOUNT_JSON'],
        providers: ['Google', 'Phone'],
      },
    });
  }
  // Integration point: verify req.body.idToken with firebase-admin.verifyIdToken,
  // then upsert users/{firebaseUid} and mint a BLUEFM session. Intentionally not
  // silently stubbed: an unverified token must never mint a paid session.
  return res.status(501).json({
    error: 'Firebase ID token verification is not implemented in this build. See docs/ARCHITECTURE.md §6.',
    code: 'firebase_verify_todo',
  });
});

export default router;
