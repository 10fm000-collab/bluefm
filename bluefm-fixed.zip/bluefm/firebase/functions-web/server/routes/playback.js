import { Router } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
import { execFile } from 'node:child_process';
import { config } from '../config.js';
import { db } from '../db.js';
import { checkStoryAccess } from '../lib/access.js';
import { hmac, safeEqual, uid } from '../lib/crypto.js';
import { rateLimit } from '../lib/rateLimit.js';
import { iso, serverNow } from '../lib/time.js';
import { requireAuth } from '../lib/auth.js';
import { b2Configured, signedAudioUrl, signEdgeToken } from '../lib/b2.js';

const router = Router();
const exec = promisify(execFile);

const audioPath = (key) => path.join(config.audioDir, path.basename(key));

/** Server-signed playback token: binds user + episode + story + expiry. */
function signPlayback({ userId, episodeId, storyId, expiresAt }) {
  const payload = Buffer.from(JSON.stringify({ u: userId, e: episodeId, s: storyId, x: expiresAt })).toString('base64url');
  return `${payload}.${hmac(config.audio.signingSecret, payload)}`;
}

function verifyPlayback(token) {
  if (typeof token !== 'string' || !token.includes('.')) return null;
  const [payload, sig] = token.split('.');
  if (!safeEqual(sig, hmac(config.audio.signingSecret, payload))) return null;
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (data.x < serverNow()) return null;
    return data;
  } catch { return null; }
}

/**
 * Step 1: authorise. The client asks for a short-lived stream URL; the server
 * re-checks the entitlement against server time every single time.
 */
router.post('/authorize', requireAuth, rateLimit('playback', config.limits.playback), async (req, res, next) => {
  const { storyId, episodeId } = req.body || {};
  const story = db.stories.get(String(storyId || ''));
  const episode = db.episodes.get(String(episodeId || ''));
  if (!story || !episode || episode.storyId !== story.id) {
    return res.status(404).json({ error: 'Episode not found' });
  }
  if (episode.status !== 'published') {
    return res.status(404).json({ error: 'Episode not available' });
  }

  const access = checkStoryAccess(req.user.id, story.id);
  if (!access.allowed) {
    db.audit.set(uid('aud_'), {
      id: uid('aud_'),
      actorId: req.user.id,
      actorEmail: req.user.email,
      action: 'playback.denied',
      target: episode.id,
      meta: { storyId: story.id, reason: access.reason },
      at: iso(),
    });
    return res.status(403).json({
      error: access.reason === 'expired'
        ? 'Your pass for this story has expired. Unlock it again to keep listening.'
        : 'This story is locked. Purchase a pass to listen.',
      code: access.reason === 'expired' ? 'access_expired' : 'access_locked',
      access,
      plans: Object.values(config.plans),
    });
  }

  const expiresAt = serverNow() + config.audio.tokenTtlSeconds * 1000;
  const token = signPlayback({
    userId: req.user.id,
    episodeId: episode.id,
    storyId: story.id,
    expiresAt,
  });

  // ---------------------------------------------------------------- delivery
  // Order of preference:
  //   1. cloudflare  → B2 storage + Cloudflare edge (custom domain, free egress)
  //   2. b2          → signed storage URL (works, but B2 egress is billable)
  //   3. proxy       → guarded local stream (dev / fallback)
  //
  // The entitlement has ALREADY been checked above, so handing out a short-lived
  // URL here is safe — that URL cannot outlive the pass by more than its TTL.
  let streamUrl = `/api/playback/stream/${encodeURIComponent(episode.id)}?t=${token}`;
  let delivery = 'proxy';

  if (config.audio.cdnBase) {
    // Cloudflare path: stable URL, edge worker does HMAC auth + caching.
    // Query string is ignored by the CDN cache rule, so every listener hits
    // the same cached object and B2 egress stays at zero.
    streamUrl = `${config.audio.cdnBase}/${episode.audioKey}?t=${signEdgeToken({
      episodeId: episode.id,
      expiresAt,
    })}`;
    delivery = 'cloudflare';
  } else if (config.audio.storageDriver === 'b2' && b2Configured()) {
    try {
      const signed = await signedAudioUrl(episode.audioKey, config.audio.tokenTtlSeconds);
      streamUrl = signed.url;
      delivery = 'b2';
    } catch (err) {
      // never block playback on CDN trouble — the guarded proxy still works
      console.warn('[playback] B2 signing failed, falling back to proxy:', err.message);
    }
  }

  // Listening history (append-only, used for "Recently played" + admin metrics)
  db.history.set(uid('hist_'), {
    id: uid('hist_'),
    userId: req.user.id,
    storyId: story.id,
    episodeId: episode.id,
    at: iso(),
    playedSeconds: 0,
  });

  res.json({
    url: streamUrl,
    delivery,
    expiresAt: iso(expiresAt),
    ttl: config.audio.tokenTtlSeconds,
    access: { expiresAt: access.expiresAt, plan: access.plan },
    episode: {
      id: episode.id,
      title: episode.title,
      number: episode.number,
      duration: episode.duration,
    },
  });
});

/**
 * Step 2: serve audio. Token is re-verified AND the entitlement is re-checked,
 * so revoking/expiring access kills in-flight signed URLs on their next use.
 * Supports HTTP Range requests for seeking and mobile-friendly streaming.
 */
router.get('/stream/:episodeId', rateLimit('playback', config.limits.playback), async (req, res, next) => {
  try {
    const data = verifyPlayback(req.query.t);
    if (!data) return res.status(403).json({ error: 'Playback link expired. Reopen the episode.', code: 'token_invalid' });
    if (data.e !== req.params.episodeId) return res.status(403).json({ error: 'Playback link does not match this episode.', code: 'token_mismatch' });

    const access = checkStoryAccess(data.u, data.s);
    if (!access.allowed) {
      return res.status(403).json({ error: 'Access expired.', code: 'access_expired' });
    }

    const episode = db.episodes.get(data.e);
    if (!episode) return res.status(404).json({ error: 'Episode not found' });

    const file = audioPath(episode.audioKey);
    if (!fs.existsSync(file)) return res.status(404).json({ error: 'Audio file missing on storage.' });

    const stat = fs.statSync(file);
    const range = req.headers.range;

    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'private, no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');

    if (range) {
      const m = /bytes=(\d*)-(\d*)/.exec(range);
      if (!m) return res.status(416).end();
      const start = m[1] ? Number(m[1]) : 0;
      const end = m[2] ? Number(m[2]) : stat.size - 1;
      if (start >= stat.size || end >= stat.size || start > end) {
        res.setHeader('Content-Range', `bytes */${stat.size}`);
        return res.status(416).end();
      }
      res.status(206);
      res.setHeader('Content-Range', `bytes ${start}-${end}/${stat.size}`);
      res.setHeader('Content-Length', end - start + 1);
      fs.createReadStream(file, { start, end }).pipe(res);
      return;
    }

    res.setHeader('Content-Length', stat.size);
    fs.createReadStream(file).pipe(res);
  } catch (err) { next(err); }
});

/** Progress sync. Position is clamped and stored per user+episode. */
router.put('/progress', requireAuth, rateLimit('write', config.limits.write), (req, res) => {
  const { storyId, episodeId, position, duration, completed } = req.body || {};
  const story = db.stories.get(String(storyId || ''));
  const episode = db.episodes.get(String(episodeId || ''));
  if (!story || !episode || episode.storyId !== story.id) {
    return res.status(404).json({ error: 'Episode not found' });
  }
  const access = checkStoryAccess(req.user.id, story.id);
  if (!access.allowed) return res.status(403).json({ error: 'Access required', code: 'access_locked' });

  const dur = Math.max(1, Math.round(Number(episode.duration) || 1));
  const pos = Math.min(dur, Math.max(0, Math.round(Number(position) || 0)));
  const id = `${req.user.id}_${episode.id}`;
  const isDone = Boolean(completed) || pos >= dur - 3;

  const row = db.progress.set(id, {
    id,
    userId: req.user.id,
    storyId: story.id,
    episodeId: episode.id,
    position: isDone ? dur : pos,
    duration: dur,
    completed: isDone,
    updatedAt: iso(),
  });

  res.json({ progress: row });
});

export default router;
