/**
 * Cloud Functions loads env from here at cold start.
 * Non-secret values only — secrets come from Secret Manager.
 */
import fs from 'node:fs';
import path from 'node:path';

const file = path.join(import.meta.dirname, '.env');
if (fs.existsSync(file)) {
  for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const i = trimmed.indexOf('=');
    if (i === -1) continue;
    const k = trimmed.slice(0, i).trim();
    const v = trimmed.slice(i + 1).trim();
    if (!process.env[k]) process.env[k] = v;
  }
}
