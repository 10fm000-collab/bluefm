/**
 * BLUEFM — WEB backend (isolated).
 *
 * Deliberately does NOT touch anything the APK uses:
 *   • no coins, no chapter_unlocks, no creator subscriptions, no offers
 *   • no writes to `audiobooks`, `subscriptions`, `transactions`, `users`
 *   • every callable is prefixed `web` so it can't collide in the same project
 *
 * What it does: story-specific passes (daily/weekly/monthly), Cashfree
 * payments, server-authoritative entitlements and B2-signed audio URLs.
 *
 * Deploy:  cd firebase && firebase deploy --only functions:web
 */
const admin = require('firebase-admin');
const crypto = require('crypto');
const { onCall, onRequest, HttpsError } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const logger = require('firebase-functions/logger');

if (!admin.apps.length) admin.initializeApp();
const db = admin.firestore();

/* ------------------------------------------------------------------ config */
const REGION = process.env.FUNCTIONS_REGION || 'asia-south1';
const WEB_RETURN_BASE_URL = process.env.WEB_RETURN_BASE_URL || 'https://bluefm.qzz.io';

// Collections are namespaced with the `web_` prefix so they never collide with
// the existing app's data.
const C = {
  stories: 'web_stories',
  episodes: 'web_episodes',
  purchases: 'web_purchases',
  entitlements: 'web_story_entitlements',
  progress: 'web_listening_progress',
  history: 'web_listening_history',
  favorites: 'web_favorites',
  admins: 'admins',          // shared with existing admin tooling
  audit: 'web_audit_logs',
  webhookEvents: 'web_webhook_events',
};

// Server-side pricing — the client can never send an amount.
const PLANS = {
  daily:   { hours: 24,  amountPaise: 200,  label: 'Daily Pass' },
  weekly:  { hours: 168, amountPaise: 1400, label: 'Weekly Pass' },
  monthly: { hours: 720, amountPaise: 6000, label: 'Monthly Pass' },
};

const CASHFREE_CLIENT_ID = defineSecret('CASHFREE_CLIENT_ID');
const CASHFREE_CLIENT_SECRET = defineSecret('CASHFREE_CLIENT_SECRET');
const CASHFREE_ENV = defineSecret('CASHFREE_ENV');
const STREAM_TOKEN_SECRET = defineSecret('STREAM_TOKEN_SECRET');
const B2_KEY_ID = defineSecret('B2_KEY_ID');
const B2_APP_KEY = defineSecret('B2_APP_KEY');
const B2_BUCKET_ID = defineSecret('B2_BUCKET_ID');

/* ----------------------------------------------------------------- helpers */
async function requireUid(request) {
  if (request.auth?.uid) return request.auth.uid;
  const hdr = request.rawRequest?.headers?.authorization;
  if (typeof hdr === 'string' && hdr.startsWith('Bearer ')) {
    try {
      const decoded = await admin.auth().verifyIdToken(hdr.slice(7).trim());
      return decoded.uid;
    } catch (e) {
      throw new HttpsError('unauthenticated', 'Invalid auth token');
    }
  }
  throw new HttpsError('unauthenticated', 'Login required');
}

async function requireAdmin(request) {
  const uid = await requireUid(request);
  const snap = await db.collection(C.admins).doc(uid).get();
  if (!snap.exists) throw new HttpsError('permission-denied', 'Admin only');
  return uid;
}

const b64url = (buf) => Buffer.from(buf).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');

/**
 * HMAC token for the Cloudflare stream worker. Identical format to
 * server/lib/b2.js#signEdgeToken and cloudflare/worker-stream-auth.js:
 *   base64url({e:episodeId,x:expirySeconds}) "." base64url(HMAC-SHA256)
 */
function signEdgeToken({ episodeId, expiresAt, path }, secret) {
  // MUST match cloudflare/worker-stream-auth.js: { exp, path }
  const body = b64url(JSON.stringify({
    exp: Math.floor(expiresAt / 1000),
    path: path || `/${episodeId}.mp3`,
  }));
  const sig = crypto.createHmac('sha256', secret).update(body).digest('base64')
    .replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  return `${body}.${sig}`;
}
const nowIso = () => new Date().toISOString();

function cashfreeBase(env) {
  return String(env || 'sandbox').toLowerCase() === 'production'
    ? 'https://api.cashfree.com/pg'
    : 'https://sandbox.cashfree.com/pg';
}

function cashfreeHeaders(clientId, clientSecret) {
  return {
    'content-type': 'application/json',
    'x-api-version': '2025-01-01',
    'x-client-id': clientId,
    'x-client-secret': clientSecret,
  };
}

async function cashfreeGetOrder(orderId, clientId, clientSecret, env) {
  const r = await fetch(`${cashfreeBase(env)}/orders/${encodeURIComponent(orderId)}`, {
    method: 'GET', headers: cashfreeHeaders(clientId, clientSecret),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    logger.error('cashfree order lookup failed', { orderId, status: r.status });
    throw new HttpsError('internal', 'Cashfree order lookup failed');
  }
  return data;
}

const entId = (uid, storyId) => `${uid}_${storyId}`;

/**
 * Grants or extends a pass. Idempotent: replaying the same purchaseId can never
 * add time; a genuinely new purchase extends from the current expiry so paid
 * time is never lost.
 */
async function grantEntitlement({ uid, storyId, purchaseId, plan, amountPaise, serverNow }) {
  const ref = db.collection(C.entitlements).doc(entId(uid, storyId));

  return db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const existing = snap.exists ? snap.data() : null;

    if (existing && existing.purchaseId === purchaseId) {
      return { entitlement: existing, duplicate: true };
    }

    const activeUntil =
      existing && existing.status === 'active' && existing.expiresAtMs > serverNow
        ? existing.expiresAtMs
        : null;
    const base = activeUntil || serverNow;
    const expiresAtMs = base + PLANS[plan].hours * 3600 * 1000;

    const doc = {
      userId: uid,
      storyId,
      purchaseId,
      plan,
      amountPaise,
      currency: 'INR',
      startsAt: nowIso(),
      startsAtMs: serverNow,
      expiresAt: new Date(expiresAtMs).toISOString(),
      expiresAtMs,
      status: 'active',
      renewalCount: activeUntil ? (existing.renewalCount || 0) + 1 : 0,
      createdAt: existing?.createdAt || nowIso(),
      updatedAt: nowIso(),
    };
    tx.set(ref, doc, { merge: true });
    return { entitlement: doc, duplicate: false };
  });
}

/* ============================================================== catalogue */
exports.webHome = onCall({ region: REGION }, async (request) => {
  const uid = request.auth?.uid || null;
  const storiesSnap = await db.collection(C.stories).where('status', '==', 'published').get();
  const stories = storiesSnap.docs.map((d) => ({ id: d.id, ...d.data() }));

  let entitlements = {};
  let progress = [];
  if (uid) {
    const [entSnap, progSnap] = await Promise.all([
      db.collection(C.entitlements).where('userId', '==', uid).get(),
      db.collection(C.progress).where('userId', '==', uid).get(),
    ]);
    const now = Date.now();
    for (const d of entSnap.docs) {
      const data = d.data();
      if (data.status === 'active' && data.expiresAtMs > now) entitlements[data.storyId] = data;
    }
    progress = progSnap.docs.map((d) => d.data()).sort((a, b) => (b.updatedAtMs || 0) - (a.updatedAtMs || 0));
  }

  const byPlays = [...stories].sort((a, b) => (b.plays || 0) - (a.plays || 0));
  const byDate = [...stories].sort((a, b) => String(b.publishedAt || '').localeCompare(String(a.publishedAt || '')));
  const featured = stories
    .filter((s) => Number(s.featuredRank) > 0)
    .sort((a, b) => Number(a.featuredRank) - Number(b.featuredRank))
    .slice(0, 4);

  const withAccess = (s) => ({
    ...s,
    access: entitlements[s.id]
      ? { status: 'active', plan: entitlements[s.id].plan, expiresAt: entitlements[s.id].expiresAt }
      : { status: 'locked' },
  });

  return {
    featured: featured.map(withAccess),
    trending: byPlays.slice(0, 6).map(withAccess),
    recentlyAdded: byDate.slice(0, 8).map(withAccess),
    popular: byPlays.slice(0, 8).map(withAccess),
    recommended: [...stories].sort((a, b) => (b.rating || 0) - (a.rating || 0)).slice(0, 8).map(withAccess),
    continueListening: progress.filter((p) => !p.completed).slice(0, 6),
    myPurchased: stories.filter((s) => entitlements[s.id]).map(withAccess),
    plans: Object.entries(PLANS).map(([id, p]) => ({ id, ...p })),
  };
});

exports.webStory = onCall({ region: REGION }, async (request) => {
  const uid = request.auth?.uid || null;
  const slug = String(request.data?.slug || '');
  if (!slug) throw new HttpsError('invalid-argument', 'slug required');

  const snap = await db.collection(C.stories).where('slug', '==', slug).limit(1).get();
  if (snap.empty) throw new HttpsError('not-found', 'Story not found');
  const story = { id: snap.docs[0].id, ...snap.docs[0].data() };

  const epsSnap = await db.collection(C.episodes)
    .where('storyId', '==', story.id).where('status', '==', 'published').get();
  const episodes = epsSnap.docs
    .map((d) => {
      const { audioKey, ...safe } = d.data();   // audio keys never leave the server
      return { id: d.id, ...safe };
    })
    .sort((a, b) => a.number - b.number);

  let access = { status: 'locked' };
  let progress = {};
  if (uid) {
    const entSnap = await db.collection(C.entitlements).doc(entId(uid, story.id)).get();
    if (entSnap.exists) {
      const e = entSnap.data();
      access = e.status === 'active' && e.expiresAtMs > Date.now()
        ? { status: 'active', plan: e.plan, expiresAt: e.expiresAt, purchasedAt: e.startsAt }
        : { status: 'expired', plan: e.plan, expiresAt: e.expiresAt };
    }
    const progSnap = await db.collection(C.progress).where('userId', '==', uid).where('storyId', '==', story.id).get();
    for (const d of progSnap.docs) progress[d.data().episodeId] = d.data();
  }

  return {
    story: { ...story, access },
    episodes: episodes.map((e) => ({ ...e, unlocked: access.status === 'active', progress: progress[e.id] || null })),
    plans: Object.entries(PLANS).map(([id, p]) => ({ id, ...p })),
  };
});

/* ============================================================ entitlements */
exports.webGetEntitlements = onCall({ region: REGION }, async (request) => {
  const uid = await requireUid(request);
  const snap = await db.collection(C.entitlements).where('userId', '==', uid).get();
  const now = Date.now();
  const rows = snap.docs.map((d) => {
    const e = d.data();
    const status = e.status === 'active' && e.expiresAtMs > now ? 'active' : (e.status === 'revoked' ? 'revoked' : 'expired');
    return { ...e, status, msRemaining: Math.max(0, e.expiresAtMs - now) };
  });
  return { entitlements: rows };
});

/* ================================================================ playback */
/**
 * Authorises a stream and returns a short-lived B2 download URL.
 * The entitlement is checked with server time on EVERY call — expiry is never
 * trusted from the client.
 */
exports.webGetStreamUrl = onCall(
  { region: REGION, secrets: [B2_KEY_ID, B2_APP_KEY, B2_BUCKET_ID, STREAM_TOKEN_SECRET] },
  async (request) => {
    const uid = await requireUid(request);
    const storyId = String(request.data?.storyId || '');
    const episodeId = String(request.data?.episodeId || '');
    if (!storyId || !episodeId) throw new HttpsError('invalid-argument', 'storyId/episodeId required');

    const entSnap = await db.collection(C.entitlements).doc(entId(uid, storyId)).get();
    if (!entSnap.exists) throw new HttpsError('permission-denied', 'Story is locked');
    const ent = entSnap.data();
    if (ent.status !== 'active' || ent.expiresAtMs <= Date.now()) {
      throw new HttpsError('permission-denied', 'Pass expired — renew to keep listening');
    }

    const epSnap = await db.collection(C.episodes).doc(episodeId).get();
    if (!epSnap.exists) throw new HttpsError('not-found', 'Episode not found');
    const ep = epSnap.data();
    if (ep.storyId !== storyId) throw new HttpsError('permission-denied', 'Episode mismatch');

    // Delivery: Cloudflare edge in front of the B2 bucket.
    //   browser → media.bluefm.site (Cloudflare) → B2 origin
    // Stable URL + HMAC token means Cloudflare can cache the object once and
    // serve every listener from edge; B2 egress stays inside the free
    // Bandwidth Alliance. B2 never sees the user and the user never sees B2.
    const ttlSeconds = 600;
    const cdnBase = (process.env.B2_DOWNLOAD_URL || '').replace(/\/$/, '');
    let url;

    if (cdnBase) {
      const cdnKey = String(ep.audioKey).split('/').map(encodeURIComponent).join('/');
      url = `${cdnBase}/${cdnKey}?t=${signEdgeToken(
        { episodeId: episodeId, expiresAt: Date.now() + ttlSeconds * 1000 },
        STREAM_TOKEN_SECRET.value(),
      )}`;
    } else {
      // No CDN configured — fall back to a direct B2 signed URL (works, but
      // B2 egress is billable; use the CDN in production).
      const auth = await b2Authorize();
      const dlResp = await fetch(`${auth.apiUrl}/b2api/v3/b2_get_download_authorization`, {
        method: 'POST',
        headers: { Authorization: auth.token, 'content-type': 'application/json' },
        body: JSON.stringify({
          bucketId: B2_BUCKET_ID.value(),
          fileNamePrefix: ep.audioKey,   // ONE object only, never the bucket
          validDurationInSeconds: ttlSeconds,
        }),
      });
      const dl = await dlResp.json().catch(() => ({}));
      if (!dlResp.ok) throw new HttpsError('internal', 'Storage signing failed');

      const bucketName = process.env.B2_BUCKET_NAME || 'bluefm-web-audio';
      const host = process.env.B2_DOWNLOAD_HOST || 'https://f005.backblazeb2.com';
      const keyPath = String(ep.audioKey).split('/').map(encodeURIComponent).join('/');
      url = `${host}/file/${bucketName}/${keyPath}?Authorization=${encodeURIComponent(dl.authorizationToken)}`;
    }

    // listening history (best-effort)
    await db.collection(C.history).add({
      userId: uid, storyId, episodeId, at: admin.firestore.FieldValue.serverTimestamp(),
    }).catch((err) => logger.warn('history write failed', err.message));

    return {
      url,
      delivery: (process.env.B2_DOWNLOAD_URL || '') ? 'cloudflare' : 'b2',
      expiresIn: ttlSeconds,
      access: { plan: ent.plan, expiresAt: ent.expiresAt },
      episode: { id: episodeId, number: ep.number, title: ep.title, duration: ep.duration },
    };
  }
);

let b2Cache = { token: null, apiUrl: null, expiresAt: 0 };
async function b2Authorize() {
  if (b2Cache.token && Date.now() < b2Cache.expiresAt - 60_000) return b2Cache;
  const basic = Buffer.from(`${B2_KEY_ID.value()}:${B2_APP_KEY.value()}`).toString('base64');
  const r = await fetch('https://api.backblazeb2.com/b2api/v3/b2_authorize_account', {
    headers: { Authorization: `Basic ${basic}` },
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new HttpsError('internal', 'B2 authorization failed');
  b2Cache = {
    token: j.authorizationToken,
    apiUrl: j.apiInfo?.storageApi?.apiUrl || j.apiUrl,
    expiresAt: Date.now() + 23 * 3600 * 1000,
  };
  return b2Cache;
}

exports.webSaveProgress = onCall({ region: REGION }, async (request) => {
  const uid = await requireUid(request);
  const { storyId, episodeId, position, completed } = request.data || {};
  if (!storyId || !episodeId) throw new HttpsError('invalid-argument', 'storyId/episodeId required');

  const entSnap = await db.collection(C.entitlements).doc(entId(uid, storyId)).get();
  const ent = entSnap.exists ? entSnap.data() : null;
  if (!ent || ent.status !== 'active' || ent.expiresAtMs <= Date.now()) {
    throw new HttpsError('permission-denied', 'Access required');
  }

  const id = `${uid}_${episodeId}`;
  await db.collection(C.progress).doc(id).set({
    userId: uid, storyId, episodeId,
    position: Math.max(0, Math.round(Number(position) || 0)),
    completed: Boolean(completed),
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    updatedAtMs: Date.now(),
  }, { merge: true });
  return { ok: true };
});

/* ================================================================ payments */
exports.webCreatePassOrder = onCall(
  { region: REGION, secrets: [CASHFREE_CLIENT_ID, CASHFREE_CLIENT_SECRET, CASHFREE_ENV] },
  async (request) => {
    const uid = await requireUid(request);
    const email = request.auth?.token?.email || '';
    const storyId = String(request.data?.storyId || '');
    const plan = String(request.data?.plan || '');
    const phone = String(request.data?.phone || '').replace(/\s+/g, '').replace(/^\+91/, '');

    if (!PLANS[plan]) throw new HttpsError('invalid-argument', 'Unknown plan');
    if (!storyId) throw new HttpsError('invalid-argument', 'storyId required');
    if (!/^[6-9]\d{9}$/.test(phone)) {
      throw new HttpsError('invalid-argument', 'Valid 10-digit mobile number required');
    }

    const storySnap = await db.collection(C.stories).doc(storyId).get();
    if (!storySnap.exists) throw new HttpsError('not-found', 'Story not found');

    const amountPaise = PLANS[plan].amountPaise;
    const orderId = `WEB_${uid.slice(0, 8)}_${Date.now()}`;
    const clientId = CASHFREE_CLIENT_ID.value();
    const clientSecret = CASHFREE_CLIENT_SECRET.value();
    const env = CASHFREE_ENV.value();

    const body = {
      order_id: orderId,
      order_amount: amountPaise / 100,
      order_currency: 'INR',
      customer_details: { customer_id: uid, customer_email: email || 'na@example.com', customer_phone: phone },
      order_meta: {
        return_url: `${WEB_RETURN_BASE_URL}/payment-return.html?order_id={order_id}`,
        notify_url: `https://${REGION}-${process.env.GCLOUD_PROJECT}.cloudfunctions.net/webCashfreeWebhook`,
      },
      order_note: `BLUEFM ${PLANS[plan].label}`,
    };

    const r = await fetch(`${cashfreeBase(env)}/orders`, {
      method: 'POST', headers: cashfreeHeaders(clientId, clientSecret), body: JSON.stringify(body),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      logger.error('cashfree create order failed', { status: r.status, data, orderId });
      throw new HttpsError('internal', `Cashfree order failed (${r.status})`);
    }

    await db.collection(C.purchases).doc(orderId).set({
      userId: uid, email, phone, storyId, plan,
      amountPaise, currency: 'INR',
      status: 'created',
      provider: 'cashfree',
      providerOrderId: orderId,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      createdAtMs: Date.now(),
      source: 'web',
    });

    return {
      orderId,
      paymentSessionId: data.payment_session_id,
      env: String(env).toLowerCase(),
      amountPaise,
      plan,
      storyId,
    };
  }
);

exports.webVerifyPassPayment = onCall(
  { region: REGION, secrets: [CASHFREE_CLIENT_ID, CASHFREE_CLIENT_SECRET, CASHFREE_ENV] },
  async (request) => {
    const uid = await requireUid(request);
    const orderId = String(request.data?.orderId || '');
    if (!orderId) throw new HttpsError('invalid-argument', 'orderId required');

    const purchaseRef = db.collection(C.purchases).doc(orderId);
    const purchaseSnap = await purchaseRef.get();
    if (!purchaseSnap.exists) throw new HttpsError('not-found', 'Order not found');
    const purchase = purchaseSnap.data();

    if (purchase.userId !== uid) throw new HttpsError('permission-denied', 'Order belongs to another account');

    const existing = await db.collection(C.entitlements).doc(entId(uid, purchase.storyId)).get();
    if (purchase.status === 'paid' && existing.exists) {
      return { success: true, duplicate: true, entitlement: existing.data() };
    }

    // Trusted check: server-to-server order status, never the client's word.
    const cfOrder = await cashfreeGetOrder(
      orderId, CASHFREE_CLIENT_ID.value(), CASHFREE_CLIENT_SECRET.value(), CASHFREE_ENV.value(),
    );
    const status = String(cfOrder.order_status || '').toUpperCase();
    if (status !== 'PAID') {
      await purchaseRef.set({ status: 'failed', failureReason: `order_status_${status}`, updatedAt: nowIso() }, { merge: true });
      throw new HttpsError('failed-precondition', `Payment not completed (${status || 'unknown'})`);
    }

    const serverNow = Date.now();
    const { entitlement, duplicate } = await grantEntitlement({
      uid, storyId: purchase.storyId, purchaseId: orderId,
      plan: purchase.plan, amountPaise: purchase.amountPaise, serverNow,
    });

    await purchaseRef.set({
      status: 'paid', paidAt: nowIso(), paidAtMs: serverNow,
      cfOrderStatus: status, verifiedServerSide: true,
    }, { merge: true });

    await db.collection(C.audit).add({
      actorId: uid, action: 'entitlement.granted', target: entId(uid, purchase.storyId),
      meta: { purchaseId: orderId, plan: purchase.plan, source: 'client_verify' }, at: nowIso(),
    });

    return { success: true, duplicate, entitlement };
  }
);

/** Cashfree webhook — verified with x-webhook-signature, idempotent by event id. */
exports.webCashfreeWebhook = onRequest(
  { region: REGION, secrets: [CASHFREE_CLIENT_ID, CASHFREE_CLIENT_SECRET, CASHFREE_ENV] },
  async (req, res) => {
    try {
      if (req.method !== 'POST') return res.status(200).json({ ok: true, ignored: 'not_post' });

      const ts = req.get('x-webhook-timestamp');
      const sig = req.get('x-webhook-signature');
      const idem = req.get('x-idempotency-header') || req.get('x-webhook-event-id');
      if (!ts || !sig) return res.status(200).json({ ok: true, ignored: 'missing_sig' });

      const raw = req.rawBody ? req.rawBody.toString('utf8') : JSON.stringify(req.body || {});
      const expected = crypto
        .createHmac('sha256', CASHFREE_CLIENT_SECRET.value())
        .update(`${ts}.${raw}`)
        .digest('base64');

      const a = Buffer.from(expected);
      const b = Buffer.from(String(sig));
      if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
        logger.warn('web cashfree webhook bad signature');
        return res.status(200).json({ ok: true, ignored: 'bad_sig' });
      }

      if (idem) {
        const ref = db.collection(C.webhookEvents).doc(idem);
        if ((await ref.get()).exists) return res.status(200).json({ ok: true, duplicate: true });
        await ref.set({ receivedAt: nowIso(), type: String(req.body?.type || '') });
      }

      const orderId = req.body?.data?.order?.order_id;
      if (!orderId) return res.status(200).json({ ok: true, ignored: 'no_order_id' });

      const cfOrder = await cashfreeGetOrder(
        orderId, CASHFREE_CLIENT_ID.value(), CASHFREE_CLIENT_SECRET.value(), CASHFREE_ENV.value(),
      );
      if (String(cfOrder.order_status || '').toUpperCase() !== 'PAID') {
        return res.status(200).json({ ok: true, ignored: 'not_paid' });
      }

      const purchaseRef = db.collection(C.purchases).doc(orderId);
      const snap = await purchaseRef.get();
      if (!snap.exists) return res.status(200).json({ ok: true, ignored: 'order_not_found' });
      const purchase = snap.data();
      if (purchase.status === 'paid') return res.status(200).json({ ok: true, alreadyProcessed: true });

      const serverNow = Date.now();
      const { duplicate } = await grantEntitlement({
        uid: purchase.userId, storyId: purchase.storyId, purchaseId: orderId,
        plan: purchase.plan, amountPaise: purchase.amountPaise, serverNow,
      });

      await purchaseRef.set({
        status: 'paid', paidAt: nowIso(), paidAtMs: serverNow, webhookVerified: true,
      }, { merge: true });

      return res.status(200).json({ ok: true, processed: true, duplicate, orderId });
    } catch (e) {
      logger.error('webCashfreeWebhook error', e);
      return res.status(200).json({ ok: true, ignored: 'error' });
    }
  }
);

/* ================================================================== admin */
exports.webAdminGrantPass = onCall({ region: REGION }, async (request) => {
  const adminUid = await requireAdmin(request);
  const { uids, storyId, plan = 'weekly', reason = 'manual_grant' } = request.data || {};
  if (!Array.isArray(uids) || !uids.length) throw new HttpsError('invalid-argument', 'uids[] required');
  if (!PLANS[plan]) throw new HttpsError('invalid-argument', 'Unknown plan');
  if (!storyId) throw new HttpsError('invalid-argument', 'storyId required');

  let granted = 0;
  const chunk = 450;
  for (let i = 0; i < uids.length; i += chunk) {
    const batch = db.batch();
    for (const targetUid of uids.slice(i, i + chunk)) {
      const now = Date.now();
      const ref = db.collection(C.entitlements).doc(entId(String(targetUid), storyId));
      batch.set(ref, {
        userId: String(targetUid), storyId, plan,
        purchaseId: `MANUAL_${adminUid}_${now}`,
        amountPaise: 0, currency: 'INR',
        startsAt: nowIso(), startsAtMs: now,
        expiresAt: new Date(now + PLANS[plan].hours * 3600 * 1000).toISOString(),
        expiresAtMs: now + PLANS[plan].hours * 3600 * 1000,
        status: 'active', source: 'admin_manual_grant',
        grantedBy: adminUid, reason, createdAt: nowIso(), updatedAt: nowIso(),
      }, { merge: true });
      granted++;
    }
    await batch.commit();
  }

  await db.collection(C.audit).add({
    actorId: adminUid, action: 'entitlement.bulk_grant', target: storyId,
    meta: { count: granted, plan, reason }, at: nowIso(),
  });

  return { success: true, granted };
});

exports.webAdminStats = onCall({ region: REGION }, async (request) => {
  await requireAdmin(request);
  const [purchasesSnap, entsSnap] = await Promise.all([
    db.collection(C.purchases).get(),
    db.collection(C.entitlements).get(),
  ]);
  const now = Date.now();
  const paid = purchasesSnap.docs.map((d) => d.data()).filter((p) => p.status === 'paid');
  const active = entsSnap.docs.map((d) => d.data()).filter((e) => e.status === 'active' && e.expiresAtMs > now);

  return {
    currency: 'INR',
    revenuePaise: paid.reduce((s, p) => s + (p.amountPaise || 0), 0),
    purchases: paid.length,
    activePasses: active.length,
    failed: purchasesSnap.docs.map((d) => d.data()).filter((p) => p.status === 'failed').length,
    plans: PLANS,
  };
});
