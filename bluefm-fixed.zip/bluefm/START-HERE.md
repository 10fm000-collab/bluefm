# BLUEFM — START HERE (aage ka process)

Ye file padhne ke baad aapko pata hoga: kya bana hai, kahan daalna hai, aur
kaunsa step aapke bina nahi ho sakta.

---

## 0. Ek min me: kya kya ready hai

| Cheez | Status | Proof |
|-------|--------|-------|
| App (UI) | ✅ frozen, aapne approve kiya | `shots/` |
| Prices ₹2 / ₹14 / ₹60 | ✅ live | `/api/plans` |
| Cashfree payments | ✅ code + **7/7 tests** | `test/cashfree.test.js` |
| B2 storage (private bucket) | ✅ **67 files uploaded** | bucket `bluefm-web-audio` |
| Cloudflare streaming | ✅ worker **8/8 tests** | `cloudflare/worker-stream-auth.js` |
| Firebase backend (alag folder) | ✅ 615 lines, deploy-ready | `firebase/functions-web/` |
| Migration script | ✅ dry-run verified | `scripts/migrate-to-firebase.js` |
| Tests | ✅ **32/32** | `npm test` |

---

## 1. ZIP kholne ke baad — 3 command

```bash
unzip bluefm.zip && cd bluefm
npm install
npm start            # http://localhost:8080
```

Login: `listener@bluefm.app / bluefm123` · Admin: `admin@bluefm.app / bluefm-admin-2026`

> **ZIP me B2 keys nahi hain.** Jo keys chat me di thi wo expose ho gayi —
> rotate karke apni nayi key `.env` me daalo. (dekh Step 2)

---

## 2. Aapko ye 5 cheezein daalni hain (baaki main kar chuka hoon)

### 2.1 B2 key rotate karo (5 min) — ZAROORI

Purani key chat me aa gayi hai. Naya **bucket-scoped** key banao:

```
Backblaze → Application Keys → Add a New Application Key
  name:        bluefm-web
  bucket:      bluefm-web-audio        ← sirf ye bucket
  capabilities: readFiles, writeFiles, listFiles
```

Phir `.env` me:

```bash
AUDIO_STORAGE=b2
B2_KEY_ID=<naya key id>
B2_APP_KEY=<naya app key>
B2_BUCKET_ID=e0af0a7f83d0af4ba71b0c1e
B2_BUCKET_NAME=bluefm-web-audio
```

Verify: `curl -s localhost:8080/api/health` → `{"ok":true}`

### 2.2 Cloudflare custom domain (15 min) — streaming yahan se

Yehi wo step hai jo B2 egress **free** karta hai. Detail:
[`cloudflare/README.md`](cloudflare/README.md)

Short version:

1. B2 → Buckets → `bluefm-web-audio` → **Bucket Settings → Custom Domain** →
   `media.bluefm.site`
2. Cloudflare DNS me jo CNAME B2 de, daalo — **Proxy ON (orange cloud)** ⚠️
3. Cloudflare → Caching → Cache Rules →
   `hostname eq "media.bluefm.site"` → Cache Eligible, Edge TTL 1 year
4. Worker deploy:
   ```bash
   npm i -g wrangler
   cd cloudflare
   wrangler login
   wrangler secret put STREAM_TOKEN_SECRET
   wrangler secret put B2_KEY_ID
   wrangler secret put B2_APP_KEY
   wrangler deploy
   ```
   (`wrangler.toml` me `B2_BUCKET_ID` aur `B2_BUCKET_NAME` bhi set karo)

Server `.env` me:

```bash
B2_DOWNLOAD_URL=https://media.bluefm.site
STREAM_TOKEN_SECRET=<wahi secret jo worker me dala>
```

Ab `/api/playback/authorize` → `delivery: "cloudflare"`.

### 2.3 Cashfree keys (10 min)

```bash
PAYMENT_PROVIDER=cashfree
CASHFREE_CLIENT_ID=...
CASHFREE_CLIENT_SECRET=...
CASHFREE_ENV=sandbox          # pehle sandbox, phir production
```

Cashfree dashboard → **Payment Gateway → Developers → Webhooks**:

```
https://<aapka-domain>/api/payments/webhooks/cashfree
```

> Sandbox me Cashfree test cards se poora flow chalta hai — asli paisa nahi.
> Live keys milne ke baad `CASHFREE_ENV=production` aur orders live ho jayenge.

### 2.4 Firebase deploy (20 min)

```bash
npm i -g firebase-tools
firebase login
cd firebase
firebase use --add          # apna project chuno (bluefm)

firebase functions:secrets:set CASHFREE_CLIENT_ID
firebase functions:secrets:set CASHFREE_CLIENT_SECRET
firebase functions:secrets:set CASHFREE_ENV
firebase functions:secrets:set STREAM_TOKEN_SECRET
firebase functions:secrets:set B2_KEY_ID
firebase functions:secrets:set B2_APP_KEY
firebase functions:secrets:set B2_BUCKET_ID

firebase deploy --only functions:web,firestore:rules,firestore:indexes
```

⚠️ **`firestore:rules` deploy karne se pehle `firestore.rules` me sirf `web_*`
rules hain** — agar aapke live project me pehle se rules hain, to unhe merge
karna hoga, warna APK ka access toot sakta hai. Safe raasta:

```bash
firebase firestore:rules:get > live-rules.txt     # pehle backup
# phir dono files manually merge karo
firebase deploy --only firestore:rules
```

Data bharne ke liye:

```bash
GOOGLE_APPLICATION_CREDENTIALS=./service-account.json \
B2_KEY_ID=... B2_APP_KEY=... B2_BUCKET_ID=e0af0a7f83d0af4ba71b0c1e \
B2_BUCKET_NAME=bluefm-web-audio \
node scripts/migrate-to-firebase.js --apply
```

### 2.5 Hosting (2 min)

Cloudflare Pages ya Firebase Hosting dono chalenge:

```bash
npm run build
# dist/client/ upload karo
```

API requests `/api/**` ko aapke Node server (ya Firebase functions) pe proxy
karna hoga — `firebase.json` me rewrite already likha hai.

---

## 3. Aage ka process — order me

```
[✅] 1. UI + catalog + player          (done, frozen)
[✅] 2. Prices double                   (₹2/₹14/₹60)
[✅] 3. B2 storage + 67 files upload    (done, verified)
[✅] 4. Cloudflare worker + tests       (done, 8/8)
[✅] 5. Cashfree integration + tests    (done, 7/7, mock gateway)
[✅] 6. Firebase backend (alag folder)  (done, deploy-ready)
[ ] 7. B2 key rotate                    ← AAP
[ ] 8. Cloudflare custom domain + worker deploy ← AAP
[ ] 9. Cashfree live keys + webhook URL ← AAP
[ ] 10. Firebase project + secrets      ← AAP
[ ] 11. Staging pe end-to-end test      ← saath me
[ ] 12. Real device testing (Android/iOS) ← AAP (QR: bluefm-qr-card.png)
[ ] 13. Play Store / App Store wrap     ← aapka call
```

Har step ke baad `npm test` chalao — 32/32 rehna chahiye.

---

## 4. Kaunsa step phasa to

| Problem | Kya karo |
|---------|----------|
| `delivery: "b2"` aa raha hai, `cloudflare` nahi | `B2_DOWNLOAD_URL` set nahi hai `.env` me |
| Audio 404 | file B2 pe nahi hai → `scripts/migrate-to-firebase.js --apply` |
| Worker 401 `Bad signature` | worker ka `STREAM_TOKEN_SECRET` aur server ka alag hai |
| Worker 401 `Path mismatch` | token kis file ke liye bana tha wo check karo |
| Cashfree order fail | `CASHFREE_ENV` galat (sandbox key + production URL = 401) |
| Audio buffer ho raha hai | cache rule me query string ignore ON karo |
| B2 ka bill aa raha hai | orange cloud OFF hai → direct B2 hit ho raha hai |

---

## 5. Aapke worker vs is worker ka diff (short)

Aapka original kaam kar raha tha, isliye maine usko todha nahi — **contract same
rakha** (`{exp, path}`, `?t=`, 401). Sirf 4 cheezein sudhaari:

| # | Aapke worker me | Ab |
|---|-----------------|-----|
| 1 | `Cache-Control: private, no-store` → Cloudflare cache **karta hi nahi**, free egress ka fayda zero | `public, max-age=31536000, immutable` → edge cache hota hai |
| 2 | Range request pe hamesha B2 hit (seek karte waqt bill) | Range bhi cache se slice hota hai → B2 hit **0** |
| 3 | Sirf `?t=` (player me header dena padta tha) | `?t=` **aur** `Authorization: Bearer` dono |
| 4 | B2 v2 API | v3 + 401 pe auto re-auth + bucket-scoped token |

Baaki sab same: HMAC scheme, payload, CORS allowlist (`ALLOWED_ORIGINS`),
`STREAM_STRICT_CACHE` (naya, optional) jo token ko cache key se hata deta hai.
