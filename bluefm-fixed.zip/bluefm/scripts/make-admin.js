#!/usr/bin/env node
/**
 * Makes an existing account an admin on nodio-575bf.
 *
 *   node scripts/make-admin.js admin@bluefm.app
 *   node scripts/make-admin.js admin@bluefm.app --project=nodio-575bf
 *
 * What it does (nothing else, no schema changes):
 *   1. finds the user in the `users` collection
 *   2. sets role: "admin" on that doc
 *   3. creates `admins/{firebaseUid}` = { email, role, createdAt }
 *      — this is the doc firestore.rules and webAdmin* functions check
 *   4. mirrors the `admin: true` custom claim into Firebase Auth
 *
 * Idempotent: running it twice is harmless.
 */
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const email = (argv.find((a) => !a.startsWith('--')) || '').trim().toLowerCase();
const PROJECT_ID = (argv.find((a) => a.startsWith('--project=')) || '').split('=')[1]
  || process.env.FIREBASE_PROJECT_ID
  || process.env.GCLOUD_PROJECT
  || 'nodio-575bf';
const PREFIX = process.env.FIRESTORE_PREFIX || '';
const col = (t) => (PREFIX ? `${PREFIX}${t}` : t);

if (!email) {
  console.error('usage: node scripts/make-admin.js <email> [--project=nodio-575bf]');
  process.exit(1);
}

const admin = (await import('firebase-admin')).default;

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.applicationDefault(),
    projectId: PROJECT_ID,
  });
}
const db = admin.firestore();

const log = (...a) => console.log('[make-admin]', ...a);

const snap = await db.collection(col('users')).where('email', '==', email).limit(1).get();
if (snap.empty) {
  console.error(`[make-admin] no user with email ${email} in ${col('users')}.`);
  console.error('[make-admin] register through the site first, then run this again.');
  process.exit(1);
}

const userDoc = snap.docs[0];
const user = { id: userDoc.id, ...userDoc.data() };
const firebaseUid = user.firebaseUid || `u_${user.id}`;

await userDoc.ref.set({ role: 'admin', updatedAt: new Date().toISOString() }, { merge: true });
log(`user ${email} → role=admin`);

await db.collection('admins').doc(firebaseUid).set({
  email,
  userId: user.id,
  role: 'admin',
  createdAt: new Date().toISOString(),
}, { merge: true });
log(`admins/${firebaseUid} written`);

try {
  await admin.auth().setCustomUserClaims(firebaseUid, { admin: true });
  log('firebase custom claim admin=true set');
} catch (err) {
  log('claim skipped (user may not exist in Auth yet):', err.message);
}

// keep a local mirror so `npm start` (file driver) also sees the role
const dbFile = path.join(process.cwd(), 'data', 'db.json');
if (fs.existsSync(dbFile)) {
  const local = JSON.parse(fs.readFileSync(dbFile, 'utf8'));
  if (local.users?.[user.id]) {
    local.users[user.id].role = 'admin';
    fs.writeFileSync(dbFile, JSON.stringify(local));
    log('local data/db.json updated too');
  }
}

log('done. Admin panel: /admin');
process.exit(0);
