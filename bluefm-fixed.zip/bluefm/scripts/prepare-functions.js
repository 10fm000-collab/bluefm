#!/usr/bin/env node
/**
 * Bundles the API into firebase/functions-web/ before deploy.
 *
 * WHY THIS EXISTS
 * ---------------
 * `firebase deploy` only uploads the functions source directory. Our API lives
 * in ../server and ../firebase-web, so those files must be copied in first.
 *
 *   node scripts/prepare-functions.js      → copy server/ + firebase-web/
 *   firebase deploy --only functions:web
 *
 * The copy is idempotent and git-ignored: run it before every deploy (npm run
 * fb:deploy does it for you).
 */
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve(import.meta.dirname, '..');
const TARGET = path.join(ROOT, 'firebase', 'functions-web');

const COPY = [
  { from: 'server', to: 'server' },
  { from: 'firebase-web', to: 'firebase-web' },
];

function rmrf(p) {
  fs.rmSync(p, { recursive: true, force: true });
}

function copyDir(from, to, { skip = [] } = {}) {
  fs.mkdirSync(to, { recursive: true });
  for (const entry of fs.readdirSync(from, { withFileTypes: true })) {
    if (skip.includes(entry.name)) continue;
    const src = path.join(from, entry.name);
    const dst = path.join(to, entry.name);
    if (entry.isDirectory()) copyDir(src, dst, { skip });
    else if (entry.isFile()) fs.copyFileSync(src, dst);
  }
}

let copied = 0;
for (const { from, to } of COPY) {
  const src = path.join(ROOT, from);
  const dst = path.join(TARGET, to);
  if (!fs.existsSync(src)) {
    console.warn(`[prepare-functions] skip ${from} (missing)`);
    continue;
  }
  rmrf(dst);
  copyDir(src, dst, { skip: ['node_modules', '.DS_Store'] });
  const n = fs.readdirSync(dst, { recursive: true }).length;
  copied += n;
  console.log(`[prepare-functions] ${from} → firebase/functions-web/${to} (${n} entries)`);
}

/* The API needs the same runtime deps as the local server. Keep the list in
 * sync with the root package.json so a dependency can never be "works locally,
 * fails in the cloud" again. */
const rootPkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const fnPkgPath = path.join(TARGET, 'package.json');
const fnPkg = JSON.parse(fs.readFileSync(fnPkgPath, 'utf8'));

// Client-only packages must never ship in the function bundle: they bloat the
// cold start and have no business server-side.
const NOT_SERVER_SIDE = ['react', 'react-dom', 'react-router-dom', 'firebase', 'sharp'];

// Keep the cloud SDKs on the SAME versions as the local/tested root project.
// Older firebase-functions 6.x ships CJS-only subpaths that break the ESM
// `import { logger } from 'firebase-functions/logger'` at container startup.
fnPkg.dependencies = {
  ...rootPkg.dependencies,
};
for (const dep of NOT_SERVER_SIDE) delete fnPkg.dependencies[dep];

fnPkg.engines = { node: '22' };
fnPkg.main = 'index.js';
fnPkg.type = 'module';

fs.writeFileSync(fnPkgPath, JSON.stringify(fnPkg, null, 2) + '\n');
console.log('[prepare-functions] dependencies synced:', Object.keys(fnPkg.dependencies).join(', '));
console.log(`[prepare-functions] done (${copied} entries). Next: firebase deploy --only functions:web`);

/* Guard: multer + sharp are imported by admin routes. If sharp is removed we
 * must confirm no route still imports it statically. */
const adminRoute = fs.readFileSync(path.join(ROOT, 'server/routes/admin.js'), 'utf8');
if (/^import sharp from 'sharp';/m.test(adminRoute)) {
  console.log('[prepare-functions] NOTE: server/routes/admin.js imports sharp statically.');
  console.log('[prepare-functions]       that file is skipped in the cloud build, see API_SKIP below.');
}
