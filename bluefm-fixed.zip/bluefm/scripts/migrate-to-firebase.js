#!/usr/bin/env node
/**
 * BLUEFM — migration: local store  →  Firestore (web_*) + Backblaze B2.
 *
 * SAFETY
 *  • Writes ONLY to the same collections server/db.js reads (stories,
 *    episodes, favorites — optionally prefixed with FIRESTORE_PREFIX).
 *  • Never touches audiobooks, users, subscriptions, transactions, creators.
 *  • Refuses to overwrite an existing web_story unless --force.
 *  • Idempotent: re-running uploads only missing audio files.
 *
 * Usage:
 *   GOOGLE_APPLICATION_CREDENTIALS=./service-account.json \
 *   B2_KEY_ID=... B2_APP_KEY=... B2_BUCKET_ID=... B2_BUCKET_NAME=bluefm-web-audio \
 *   node scripts/migrate-to-firebase.js            # dry run
 *   node scripts/migrate-to-firebase.js --apply    # actually write
 *   node scripts/migrate-to-firebase.js --apply --force
 */
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const VERIFY = argv.includes('--verify');
const APPLY = argv.includes('--apply');
const FORCE = argv.includes('--force');
const PROJECT_ID = (argv.find((a) => a.startsWith('--project=')) || '').split('=')[1]
  || process.env.FIREBASE_PROJECT_ID
  || process.env.GCLOUD_PROJECT
  || 'nodio-575bf';
// Must match server/db.js#collectionName — the app reads these exact names.
const PREFIX = process.env.FIRESTORE_PREFIX || '';
const col = (t) => (PREFIX ? `${PREFIX}${t}` : t);
const ROOT = path.resolve(import.meta.dirname, '..');

const log = (...a) => console.log(APPLY ? '[apply]' : '[dry-run]', ...a);

/* ------------------------------------------------------------------ verify */
async function verify() {
  const admin = (await import('firebase-admin')).default;
  if (!admin.apps.length) {
    admin.initializeApp({
      credential: admin.credential.applicationDefault(),
      projectId: PROJECT_ID,
    });
  }
  const db = admin.firestore();

  console.log(`[verify] project: ${PROJECT_ID}`);
  console.log(`[verify] collections: ${col('stories')}, ${col('episodes')}, ${col('users')}`);

  const storiesSnap = await db.collection(col('stories')).where('status', '==', 'published').get();
  const epsSnap = await db.collection(col('episodes')).get();

  console.log(`[verify] published stories: ${storiesSnap.size}`);
  console.log(`[verify] episodes: ${epsSnap.size}`);

  if (storiesSnap.empty) {
    console.log('[verify] ✗ EMPTY — the website will show no stories.');
    console.log('[verify]   run: node scripts/migrate-to-firebase.js --apply');
    process.exitCode = 2;
    return;
  }

  const sample = storiesSnap.docs.slice(0, 5).map((d) => {
    const s = d.data();
    return `  • ${d.id.padEnd(18)} ${s.title} (${s.episodeCount || '?'} eps)`;
  });
  console.log('[verify] sample:');
  console.log(sample.join('\n'));

  const slugs = storiesSnap.docs.map((d) => d.data().slug).filter(Boolean);
  console.log(`[verify] slugs resolve for /api/stories/:slug → ${slugs.slice(0, 3).join(', ')}…`);

  // what the home page actually returns
  const featured = storiesSnap.docs.filter((d) => Number(d.data().featuredRank) > 0).length;
  console.log(`[verify] featured rail: ${featured} ${featured ? '✓' : '✗ (home rail will be empty)'}`);

  console.log('[verify] ✓ OK — the web app will render this catalogue.');
}

if (VERIFY) {
  await verify();
  process.exit(process.exitCode || 0);
}


async function main() {
  /* -------------------------------------------------------------- source */
  const dbFile = path.join(ROOT, 'data', 'db.json');
  if (!fs.existsSync(dbFile)) throw new Error(`Local store not found: ${dbFile}`);
  const local = JSON.parse(fs.readFileSync(dbFile, 'utf8'));

  const stories = Object.values(local.stories || {});
  const episodes = Object.values(local.episodes || {});
  const favorites = Object.values(local.favorites || {});
  log(`source: ${stories.length} stories, ${episodes.length} episodes, ${favorites.length} favourites`);

  /* ------------------------------------------------------------ firestore */
  let db = null;
  if (APPLY) {
    const admin = (await import('firebase-admin')).default;
    if (!admin.apps.length) admin.initializeApp({
      credential: admin.credential.applicationDefault(),
      projectId: PROJECT_ID,
    });
    log(`firestore project: ${PROJECT_ID} · collections: ${col('stories')}, ${col('episodes')}`);
    db = admin.firestore();
    log('firestore connected');
  }

  /* ------------------------------------------------------------------ B2 */
  const b2env = {
    keyId: process.env.B2_KEY_ID,
    appKey: process.env.B2_APP_KEY,
    bucketId: process.env.B2_BUCKET_ID,
    bucketName: process.env.B2_BUCKET_NAME || 'bluefm-web-audio',
  };

  async function b2Token() {
    const basic = Buffer.from(`${b2env.keyId}:${b2env.appKey}`).toString('base64');
    const r = await fetch('https://api.backblazeb2.com/b2api/v3/b2_authorize_account', {
      headers: { Authorization: `Basic ${basic}` },
    });
    const j = await r.json();
    if (!r.ok) throw new Error(`B2 authorize failed: ${j.message || r.status}`);
    return {
      token: j.authorizationToken,
      apiUrl: j.apiInfo?.storageApi?.apiUrl || j.apiUrl,
      accountId: j.accountId,
    };
  }

  async function b2Existing(auth) {
    const r = await fetch(`${auth.apiUrl}/b2api/v3/b2_list_file_names`, {
      method: 'POST',
      headers: { Authorization: auth.token, 'content-type': 'application/json' },
      body: JSON.stringify({ bucketId: b2env.bucketId, maxFileCount: 10000 }),
    });
    const j = await r.json();
    return new Set((j.files || []).map((f) => f.fileName));
  }

  async function b2Upload(auth, fileName, filePath) {
    const buf = fs.readFileSync(filePath);
    const u = await fetch(`${auth.apiUrl}/b2api/v3/b2_get_upload_url`, {
      method: 'POST',
      headers: { Authorization: auth.token, 'content-type': 'application/json' },
      body: JSON.stringify({ bucketId: b2env.bucketId }),
    });
    const ud = await u.json();
    if (!u.ok) throw new Error(`B2 upload url failed: ${ud.message || u.status}`);

    const sha1 = (await import('node:crypto')).createHash('sha1').update(buf).digest('hex');
    const up = await fetch(ud.uploadUrl, {
      method: 'POST',
      headers: {
        Authorization: ud.authorizationToken,
        'X-Bz-File-Name': encodeURIComponent(fileName).replace(/%2F/g, '/'),
        'Content-Type': 'audio/mpeg',
        'Content-Length': String(buf.length),
        'X-Bz-Content-Sha1': sha1,
      },
      body: buf,
    });
    const j = await up.json();
    if (!up.ok) throw new Error(`B2 upload failed: ${j.message || up.status}`);
    return j;
  }

  const canB2 = Boolean(b2env.keyId && b2env.appKey && b2env.bucketId);
  let auth = null;
  let existing = new Set();

  if (canB2) {
    auth = await b2Token();
    existing = await b2Existing(auth);
    log(`B2 authorised (bucket ${b2env.bucketName}), ${existing.size} objects present`);
  } else {
    log('B2 credentials missing — audio upload will be skipped');
  }

  /* ------------------------------------------------------------- uploads */
  let uploaded = 0;
  let skipped = 0;
  for (const ep of episodes) {
    const key = ep.audioKey || `${ep.id}.mp3`;
    const localFile = path.join(ROOT, 'data', 'media', 'audio', path.basename(key));

    if (!fs.existsSync(localFile)) {
      log(`  ! missing local audio for ${ep.id}`);
      continue;
    }
    if (existing.has(key)) { skipped++; continue; }

    if (!APPLY) { log(`  would upload ${key} (${(fs.statSync(localFile).size / 1024).toFixed(0)} kB)`); uploaded++; continue; }

    await b2Upload(auth, key, localFile);
    uploaded++;
    if (uploaded % 10 === 0) log(`  uploaded ${uploaded} files…`);
  }
  log(`audio: ${uploaded} ${APPLY ? 'uploaded' : 'to upload'}, ${skipped} already present`);

  /* -------------------------------------------------------------- stories */
  let storiesWritten = 0;
  for (const s of stories) {
    const doc = {
      slug: s.slug,
      title: s.title,
      author: s.author,
      narrator: s.narrator,
      tagline: s.tagline,
      synopsis: s.synopsis,
      description: s.description,
      genre: s.genre || [],
      language: s.language,
      tags: s.tags || [],
      coverKey: s.coverKey,
      lqip: s.lqip || '',
      rating: s.rating ?? 0,
      plays: s.plays ?? 0,
      featuredRank: s.featuredRank ?? 0,
      trending: Boolean(s.trending),
      isNew: Boolean(s.isNew),
      episodeCount: s.episodeCount || 0,
      totalDuration: s.totalDuration || 0,
      publishedAt: s.publishedAt,
      status: s.status || 'published',
      updatedAt: new Date().toISOString(),
      migratedFrom: 'local_store',
    };

    if (!APPLY) { storiesWritten++; continue; }

    const ref = db.collection(col('stories')).doc(s.id);
    const existingDoc = await ref.get();
    if (existingDoc.exists && !FORCE) { continue; }
    await ref.set(doc, { merge: true });
    storiesWritten++;
  }
  log(`stories: ${storiesWritten} ${APPLY ? 'written' : 'to write'}`);

  /* ------------------------------------------------------------- episodes */
  let episodesWritten = 0;
  for (const ep of episodes) {
    const doc = {
      storyId: ep.storyId,
      number: ep.number,
      title: ep.title,
      description: ep.description || '',
      audioKey: ep.audioKey || `${ep.id}.mp3`,
      storage: canB2 ? 'b2' : 'local',
      duration: ep.duration || 0,
      bytes: ep.bytes || 0,
      narrator: ep.narrator,
      publishedAt: ep.publishedAt,
      status: ep.status || 'published',
    };

    if (!APPLY) { episodesWritten++; continue; }
    await db.collection(col('episodes')).doc(ep.id).set(doc, { merge: true });
    episodesWritten++;
  }
  log(`episodes: ${episodesWritten} ${APPLY ? 'written' : 'to write'}`);

  /* ------------------------------------------------------------ favorites */
  let favWritten = 0;
  for (const f of favorites) {
    if (!APPLY) { favWritten++; continue; }
    await db.collection(col('favorites')).doc(f.id).set({
      userId: f.userId, storyId: f.storyId, createdAt: f.createdAt,
    }, { merge: true });
    favWritten++;
  }
  log(`favourites: ${favWritten} ${APPLY ? 'written' : 'to write'}`);

  log('done');
  if (!APPLY) log('run again with --apply to write changes');
}

main().catch((err) => {
  console.error('[migrate] failed:', err);
  process.exit(1);
});
