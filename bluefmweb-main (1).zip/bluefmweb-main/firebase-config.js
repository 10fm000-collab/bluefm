// firebase-config.js (CLEAN - compat)
(function () {
  const firebaseConfig = {
    apiKey: "AIzaSyAxXvJt6m-IK2G_EstbvYQZBj5wMBaqFeM",
    authDomain: "dreamfm-a6694.firebaseapp.com",
    projectId: "dreamfm-a6694",
    storageBucket: "dreamfm-a6694.firebasestorage.app",
    messagingSenderId: "634304814330",
    appId: "1:634304814330:web:e4fd0cd5e36276c37d3d43",
  };

  // Init once
  if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
  }

  // Globals
  window.auth = firebase.auth();
  window.db = firebase.firestore();

  // IMPORTANT: firebase-functions-compat.js must be loaded BEFORE this file
  window.functions = firebase.app().functions("us-central1");

  // Optional global
  if (typeof window.currentUser === "undefined") window.currentUser = null;

  console.log("✅ Firebase ready (auth/db/functions)");
})();