// ============================================
// CREATOR PROFILE LOGIC (Cashfree + Price Fix + Better Sub Check)
// ============================================

console.log("👤 Creator Profile Loading...");

let currentCreator = null;
let isSubscribed = false;
let creatorAudiobooks = [];

// ✅ UPDATED: ₹199 (poora catalog unlock)
const SUB_PRICE_RUPEES = 199;
const SUB_ORIGINAL_PRICE_RUPEES = 299;

// ============================================
// GET CREATOR ID FROM URL
// ============================================
function getCreatorIdFromUrl() {
  const params = new URLSearchParams(window.location.search);
  return params.get("id");
}

// ============================================
// LOAD CREATOR PROFILE
// ============================================
async function loadCreatorProfile() {
  const creatorId = getCreatorIdFromUrl();

  if (!creatorId) {
    document.getElementById("loadingContainer").innerHTML = `
      <div class="loading">
        <h3>❌ Invalid Creator ID</h3>
        <p>No creator specified</p>
      </div>
    `;
    return;
  }

  try {
    const creatorDoc = await db.collection("creators").doc(creatorId).get();

    if (!creatorDoc.exists) {
      document.getElementById("loadingContainer").innerHTML = `
        <div class="loading">
          <h3>❌ Creator Not Found</h3>
          <p>This creator doesn't exist</p>
        </div>
      `;
      return;
    }

    currentCreator = {
      uid: creatorDoc.id,
      ...creatorDoc.data(),
    };

    console.log("✅ Creator loaded:", currentCreator.channelName);

    // ✅ Check subscription (creator-specific OR all-app, dono cover ho jate hain
    // window.hasActiveSubscription se jo subscription.js me hai)
    if (typeof window.hasActiveSubscription === "function") {
      try {
        isSubscribed = await window.hasActiveSubscription(creatorId);
      } catch (e) {
        console.warn("hasActiveSubscription failed:", e);
        isSubscribed = false;
      }
    }

    displayCreatorProfile();
    loadCreatorAudiobooks(creatorId);
  } catch (error) {
    console.error("❌ Load error:", error);
    document.getElementById("loadingContainer").innerHTML = `
      <div class="loading">
        <h3>❌ Error Loading Profile</h3>
        <p>${error.message}</p>
      </div>
    `;
  }
}

// ============================================
// DISPLAY PROFILE
// ============================================
function displayCreatorProfile() {
  document.getElementById("loadingContainer").style.display = "none";
  document.getElementById("profileContainer").style.display = "block";

  const profileImage =
    currentCreator.profileImage ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(
      currentCreator.channelName
    )}&background=ab47bc&color=fff&size=300`;

  const avatarElement = document.getElementById("creatorAvatar");
  avatarElement.src = profileImage;

  avatarElement.onerror = function () {
    this.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(
      currentCreator.channelName
    )}&background=ab47bc&color=fff&size=300`;
  };

  document.getElementById("creatorName").textContent = currentCreator.channelName;
  document.getElementById("creatorBio").textContent =
    currentCreator.description || "Audiobook Creator";

  document.getElementById("totalBooks").textContent =
    currentCreator.totalAudiobooks || 0;
  document.getElementById("totalSubscribers").textContent =
    currentCreator.totalSubscribers || 0;
  document.getElementById("creatorRating").textContent = (
    currentCreator.rating || 0
  ).toFixed(1);

  const subscribeBtn = document.getElementById("subscribeBtn");

  if (isSubscribed) {
    subscribeBtn.className = "subscribe-btn subscribed";
    subscribeBtn.innerHTML = '<i class="fa-solid fa-check"></i> Subscribed';
  } else {
    subscribeBtn.className = "subscribe-btn";
    // ✅ Discount UI: strikethrough ₹299 → ₹199
    subscribeBtn.innerHTML = `
      <i class="fa-solid fa-crown"></i>
      <span style="text-decoration:line-through; opacity:0.65; font-size:0.85em; margin-left:6px;">₹${SUB_ORIGINAL_PRICE_RUPEES}</span>
      <span style="margin-left:6px;">₹${SUB_PRICE_RUPEES}/month</span>
    `;
  }
}

// ============================================
// LOAD CREATOR'S AUDIOBOOKS
// ============================================
async function loadCreatorAudiobooks(creatorId) {
  const container = document.getElementById("audiobooksGrid");

  try {
    const snapshot = await db
      .collection("audiobooks")
      .where("creatorId", "==", creatorId)
      .get();

    if (snapshot.empty) {
      container.innerHTML = `
        <div class="loading">
          <h3>📭 No Audiobooks Yet</h3>
          <p>This creator hasn't uploaded any audiobooks yet</p>
        </div>
      `;
      return;
    }

    creatorAudiobooks = [];
    let html = "";

    snapshot.forEach((doc) => {
      const book = { id: doc.id, ...doc.data() };
      creatorAudiobooks.push(book);

      html += `
        <div class="audiobook-card" onclick="openAudiobookByIndex(${creatorAudiobooks.length - 1})">
          <img src="${book.coverUrl}" alt="${book.title}" class="audiobook-cover"
               onerror="this.src='https://via.placeholder.com/150x200/ab47bc/FFFFFF?text=${encodeURIComponent(
                 book.title
               )}'">
          <div class="audiobook-info">
            <div class="audiobook-title">${book.title}</div>
            <div class="audiobook-author">${book.author || ""}</div>
            <div style="margin-top: 8px; font-size: 0.75rem; color: #10b981;">
              <i class="fa-solid fa-unlock"></i> First 10 Chapters FREE
            </div>
          </div>
        </div>
      `;
    });

    container.innerHTML = html;
    console.log(`✅ Loaded ${creatorAudiobooks.length} audiobooks`);
  } catch (error) {
    console.error("❌ Load audiobooks error:", error);
    container.innerHTML = `
      <div class="loading">
        <h3>❌ Error Loading Audiobooks</h3>
        <p>${error.message}</p>
      </div>
    `;
  }
}

// ============================================
// HANDLE SUBSCRIBE
// ============================================
function handleSubscribe() {
  if (!window.currentUser) {
    alert("Please login first");
    window.location.href = "login.html";
    return;
  }

  if (isSubscribed) {
    alert(`You're already subscribed to ${currentCreator.channelName}!`);
    return;
  }

  if (window.subscribeToCreator) {
    window.subscribeToCreator(currentCreator.uid, currentCreator.channelName);
  } else {
    alert("Subscription system not loaded");
  }
}

// ============================================
// OPEN AUDIOBOOK BY INDEX
// ============================================
function openAudiobookByIndex(index) {
  const book = creatorAudiobooks[index];

  if (!book) {
    console.error("❌ Book not found at index:", index);
    return;
  }

  console.log("🎵 Opening audiobook:", book.title);

  sessionStorage.setItem("autoPlayBook", JSON.stringify(book));
  window.location.href = `index.html#play-${book.id}`;
}

// ============================================
// INITIALIZE
// ============================================
document.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    loadCreatorProfile();
  }, 1000);
});

console.log("✅ Creator Profile Ready");
