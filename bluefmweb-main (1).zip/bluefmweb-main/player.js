// ============================================
// BLUEFM PLAYER v2 (Flutter PlayerScreen match) - SECURE + SUB DAILY QUOTA FIX
// - Coin unlock is server-side via Cloud Function: unlockChapterWithCoins
// - Unlocks are stored in Firestore: users/{uid}/chapter_unlocks/{bookId}
// - Stream URLs are signed via Cloud Function: getChapterStreamUrl
//
// FIXES ADDED:
// 1) If subscription daily limit error comes from getChapterStreamUrl,
//    player will SHOW coin unlock option (unlimited via coins).
// 2) Chapters sheet now shows: FREE / SUB (till unlockedUntil) / COIN
// ============================================

console.log("🎧 Player v2 loading (SECURE)...");

const PlayerState = {
  currentBook: null,
  currentChapter: 1,
  isPlaying: false,
  playbackSpeed: 1.0,
  blobUrl: null,

  // From Firestore:
  // [{ chapter: 11, until: 1710000000000 }, ...]
  unlockedChapters: [],

  likedBooks: [],
};

const FREE_CHAPTERS = 10;
const CHAPTER_COIN_COST = 10;
const SPEEDS = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0];

let audioEl = null;

// ============================================
// SECURE HELPERS (AUTH + UNLOCKS + COINS)
// ============================================

async function ensureAuthPlayer(timeoutMs = 5000) {
  if (window.currentUser) return window.currentUser;

  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    await new Promise((r) => setTimeout(r, 100));
    if (window.currentUser) return window.currentUser;
  }
  return null;
}

async function getUserCoinsLive() {
  const user = await ensureAuthPlayer();
  if (!user) return parseInt(localStorage.getItem("userCoins") || "0", 10);

  try {
    const snap = await db.collection("users").doc(user.uid).get();
    const coins = snap.exists ? snap.data().coins || 0 : 0;
    localStorage.setItem("userCoins", String(coins));
    return coins;
  } catch (e) {
    console.warn("getUserCoinsLive failed:", e);
    return parseInt(localStorage.getItem("userCoins") || "0", 10);
  }
}

async function loadUnlocksFromFirestore(bookId) {
  PlayerState.unlockedChapters = [];
  const user = await ensureAuthPlayer();
  if (!user || !bookId) return;

  try {
    const ref = db
      .collection("users")
      .doc(user.uid)
      .collection("chapter_unlocks")
      .doc(bookId);

    const snap = await ref.get();
    if (!snap.exists) return;

    const data = snap.data() || {};
    const chapters = data.chapters || {};
    const now = Date.now();

    const out = [];
    for (const [chStr, untilVal] of Object.entries(chapters)) {
      const ch = parseInt(chStr, 10);
      let untilMs = 0;

      if (untilVal && typeof untilVal.toDate === "function") {
        untilMs = untilVal.toDate().getTime();
      } else if (typeof untilVal === "string") {
        const t = Date.parse(untilVal);
        if (!isNaN(t)) untilMs = t;
      }

      if (Number.isInteger(ch) && untilMs > now) {
        out.push({ chapter: ch, until: untilMs });
      }
    }

    PlayerState.unlockedChapters = out;
  } catch (e) {
    console.warn("loadUnlocksFromFirestore failed:", e);
  }
}

function isChapterCoinUnlocked(chapterNum) {
  const now = Date.now();
  return PlayerState.unlockedChapters.some(
    (u) => u.chapter === chapterNum && u.until > now
  );
}

// ============================================
// ERROR HELPERS (Functions errors)
// ============================================

function extractErrorMessage(err) {
  // firebase-functions-compat errors often have message like:
  // "FirebaseError: ... (functions/failed-precondition)."
  const msg =
    err?.message ||
    (typeof err?.details === "string" ? err.details : "") ||
    String(err);

  return String(msg || "").trim();
}

function isDailyLimitErrorMessage(msg) {
  const m = (msg || "").toLowerCase();
  return (
    m.includes("daily limit") ||
    m.includes("unlocked until") ||
    m.includes("wait tomorrow")
  );
}

// ============================================
// SIGNED STREAM URL HELPER (Cloud Function)
// ============================================

async function getSignedStreamUrlForCurrentBook(chapterNum) {
  if (!window.functions) throw new Error("Functions not loaded");
  const book = PlayerState.currentBook;
  if (!book) throw new Error("No book");

  const fn = window.functions.httpsCallable("getChapterStreamUrl");
  const resp = await fn({ bookId: book.id, chapter: chapterNum });
  const url = resp.data?.url;
  if (!url) throw new Error("No stream url");
  return url;
}

// ============================================
// SUBSCRIPTION PROGRESS (UI only)
// - Reads users/{uid}/subscription_progress/{bookId}
// - Optionally triggers daily grant by calling getChapterStreamUrl(11)
//   (server updates doc + returns unlockedUntil)
// ============================================

function dateKeyISTClient() {
  const istMs = Date.now() + 330 * 60 * 1000; // +5:30
  const d = new Date(istMs);
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

async function getSubUnlockedUntilForCurrentBook() {
  const book = PlayerState.currentBook;
  const user = await ensureAuthPlayer();

  if (!book || !user) return FREE_CHAPTERS;
  if (!book.isPremium || !book.creatorId) return FREE_CHAPTERS;
  if (typeof window.hasActiveSubscription !== "function") return FREE_CHAPTERS;

  let hasSub = false;
  try {
    hasSub = await window.hasActiveSubscription(book.creatorId);
  } catch (_) {}
  if (!hasSub) return FREE_CHAPTERS;

  let unlockedUntil = FREE_CHAPTERS;
  let lastGrantDate = null;

  try {
    const snap = await db
      .collection("users")
      .doc(user.uid)
      .collection("subscription_progress")
      .doc(book.id)
      .get();

    if (snap.exists) {
      const data = snap.data() || {};
      unlockedUntil = Math.max(
        FREE_CHAPTERS,
        Number(data.unlockedUntil || FREE_CHAPTERS)
      );
      lastGrantDate = data.lastGrantDate || null;
    }
  } catch (_) {}

  // If not granted today, trigger server-side grant (safe) by requesting chapter 11
  const today = dateKeyISTClient();
  if (lastGrantDate !== today && window.functions) {
    try {
      const fn = window.functions.httpsCallable("getChapterStreamUrl");
      const r = await fn({ bookId: book.id, chapter: FREE_CHAPTERS + 1 });
      if (typeof r.data?.unlockedUntil === "number") {
        unlockedUntil = Math.max(unlockedUntil, r.data.unlockedUntil);
      }
    } catch (_) {
      // ignore (if any error)
    }
  }

  return unlockedUntil;
}

// ============================================
// INIT
// ============================================

document.addEventListener("DOMContentLoaded", initPlayer);

function initPlayer() {
  audioEl = document.getElementById("audioElement");
  if (!audioEl) {
    console.error("❌ audio element missing");
    return;
  }

  audioEl.controls = false;

  // Audio events
  audioEl.addEventListener("loadedmetadata", onMeta);
  audioEl.addEventListener("timeupdate", onTimeUpdate);
  audioEl.addEventListener("ended", onEnded);
  audioEl.addEventListener("error", onAudioError);
  audioEl.addEventListener("play", () => {
    PlayerState.isPlaying = true;
    syncPlayIcons();
    startRing();
  });
  audioEl.addEventListener("pause", () => {
    PlayerState.isPlaying = false;
    syncPlayIcons();
    stopRing();
  });

  // Mini player
  document
    .getElementById("miniPlayerInner")
    ?.addEventListener("click", openFullPlayer);
  document.getElementById("miniPlayBtn")?.addEventListener("click", (e) => {
    e.stopPropagation();
    togglePlay();
  });
  document.getElementById("miniSpeedBtn")?.addEventListener("click", (e) => {
    e.stopPropagation();
    cycleSpeed();
  });

  // Full player controls
  document.getElementById("fpCloseBtn")?.addEventListener("click", closeFullPlayer);
  document.getElementById("fpPlayBtn")?.addEventListener("click", togglePlay);
  document.getElementById("fpPrevChapter")?.addEventListener("click", prevChapter);
  document.getElementById("fpNextChapter")?.addEventListener("click", nextChapter);
  document.getElementById("fpRewind15")?.addEventListener("click", () => seekRelative(-15));
  document.getElementById("fpForward15")?.addEventListener("click", () => seekRelative(15));
  document.getElementById("fpSeekBar")?.addEventListener("input", onSeek);
  document.getElementById("fpLikeBtn")?.addEventListener("click", toggleLike);

  // Speed pills
  document.getElementById("fpSpeedPills")?.addEventListener("click", (e) => {
    const btn = e.target.closest(".fp-speed-pill");
    if (btn) setSpeed(parseFloat(btn.dataset.speed));
  });

  // All chapters button
  document.getElementById("fpAllChaptersBtn")?.addEventListener("click", () => {
    openChaptersSheet();
  });

  // Sheet overlay close
  document.getElementById("fpSheetOverlay")?.addEventListener("click", closeChaptersSheet);

  // Liked books from storage
  PlayerState.likedBooks = JSON.parse(localStorage.getItem("likedBooks") || "[]");

  console.log("✅ Player v2 ready (SECURE)");
}

// ============================================
// PLAY AUDIOBOOK (called from app.js)
// ============================================

window.playAudiobook = async function (bookId, bookData) {
  console.log("🎵 Playing:", bookData.title);

  PlayerState.currentBook = { id: bookId, ...bookData };
  PlayerState.currentChapter = 1;

  updateAllUI();
  showMiniPlayer();
  openFullPlayer();

  await loadUnlocksFromFirestore(bookId);
  await loadChapter(1);
};

window.playAudiobookAtChapter = async function (bookId, bookData, startChapter) {
  console.log(`🎵 Playing: ${bookData.title} — Chapter ${startChapter}`);

  PlayerState.currentBook = { id: bookId, ...bookData };
  PlayerState.currentChapter = startChapter;

  updateAllUI();
  showMiniPlayer();
  openFullPlayer();

  await loadUnlocksFromFirestore(bookId);
  await loadChapter(startChapter);
};

// ============================================
// LOAD CHAPTER
// ============================================

async function loadChapter(chapterNum) {
  const book = PlayerState.currentBook;
  if (!book) return;

  // Free check
  if (chapterNum <= FREE_CHAPTERS) {
    await fetchAndPlayChapter(chapterNum);
    return;
  }

  // Coin-unlocked?
  if (isChapterCoinUnlocked(chapterNum)) {
    await fetchAndPlayChapter(chapterNum);
    return;
  }

  // Subscription check (daily quota is enforced by getChapterStreamUrl)
  if (book.creatorId && book.isPremium && typeof window.hasActiveSubscription === "function") {
    try {
      const hasSub = await window.hasActiveSubscription(book.creatorId);
      if (hasSub) {
        await fetchAndPlayChapter(chapterNum);
        return;
      }
    } catch (_) {}
  }

  // Not subscribed: show coin unlock
  await showCoinUnlockSheet(chapterNum);
}

// ============================================
// FETCH AND PLAY CHAPTER (Signed URL via Cloud Function)
// ============================================

async function fetchAndPlayChapter(chapterNum) {
  const book = PlayerState.currentBook;
  if (!book) return;

  // Old blob cleanup (not used now)
  if (PlayerState.blobUrl) {
    URL.revokeObjectURL(PlayerState.blobUrl);
    PlayerState.blobUrl = null;
  }

  PlayerState.currentChapter = chapterNum;
  updateAllUI();

  try {
    showToast(`📖 Loading Chapter ${chapterNum}...`);

    const signedUrl = await getSignedStreamUrlForCurrentBook(chapterNum);

    audioEl.src = signedUrl;
    audioEl.playbackRate = PlayerState.playbackSpeed;
    audioEl.load();

    try {
      await audioEl.play();
    } catch (e) {
      console.warn("Autoplay blocked:", e);
    }
  } catch (err) {
    console.error(err);
    const msg = extractErrorMessage(err);

    // ✅ FIX: If daily quota reached (or locked by subscription rules),
    // allow user to unlock with coins (unlimited).
    if (chapterNum > FREE_CHAPTERS && isDailyLimitErrorMessage(msg)) {
      showToast("Daily limit reached. You can unlock with coins.");
      await showCoinUnlockSheet(chapterNum);
      return;
    }

    // Also if backend says locked (subscribe/coins), show coin unlock sheet
    if (chapterNum > FREE_CHAPTERS && msg.toLowerCase().includes("locked")) {
      await showCoinUnlockSheet(chapterNum);
      return;
    }

    showToast("❌ " + msg);
  }
}

// ============================================
// COIN UNLOCK SHEET (SECURE - server-side deduct + unlock)
// Cloud Function: unlockChapterWithCoins
// ============================================

async function showCoinUnlockSheet(chapterNum) {
  const book = PlayerState.currentBook;
  if (!book) return;

  const user = await ensureAuthPlayer();
  if (!user) {
    showToast("❌ Please login to unlock chapters");
    return;
  }

  if (!window.functions) {
    showToast("❌ Firebase Functions not loaded");
    return;
  }

  const coins = await getUserCoinsLive();
  const canAfford = coins >= CHAPTER_COIN_COST;

  const confirmed = await new Promise((resolve) => {
    const overlay = document.createElement("div");
    overlay.style.cssText = `
      position:fixed; inset:0; background:rgba(0,0,0,0.55); z-index:4000;
      display:flex; align-items:flex-end;
    `;

    overlay.innerHTML = `
      <div style="width:100%; background:var(--bg-card);
                  border-radius:24px 24px 0 0;
                  padding: 0 18px 28px;
                  font-family: inherit;">
        <div style="width:40px;height:4px;background:rgba(255,255,255,0.24);
                    border-radius:2px;margin:10px auto 16px;"></div>

        <div style="font-size:16px;font-weight:900;margin-bottom:10px;">
          Unlock Chapter
        </div>

        <div style="font-size:14px;color:var(--text-gray-light);
                    margin-bottom:18px;line-height:1.5;">
          Unlock Chapter ${chapterNum} for <strong>${CHAPTER_COIN_COST} coins</strong>?<br>
          You have <strong>${coins} coins</strong>.
        </div>

        <div style="display:flex;gap:10px;">
          <button id="_unlockCancel" style="
            flex:1; padding:14px; border-radius:12px;
            border:1px solid rgba(255,255,255,0.12);
            background:transparent; color:#fff;
            font-size:14px; font-weight:900; font-family:inherit; cursor:pointer;
          ">Cancel</button>

          <button id="_unlockConfirm" style="
            flex:1; padding:14px; border-radius:12px;
            border:none;
            background: ${
              canAfford
                ? "linear-gradient(135deg,var(--primary),var(--secondary))"
                : "rgba(255,255,255,0.10)"
            };
            color: ${canAfford ? "#fff" : "var(--text-gray-light)"};
            font-size:14px; font-weight:900; font-family:inherit;
            cursor: ${canAfford ? "pointer" : "not-allowed"};
          ">${canAfford ? "Unlock" : "Not Enough Coins"}</button>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    overlay.querySelector("#_unlockCancel").onclick = () => {
      overlay.remove();
      resolve(false);
    };
    overlay.querySelector("#_unlockConfirm").onclick = () => {
      if (!canAfford) return;
      overlay.remove();
      resolve(true);
    };
    overlay.onclick = (e) => {
      if (e.target === overlay) {
        overlay.remove();
        resolve(false);
      }
    };
  });

  if (!confirmed) return;

  try {
    showToast("⏳ Unlocking...");

    const fn = window.functions.httpsCallable("unlockChapterWithCoins");
    const resp = await fn({ bookId: book.id, chapter: chapterNum });

    const data = resp.data || {};
    if (!data.success) throw new Error("Unlock failed");

    if (typeof data.newBalance === "number") {
      localStorage.setItem("userCoins", String(data.newBalance));
    }

    // Refresh unlock cache from server
    await loadUnlocksFromFirestore(book.id);

    showToast(
      data.alreadyUnlocked
        ? `✅ Chapter ${chapterNum} already unlocked`
        : `✅ Chapter ${chapterNum} unlocked! (-${CHAPTER_COIN_COST} coins)`
    );

    // Play now (signed URL should now be returned in "coin" mode by backend)
    await fetchAndPlayChapter(chapterNum);
  } catch (err) {
    console.error(err);
    const msg = extractErrorMessage(err);

    if (msg.toLowerCase().includes("not enough coins")) showToast("❌ Not enough coins!");
    else showToast("❌ Unlock failed: " + msg);
  }
}

// ============================================
// PLAY / PAUSE / CONTROLS
// ============================================

function togglePlay() {
  if (!audioEl.src || audioEl.src === window.location.href) {
    if (PlayerState.currentBook) loadChapter(PlayerState.currentChapter);
    return;
  }
  if (audioEl.paused) {
    audioEl.play().catch((e) => showToast("❌ Play failed: " + e.message));
  } else {
    audioEl.pause();
  }
}

function prevChapter() {
  if (PlayerState.currentChapter > 1) loadChapter(PlayerState.currentChapter - 1);
  else showToast("Already at first chapter");
}

function nextChapter() {
  const book = PlayerState.currentBook;
  if (book && PlayerState.currentChapter < book.totalChapters) {
    loadChapter(PlayerState.currentChapter + 1);
  } else {
    showToast("No more chapters");
  }
}

function seekRelative(secs) {
  const d = audioEl.duration || 0;
  audioEl.currentTime = Math.max(0, Math.min(d, (audioEl.currentTime || 0) + secs));
}

function onSeek(e) {
  const d = audioEl.duration || 0;
  if (d > 0) audioEl.currentTime = (e.target.value / 100) * d;
}

function cycleSpeed() {
  const idx = SPEEDS.indexOf(PlayerState.playbackSpeed);
  setSpeed(SPEEDS[(idx + 1) % SPEEDS.length]);
}

function setSpeed(s) {
  PlayerState.playbackSpeed = s;
  audioEl.playbackRate = s;

  const miniSpd = document.getElementById("miniSpeedBtn");
  if (miniSpd) miniSpd.textContent = `${s}x`;

  document.querySelectorAll(".fp-speed-pill").forEach((btn) => {
    btn.classList.toggle("active", parseFloat(btn.dataset.speed) === s);
  });
}

// ============================================
// AUDIO EVENT HANDLERS
// ============================================

function onMeta() {
  updateSeekUI();
}

function onTimeUpdate() {
  updateSeekUI();
}

function updateSeekUI() {
  const cur = audioEl.currentTime || 0;
  const dur = audioEl.duration || 0;
  const pct = dur > 0 ? (cur / dur) * 100 : 0;

  const fill = document.getElementById("miniProgressFill");
  if (fill) fill.style.width = pct + "%";

  const seek = document.getElementById("fpSeekBar");
  if (seek) seek.value = pct;

  const ct = document.getElementById("fpCurrentTime");
  const dt = document.getElementById("fpDuration");
  if (ct) ct.textContent = formatTime(cur);
  if (dt) dt.textContent = formatTime(dur);
}

function onEnded() {
  PlayerState.isPlaying = false;
  syncPlayIcons();
  stopRing();
  setTimeout(nextChapter, 1000);
}

function onAudioError() {
  showToast("❌ Audio error. Check chapter availability.");
  PlayerState.isPlaying = false;
  syncPlayIcons();
  stopRing();
}

// ============================================
// UI UPDATES
// ============================================

function updateAllUI() {
  const book = PlayerState.currentBook;
  if (!book) return;

  const ch = PlayerState.currentChapter;
  const coverUrl = book.coverUrl || book.safeCoverUrl || "";
  const author = book.creatorName || book.author || "Unknown";

  const miniCover = document.getElementById("miniCover");
  const miniCh = document.getElementById("miniChapterLabel");
  const miniLabel = document.getElementById("miniBookLabel");
  const miniSpeed = document.getElementById("miniSpeedBtn");

  if (miniCover) miniCover.src = coverUrl;
  if (miniCh) miniCh.textContent = `Chapter ${ch}`;
  if (miniLabel) miniLabel.textContent = `${book.title} · ${author}`;
  if (miniSpeed) miniSpeed.textContent = `${PlayerState.playbackSpeed}x`;

  const fpCover = document.getElementById("fpCoverImg");
  const fpBg = document.getElementById("fpBg");
  const fpTitle = document.getElementById("fpBookTitle");
  const fpSub = document.getElementById("fpBookSub");

  if (fpCover) fpCover.src = coverUrl;
  if (fpBg) fpBg.style.backgroundImage = `url('${coverUrl}')`;
  if (fpTitle) fpTitle.textContent = book.title;
  if (fpSub) fpSub.textContent = `By ${author} • Chapter ${ch} of ${book.totalChapters}`;

  updateLikeIcon();
  renderChapterChips();
}

function syncPlayIcons() {
  const playing = PlayerState.isPlaying;
  const iconClass = playing ? "fa-solid fa-pause" : "fa-solid fa-play";

  const miniIcon = document.getElementById("miniPlayIcon");
  const fpIcon = document.getElementById("fpPlayIcon");
  if (miniIcon) miniIcon.className = iconClass;
  if (fpIcon) fpIcon.className = iconClass;
}

function startRing() {
  const ring = document.getElementById("fpArtRing");
  if (ring) ring.classList.add("spinning");
}

function stopRing() {
  const ring = document.getElementById("fpArtRing");
  if (ring) ring.classList.remove("spinning");
}

// ============================================
// CHAPTER CHIPS (Quick navigation)
// ============================================

function renderChapterChips() {
  const book = PlayerState.currentBook;
  if (!book) return;

  const ch = PlayerState.currentChapter;
  const total = book.totalChapters || 1;

  const start = Math.max(1, ch - 2);
  const end = Math.min(total, start + 5);

  const chips = document.getElementById("fpChapterChips");
  if (!chips) return;

  let html = "";
  for (let i = start; i <= end; i++) {
    html += `<button class="fp-chapter-chip ${i === ch ? "active" : ""}"
                     onclick="handleChapterChipClick(${i})">
               Ch ${i}
             </button>`;
  }
  chips.innerHTML = html;
}

window.handleChapterChipClick = function (chapterNum) {
  loadChapter(chapterNum);
};

// ============================================
// CHAPTERS SHEET (FREE / SUB / COIN)
// ============================================

async function openChaptersSheet() {
  const book = PlayerState.currentBook;
  if (!book) return;

  await loadUnlocksFromFirestore(book.id);

  // ✅ NEW: compute subscription unlockedUntil (UI)
  const subUnlockedUntil = await getSubUnlockedUntilForCurrentBook();

  const title = document.getElementById("fpSheetTitle");
  if (title) title.textContent = `Chapters (${book.totalChapters})`;

  const list = document.getElementById("fpSheetList");
  if (!list) return;

  let html = "";
  for (let i = 1; i <= book.totalChapters; i++) {
    const ch = i;
    const isCurrent = ch === PlayerState.currentChapter;
    const isFree = ch <= FREE_CHAPTERS;

    const coinUnlocked = isChapterCoinUnlocked(ch);
    const viaSub =
      book.isPremium &&
      ch > FREE_CHAPTERS &&
      subUnlockedUntil >= ch; // ✅ only till unlockedUntil

    let icon, tag, tagColor;

    if (isCurrent) {
      icon = "▶";
      tag = "Playing";
      tagColor = "var(--secondary)";
    } else if (isFree) {
      icon = "🔓";
      tag = "FREE";
      tagColor = "#10B981";
    } else if (viaSub) {
      icon = "👑";
      tag = "SUB";
      tagColor = "var(--secondary)";
    } else if (coinUnlocked) {
      icon = "🔓";
      tag = "Unlocked";
      tagColor = "var(--secondary)";
    } else {
      icon = "🔒";
      tag = `🪙 ${CHAPTER_COIN_COST}`;
      tagColor = "#F59E0B";
    }

    html += `
      <div class="fp-sheet-item ${isCurrent ? "current" : ""}"
           onclick="handleSheetChapterClick(${ch})">
        <div class="fp-sheet-item-icon">${icon}</div>
        <div class="fp-sheet-item-title">Chapter ${ch}</div>
        <div class="fp-sheet-item-tag" style="color:${tagColor}">${tag}</div>
      </div>`;
  }

  list.innerHTML = html;

  document.getElementById("fpSheetOverlay")?.classList.add("open");
  document.getElementById("fpChaptersSheet")?.classList.add("open");
}

function closeChaptersSheet() {
  document.getElementById("fpSheetOverlay")?.classList.remove("open");
  document.getElementById("fpChaptersSheet")?.classList.remove("open");
}

window.handleSheetChapterClick = function (ch) {
  closeChaptersSheet();
  loadChapter(ch);
};

// ============================================
// LIKE / BOOKMARK
// ============================================

function toggleLike() {
  const book = PlayerState.currentBook;
  if (!book) return;

  let liked = JSON.parse(localStorage.getItem("likedBooks") || "[]");
  const existIdx = liked.findIndex((b) => (b.id || b) === book.id);

  if (existIdx >= 0) {
    liked.splice(existIdx, 1);
    showToast("Removed from library");
  } else {
    liked.push({
      id: book.id,
      title: book.title,
      author: book.author,
      coverUrl: book.coverUrl,
    });
    showToast("❤️ Saved to library");
  }

  localStorage.setItem("likedBooks", JSON.stringify(liked));
  PlayerState.likedBooks = liked;
  updateLikeIcon();
}

function updateLikeIcon() {
  const book = PlayerState.currentBook;
  const liked = JSON.parse(localStorage.getItem("likedBooks") || "[]");
  const isLiked = liked.some((b) => (b.id || b) === book?.id);

  const icon = document.getElementById("fpLikeIcon");
  if (icon) {
    icon.className = isLiked ? "fa-solid fa-bookmark" : "fa-regular fa-bookmark";
    icon.closest("button")?.classList.toggle("fp-liked", isLiked);
  }
}

// ============================================
// SHOW / HIDE PLAYER
// ============================================

function showMiniPlayer() {
  const mp = document.getElementById("miniPlayer");
  if (mp) mp.style.display = "block";
}

function openFullPlayer() {
  const fp = document.getElementById("fullPlayer");
  if (fp) fp.classList.add("open");
  document.body.style.overflow = "hidden";
}

function closeFullPlayer() {
  const fp = document.getElementById("fullPlayer");
  if (fp) fp.classList.remove("open");
  document.body.style.overflow = "";
}

// ============================================
// HELPERS
// ============================================

function formatTime(secs) {
  if (!secs || isNaN(secs)) return "0:00";
  const m = Math.floor(secs / 60);
  const s = Math.floor(secs % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}

function showToast(msg) {
  const old = document.querySelector(".toast-notification");
  if (old) old.remove();
  const t = document.createElement("div");
  t.className = "toast-notification";
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.classList.add("show"), 80);
  setTimeout(() => {
    t.classList.remove("show");
    setTimeout(() => t.remove(), 300);
  }, 3000);
}

window.addEventListener("beforeunload", () => {
  if (PlayerState.blobUrl) URL.revokeObjectURL(PlayerState.blobUrl);
});

// Security: no right-click on audio
document.addEventListener("contextmenu", (e) => {
  if (e.target.tagName === "AUDIO") e.preventDefault();
});

console.log("✅ Player v2 ready (SECURE - server unlocks + signed stream URLs + daily quota fix)");