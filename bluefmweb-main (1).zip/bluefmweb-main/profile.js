// ============================================
// PROFILE PAGE (Flutter ProfileScreen match) - UPDATED (Back fix + BlueFM text)
// ============================================

window.loadProfilePage = function () {
  const mainContent = document.getElementById('mainContent');
  const user = window.currentUser;

  if (!user) {
    mainContent.innerHTML = `
      <div style="display:flex;flex-direction:column;align-items:center;
                  justify-content:center;min-height:60vh;gap:16px;
                  font-family:inherit;">
        <div style="font-size:54px;">🔒</div>
        <div style="font-size:18px;font-weight:900;color:#fff;">Not logged in</div>
        <button onclick="window.location.href='login.html'"
                style="padding:12px 28px;border-radius:18px;border:none;
                       background:linear-gradient(135deg,var(--primary),var(--secondary));
                       color:#fff;font-weight:900;font-size:14px;
                       cursor:pointer;font-family:inherit;">
          Login
        </button>
      </div>`;
    return;
  }

  // Coins from Firestore (if available) or localStorage
  const coins = window.__userCoins !== undefined
    ? window.__userCoins
    : parseInt(localStorage.getItem('userCoins') || '0', 10);

  const initial = ((user.displayName || user.email || 'U')[0] || 'U').toUpperCase();

  mainContent.innerHTML = `
  <div class="profile-page-v2">

    <!-- Topbar -->
    <div class="pv2-topbar">
      <button class="pv2-back-btn" onclick="goBackFromProfile()">
        <i class="fa-solid fa-arrow-left"></i>
      </button>
      <div class="pv2-topbar-title">Profile</div>
      <div style="width:40px;"></div>
    </div>

    <!-- Avatar + Name -->
    <div class="pv2-avatar-section">
      <div class="pv2-avatar">${initial}</div>
      <div class="pv2-name">${escPr(user.displayName || 'User')}</div>
      <div class="pv2-email">${escPr(user.email || '')}</div>
    </div>

    <!-- Coins mini card -->
    <div class="pv2-coins-card">
      <div class="pv2-coins-icon">🪙</div>
      <div class="pv2-coins-info">
        <div class="pv2-coins-num" id="profileCoinsNum">${coins} Coins</div>
        <div class="pv2-coins-hint">Balance · Buy coins in My Store</div>
      </div>
    </div>

    <!-- Settings tiles -->
    <div class="pv2-tiles">

      <div class="pv2-tile" onclick="openLanguageSheet()">
        <div class="pv2-tile-icon">
          <i class="fa-solid fa-language"></i>
        </div>
        <div class="pv2-tile-text">
          <div class="pv2-tile-title">Language</div>
          <div class="pv2-tile-sub" id="langLabel">English</div>
        </div>
        <i class="fa-solid fa-chevron-right pv2-tile-arrow"></i>
      </div>

      <div class="pv2-tile" onclick="window.location.href='privacy.html'">
        <div class="pv2-tile-icon">
          <i class="fa-solid fa-shield-halved"></i>
        </div>
        <div class="pv2-tile-text">
          <div class="pv2-tile-title">Privacy Policy</div>
          <div class="pv2-tile-sub">How we handle your data</div>
        </div>
        <i class="fa-solid fa-chevron-right pv2-tile-arrow"></i>
      </div>

      <div class="pv2-tile" onclick="window.location.href='terms.html'">
        <div class="pv2-tile-icon">
          <i class="fa-solid fa-file-contract"></i>
        </div>
        <div class="pv2-tile-text">
          <div class="pv2-tile-title">Terms of Service</div>
          <div class="pv2-tile-sub">Rules for using BlueFM</div>
        </div>
        <i class="fa-solid fa-chevron-right pv2-tile-arrow"></i>
      </div>

      <div class="pv2-tile" onclick="window.location.href='refund.html'">
        <div class="pv2-tile-icon">
          <i class="fa-solid fa-rotate-left"></i>
        </div>
        <div class="pv2-tile-text">
          <div class="pv2-tile-title">Refund & Cancellation</div>
          <div class="pv2-tile-sub">Subscriptions & coin top-ups</div>
        </div>
        <i class="fa-solid fa-chevron-right pv2-tile-arrow"></i>
      </div>

      <div class="pv2-tile" onclick="showToastPr('BlueFM')">
        <div class="pv2-tile-icon">
          <i class="fa-solid fa-circle-info"></i>
        </div>
        <div class="pv2-tile-text">
          <div class="pv2-tile-title">About</div>
          <div class="pv2-tile-sub">BlueFM</div>
        </div>
        <i class="fa-solid fa-chevron-right pv2-tile-arrow"></i>
      </div>

      ${isAdminUserPr() ? `
      <div class="pv2-tile" onclick="window.location.href='admin-dashboard.html'">
        <div class="pv2-tile-icon" style="background:rgba(124,58,237,0.15);">
          <i class="fa-solid fa-shield-halved" style="color:var(--primary);"></i>
        </div>
        <div class="pv2-tile-text">
          <div class="pv2-tile-title">Admin Panel</div>
          <div class="pv2-tile-sub">Manage content</div>
        </div>
        <i class="fa-solid fa-chevron-right pv2-tile-arrow"></i>
      </div>` : ''}

    </div>

    <!-- Logout -->
    <div style="padding: 8px 16px 40px;">
      <button class="pv2-logout-btn" onclick="handleProfileLogout()">
        <i class="fa-solid fa-right-from-bracket"></i>
        Logout
      </button>
    </div>

  </div>

  <!-- Language Sheet -->
  <div id="langSheetOverlay" style="display:none;position:fixed;inset:0;
       background:rgba(0,0,0,0.55);z-index:4000;"
       onclick="closeLangSheet()"></div>

  <div id="langSheet" style="
      display:none;
      position:fixed;bottom:0;left:0;right:0;
      background:var(--bg-card);
      border-radius:22px 22px 0 0;
      z-index:4001;
      padding:0 16px 32px;
      font-family:inherit;
      transform:translateY(100%);
      transition:transform 0.3s ease;
  ">
    <div style="width:40px;height:4px;background:rgba(255,255,255,0.20);
                border-radius:2px;margin:12px auto 16px;"></div>
    <div style="font-size:16px;font-weight:900;color:#fff;margin-bottom:12px;">
      Select Language
    </div>
    <div class="pv2-lang-tile active" id="langEn" onclick="selectLang('English')">
      <span>English</span>
      <i class="fa-solid fa-circle-check" style="color:var(--secondary);"></i>
    </div>
    <div class="pv2-lang-tile" id="langHi" onclick="selectLang('Hindi')">
      <span>Hindi</span>
    </div>
  </div>`;

  // Load coins from Firestore
  loadUserCoins();
};

// ============================================
// LOAD USER COINS FROM FIRESTORE
// ============================================
async function loadUserCoins() {
  const user = window.currentUser;
  if (!user) return;

  try {
    const doc = await db.collection('users').doc(user.uid).get();
    if (doc.exists) {
      const coins = doc.data().coins || 0;
      window.__userCoins = coins;
      localStorage.setItem('userCoins', coins.toString());

      const el = document.getElementById('profileCoinsNum');
      if (el) el.textContent = `${coins} Coins`;
    }
  } catch (e) {
    console.warn('Coins load:', e);
  }
}

// ============================================
// LANGUAGE SHEET
// ============================================
let __selectedLang = localStorage.getItem('appLang') || 'English';

window.openLanguageSheet = function () {
  const overlay = document.getElementById('langSheetOverlay');
  const sheet = document.getElementById('langSheet');
  if (!overlay || !sheet) return;

  overlay.style.display = 'block';
  sheet.style.display = 'block';

  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      sheet.style.transform = 'translateY(0)';
    });
  });

  updateLangTiles();
};

window.closeLangSheet = function () {
  const overlay = document.getElementById('langSheetOverlay');
  const sheet = document.getElementById('langSheet');
  if (!sheet) return;

  sheet.style.transform = 'translateY(100%)';
  setTimeout(() => {
    if (overlay) overlay.style.display = 'none';
    if (sheet) sheet.style.display = 'none';
  }, 300);
};

window.selectLang = function (lang) {
  __selectedLang = lang;
  localStorage.setItem('appLang', lang);

  const label = document.getElementById('langLabel');
  if (label) label.textContent = lang;

  updateLangTiles();
  closeLangSheet();
};

function updateLangTiles() {
  const enTile = document.getElementById('langEn');
  const hiTile = document.getElementById('langHi');

  if (enTile) enTile.classList.toggle('active', __selectedLang === 'English');
  if (hiTile) hiTile.classList.toggle('active', __selectedLang === 'Hindi');
}

// ============================================
// LOGOUT
// ============================================
window.handleProfileLogout = async function () {
  if (!confirm('Logout karna chahte ho?')) return;

  try {
    // Stop player
    const audioEl = document.getElementById('audioElement');
    if (audioEl) { audioEl.pause(); audioEl.src = ''; }

    await window.auth.signOut();
    window.location.href = 'login.html';
  } catch (e) {
    showToastPr('❌ Logout failed: ' + e.message);
  }
};

// ============================================
// BACK from profile (UPDATED for hash-router)
// ============================================
window.goBackFromProfile = function () {
  // ✅ app.js me goBackInApp add kiya hai — wahi use karo
  if (typeof window.goBackInApp === 'function') window.goBackInApp('#home');
  else window.location.hash = '#home';
};

// ============================================
// HELPERS
// ============================================
function isAdminUserPr() {
  const ADMIN_EMAILS = ['vikassingh44999@gmail.com'];
  return window.currentUser && ADMIN_EMAILS.includes(window.currentUser.email);
}

function escPr(s) {
  return String(s ?? '')
    .replaceAll('&', '&amp;').replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;').replaceAll('"', '&quot;');
}

function showToastPr(msg) {
  const old = document.querySelector('.toast-notification');
  if (old) old.remove();
  const t = document.createElement('div');
  t.className = 'toast-notification';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.classList.add('show'), 80);
  setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, 3000);
}

console.log('✅ Profile page ready (updated)');