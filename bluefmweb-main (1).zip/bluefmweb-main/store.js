// ============================================
// MY STORE (SECURE) - Coins + All-App Plans via CASHFREE
// ============================================

console.log("🛍️ Store.js loaded (Cashfree coins + all-app plans)...");

const COIN_PACKAGES = [
  { price: 10, coins: 300, bonus: "" },
  { price: 29, coins: 1000, bonus: "" },
  { price: 49, coins: 1800, bonus: "" },
  { price: 99, coins: 4000, bonus: "" },
];

window.loadStorePage = function () {
  const mainContent = document.getElementById("mainContent");

  mainContent.innerHTML = `
    <div class="store-page-v2">

      <div class="store-topbar">
        <div class="store-title">My Store</div>
      </div>

      <div class="store-balance-card">
        <div class="store-balance-icon-box">🪙</div>
        <div class="store-balance-info">
          <div class="store-balance-num" id="storeCoinsNum">...</div>
          <div class="store-balance-label">Current balance</div>
        </div>
        <span style="font-size:20px; color:rgba(0,0,0,0.20);">✨</span>
      </div>

      <div class="store-section-head">
        <div class="store-section-title">Packages</div>
        <div class="store-secure-badge">
          <i class="fa-solid fa-shield-halved" style="color:#10B981;font-size:12px;"></i>
          <span>Secure via Cashfree</span>
        </div>
      </div>

      <div class="store-packages" id="storePackages">
        ${COIN_PACKAGES.map(renderPackageTile).join("")}
      </div>

      <!-- ✅ NEW: All-App Membership Section (₹299 / ₹499) -->
      <div class="store-section-head" style="margin-top:22px;">
        <i class="fa-solid fa-crown" style="color:var(--secondary);font-size:16px;"></i>
        <div class="store-section-title">All-Access Membership</div>
      </div>
      <p style="color:#b0b0b0;font-size:0.8rem;margin:4px 0 14px;">
        Unlock ALL creators' stories with one plan.
      </p>

      <div id="allAppPlansMount">
        <div class="loading-container" style="padding:20px 0;">
          <div class="loading-spinner"></div>
        </div>
      </div>

      <div class="store-section-head" style="margin-top:22px;">
        <i class="fa-solid fa-crown" style="color:var(--secondary);font-size:16px;"></i>
        <div class="store-section-title">My Subscriptions</div>
      </div>

      <div id="storeSubsMount">
        <div class="loading-container" style="padding:20px 0;">
          <div class="loading-spinner"></div>
        </div>
      </div>

    </div>
  `;

  refreshCoinsBalance();
  loadAllAppPlans();
  loadStoreSubscriptions();
};

function renderPackageTile(pkg) {
  const isPopular = pkg.price === 49;
  const isBest = pkg.price === 99;

  const badgeHtml = isBest
    ? `<span class="pkg-badge pkg-badge--best">BEST</span>`
    : isPopular
      ? `<span class="pkg-badge pkg-badge--popular">POPULAR</span>`
      : ``;

  return `
    <div class="pkg-tile">
      <div class="pkg-tile-inner">
        <div class="pkg-coin-box">🪙</div>

        <div class="pkg-info">
          <div class="pkg-coins-row">
            <span class="pkg-coins-text">${pkg.coins} Coins</span>
            ${badgeHtml}
          </div>
          <div class="pkg-price">₹${pkg.price}</div>
        </div>

        <button
          class="pkg-buy-btn"
          onclick="buyCoins(${pkg.price}, ${pkg.coins})"
        >
          Buy
        </button>
      </div>
    </div>
  `;
}

async function refreshCoinsBalance() {
  const el = document.getElementById("storeCoinsNum");
  if (!el) return;

  if (!window.currentUser) {
    el.textContent = "0";
    return;
  }

  try {
    const doc = await db.collection("users").doc(window.currentUser.uid).get();
    const coins = doc.exists ? (doc.data().coins || 0) : 0;
    el.textContent = coins;
    localStorage.setItem("userCoins", String(coins));
  } catch (e) {
    console.warn("Coins read failed (rules?):", e);
    el.textContent = localStorage.getItem("userCoins") || "0";
  }
}

// ============================================
// ✅ NEW: ALL-APP PLANS RENDER (₹299 / ₹499)
// ============================================
async function loadAllAppPlans() {
  const mount = document.getElementById("allAppPlansMount");
  if (!mount) return;

  let hasAllApp = false;
  if (window.currentUser && typeof window.hasActiveAllAppSubscription === "function") {
    try {
      hasAllApp = await window.hasActiveAllAppSubscription();
    } catch (e) {
      console.warn(e);
    }
  }

  if (hasAllApp) {
    mount.innerHTML = `
      <div style="background:rgba(16,185,129,0.12); border:1px solid rgba(16,185,129,0.35);
                  border-radius:16px; padding:16px; display:flex; align-items:center; gap:10px; margin-bottom:10px;">
        <i class="fa-solid fa-circle-check" style="color:#10b981;"></i>
        <span style="color:#10b981; font-weight:700; font-size:0.85rem;">
          You have an active All-Access plan
        </span>
      </div>
    `;
    return;
  }

  const monthlyPrice = window.ALLAPP_MONTHLY_PRICE || 299;
  const quarterlyPrice = window.ALLAPP_QUARTERLY_PRICE || 499;

  mount.innerHTML = `
    <div class="allapp-plan-card" onclick="window.subscribeAllApp('all_app_monthly')">
      <div class="allapp-plan-row">
        <div class="allapp-plan-icon">
          <i class="fa-solid fa-crown"></i>
        </div>
        <div class="allapp-plan-text">
          <div class="allapp-plan-title">1 Month Pass</div>
          <div class="allapp-plan-sub">Unlock all creators for 30 days</div>
        </div>
        <div class="allapp-plan-price">₹${monthlyPrice}</div>
      </div>
    </div>

    <div class="allapp-plan-card" onclick="window.subscribeAllApp('all_app_quarterly')">
      <div class="allapp-plan-row">
        <div class="allapp-plan-icon">
          <i class="fa-solid fa-crown"></i>
        </div>
        <div class="allapp-plan-text">
          <div class="allapp-plan-title">
            3 Months Pass
            <span class="allapp-plan-best-badge">BEST VALUE</span>
          </div>
          <div class="allapp-plan-sub">Unlock all creators for 90 days</div>
        </div>
        <div class="allapp-plan-price">₹${quarterlyPrice}</div>
      </div>
    </div>
  `;
}

function _cleanPhone(p) {
  return String(p || "")
    .trim()
    .replace(/\s+/g, "")
    .replace(/^\+91/, "");
}
function _isValidIndianPhone(p) {
  return /^[6-9]\d{9}$/.test(p);
}

async function ensureCashfreeSdkLoaded() {
  if (typeof window.Cashfree === "function") return true;

  if (window.__loadingCashfreeSdk) {
    await window.__loadingCashfreeSdk.catch(() => {});
    return typeof window.Cashfree === "function";
  }

  window.__loadingCashfreeSdk = new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = "https://sdk.cashfree.com/js/v3/cashfree.js";
    s.async = true;
    s.onload = () => resolve(true);
    s.onerror = () => reject(new Error("Cashfree SDK failed to load"));
    document.head.appendChild(s);
  });

  try {
    await window.__loadingCashfreeSdk;
  } catch (e) {
    console.warn(e);
  }

  return typeof window.Cashfree === "function";
}

window.buyCoins = async function (price, coins) {
  if (!window.currentUser) {
    showToast("❌ Please login first");
    return;
  }
  if (!window.functions) {
    showToast("❌ Firebase Functions not loaded");
    return;
  }

  const sdkOk = await ensureCashfreeSdkLoaded();
  if (!sdkOk) {
    showToast("❌ Cashfree SDK not loaded (blocked/network). Try refresh / disable adblock.");
    return;
  }

  let phone = _cleanPhone(localStorage.getItem("cf_phone") || "");
  if (!_isValidIndianPhone(phone)) {
    phone = _cleanPhone(prompt("Enter 10-digit mobile number:", "") || "");
    if (!phone) return;

    if (!_isValidIndianPhone(phone)) {
      showToast("❌ Invalid mobile number");
      return;
    }
    localStorage.setItem("cf_phone", phone);
  }

  try {
    showToast("⏳ Creating Cashfree order...");

    const createOrder = window.functions.httpsCallable("createCashfreeCoinsOrder");
    const resp = await createOrder({
      rupees: price,
      coins: coins,
      phone: phone,
    });

    const data = resp.data || {};
    const paymentSessionId = data.paymentSessionId;
    const env = (data.env || "sandbox").toLowerCase();

    if (!paymentSessionId) {
      throw new Error("Missing paymentSessionId");
    }

    const mode = env === "production" ? "production" : "sandbox";
    const cashfree = Cashfree({ mode });

    showToast("🔐 Opening checkout...");

    await cashfree.checkout({
      paymentSessionId,
      redirectTarget: "_self",
    });

  } catch (err) {
    console.error(err);
    showToast("❌ Order failed: " + (err.message || err));
  }
};

// ============================================
// SUBSCRIPTIONS LIST (creator + all-app dono)
// ============================================

async function loadStoreSubscriptions() {
  const mount = document.getElementById("storeSubsMount");
  if (!mount) return;

  if (!window.currentUser) {
    mount.innerHTML = `
      <div class="store-empty-subs">
        <i class="fa-regular fa-face-sad-tear"></i>
        <p>Login to see subscriptions</p>
      </div>
    `;
    return;
  }

  try {
    const snapshot = await db
      .collection("subscriptions")
      .where("userId", "==", window.currentUser.uid)
      .where("status", "==", "active")
      .get();

    if (snapshot.empty) {
      mount.innerHTML = `
        <div class="store-empty-sub-card">No active subscriptions</div>
      `;
      return;
    }

    let html = "";
    snapshot.forEach((doc) => {
      const sub = doc.data();
      const endDate = sub.endDate?.toDate ? sub.endDate.toDate() : new Date(sub.endDate);
      const daysLeft = Math.max(0, Math.ceil((endDate - Date.now()) / (1000 * 60 * 60 * 24)));

      // ✅ Detect all-app vs creator plan
      const isAllApp = sub.creatorId === "ALL" ||
        sub.planType === "all_app_monthly" ||
        sub.planType === "all_app_quarterly";

      if (isAllApp) {
        const planLabel = sub.planType === "all_app_quarterly"
          ? "3 Months - All Creators"
          : "1 Month - All Creators";

        html += `
          <div class="sub-tile">
            <div class="sub-tile-info">
              <div class="sub-creator-name">🌟 ${esc(planLabel)}</div>
              <div class="sub-meta">₹${sub.amount || 299} • ${daysLeft} days left</div>
              <div class="sub-autorenewal ${sub.autoRenew ? "on" : "off"}">
                Auto-renew: ${sub.autoRenew ? "ON" : "OFF"}
              </div>
            </div>
          </div>
        `;
      } else {
        html += `
          <div class="sub-tile">
            <div class="sub-tile-info">
              <div class="sub-creator-name">${esc(sub.creatorName || "Creator")}</div>
              <div class="sub-meta">₹${sub.amount || 199}/month • ${daysLeft} days left</div>
              <div class="sub-autorenewal ${sub.autoRenew ? "on" : "off"}">
                Auto-renew: ${sub.autoRenew ? "ON" : "OFF"}
              </div>
            </div>
            <div class="sub-tile-actions">
              <button
                class="sub-btn"
                onclick="loadCreatorProfile('${sub.creatorId}'); setActiveNav('creators');"
              >
                <i class="fa-solid fa-user"></i> Creator
              </button>
            </div>
          </div>
        `;
      }
    });

    mount.innerHTML = html;
  } catch (err) {
    mount.innerHTML = `
      <div class="store-empty-sub-card">❌ ${esc(err.message)}</div>
    `;
  }
}

// ============================================
// HELPERS
// ============================================

function esc(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}
