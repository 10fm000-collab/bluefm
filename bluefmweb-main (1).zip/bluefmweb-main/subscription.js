// ============================================
// BLUEFM/DREAMFM - SUBSCRIPTION (WEB)
// SECURE via Cashfree + Cloud Functions
// ============================================

console.log("💳 Subscription System Loading (CASHFREE)...");

// ✅ UPDATED: ₹199 (poora catalog unlock, no daily quota)
const SUB_PRICE_RUPEES = 199;
const SUB_ORIGINAL_PRICE_RUPEES = 299;

// ✅ NEW: All-App plans
const ALLAPP_MONTHLY_PRICE = 299;
const ALLAPP_QUARTERLY_PRICE = 499;

const ALL_APP_CREATOR_ID = "ALL";

function toast(msg) {
  if (typeof window.showToast === "function") window.showToast(msg);
  else alert(msg);
}

function ensureAuth() {
  return new Promise((resolve) => {
    if (window.currentUser) return resolve(window.currentUser);
    let attempts = 0;
    const t = setInterval(() => {
      attempts++;
      if (window.currentUser) {
        clearInterval(t);
        resolve(window.currentUser);
      } else if (attempts >= 50) {
        clearInterval(t);
        resolve(null);
      }
    }, 100);
  });
}

// ----------------------------
// CHECK: Creator-specific subscription
// ----------------------------
async function hasActiveCreatorSubscription(creatorId) {
  const user = await ensureAuth();
  if (!user) return false;

  try {
    const snapshot = await db
      .collection("subscriptions")
      .where("userId", "==", user.uid)
      .where("creatorId", "==", creatorId)
      .where("status", "==", "active")
      .get();

    if (snapshot.empty) return false;

    const now = new Date();
    let active = false;

    snapshot.forEach((doc) => {
      const sub = doc.data();
      const endDate = sub.endDate?.toDate ? sub.endDate.toDate() : new Date(sub.endDate);
      if (endDate && now < endDate) active = true;
    });

    return active;
  } catch (e) {
    console.error("hasActiveCreatorSubscription error:", e);
    return false;
  }
}

// ----------------------------
// ✅ NEW: CHECK: All-app subscription
// ----------------------------
async function hasActiveAllAppSubscription() {
  const user = await ensureAuth();
  if (!user) return false;

  try {
    const snapshot = await db
      .collection("subscriptions")
      .where("userId", "==", user.uid)
      .where("creatorId", "==", ALL_APP_CREATOR_ID)
      .where("status", "==", "active")
      .get();

    if (snapshot.empty) return false;

    const now = new Date();
    let active = false;

    snapshot.forEach((doc) => {
      const sub = doc.data();
      const endDate = sub.endDate?.toDate ? sub.endDate.toDate() : new Date(sub.endDate);
      if (endDate && now < endDate) active = true;
    });

    return active;
  } catch (e) {
    console.error("hasActiveAllAppSubscription error:", e);
    return false;
  }
}

// ----------------------------
// ✅ UPDATED: MAIN CHECK (all-app OR creator-specific)
// ----------------------------
async function hasActiveSubscription(creatorId) {
  const hasAllApp = await hasActiveAllAppSubscription();
  if (hasAllApp) return true;

  if (!creatorId) return false;
  return hasActiveCreatorSubscription(creatorId);
}

// ----------------------------
// GET MY SUBSCRIPTIONS (READ ONLY)
// ----------------------------
async function getMySubscriptions() {
  const user = await ensureAuth();
  if (!user) return [];

  try {
    const snapshot = await db
      .collection("subscriptions")
      .where("userId", "==", user.uid)
      .where("status", "==", "active")
      .get();

    const now = new Date();
    const out = [];

    snapshot.forEach((doc) => {
      const sub = doc.data();
      const endDate = sub.endDate?.toDate ? sub.endDate.toDate() : new Date(sub.endDate);

      if (endDate && now < endDate) {
        out.push({ id: doc.id, ...sub, endDate });
      }
    });

    return out;
  } catch (e) {
    console.error("getMySubscriptions error:", e);
    return [];
  }
}

function _cleanPhone(p) {
  return String(p || "").trim().replace(/\s+/g, "").replace(/^\+91/, "");
}
function _isValidPhone(p) {
  return /^[6-9]\d{9}$/.test(p);
}

async function _getPhoneFromUser() {
  let phone = _cleanPhone(localStorage.getItem("cf_phone") || "");
  if (_isValidPhone(phone)) return phone;

  phone = _cleanPhone(prompt("Enter 10-digit mobile number (Cashfree requires it):", "") || "");
  if (!phone || !_isValidPhone(phone)) return null;

  localStorage.setItem("cf_phone", phone);
  return phone;
}

// ----------------------------
// SUBSCRIBE TO CREATOR (₹199) - Cashfree
// ----------------------------
async function subscribeToCreator(creatorId, creatorName) {
  const user = await ensureAuth();

  if (!user) {
    if (confirm("🔒 Please login to subscribe. Go to login?")) {
      window.location.href = "login.html";
    }
    return;
  }

  if (!window.functions) {
    toast("❌ Firebase Functions not loaded");
    return;
  }

  if (typeof window.Cashfree !== "function") {
    toast("❌ Cashfree SDK not loaded");
    return;
  }

  const already = await hasActiveSubscription(creatorId);
  if (already) {
    toast(`✅ You already have access to ${creatorName}`);
    return;
  }

  const phone = await _getPhoneFromUser();
  if (!phone) {
    toast("❌ Invalid mobile number");
    return;
  }

  const ok = confirm(
    `Subscribe to ${creatorName}?\n\n` +
      `💰 Price: ₹${SUB_PRICE_RUPEES}/month\n` +
      `📚 Full catalog + new episodes unlocked\n\nContinue?`
  );
  if (!ok) return;

  try {
    toast("⏳ Creating order...");

    const createOrder = window.functions.httpsCallable("createCashfreeCreatorSubscriptionOrder");
    const resp = await createOrder({ creatorId, creatorName, phone });

    const data = resp.data || {};
    const orderId = data.orderId;
    const paymentSessionId = data.paymentSessionId;
    const env = (data.env || "sandbox").toLowerCase();

    if (!orderId || !paymentSessionId) {
      throw new Error("Invalid order response");
    }

    const mode = env === "production" ? "production" : "sandbox";
    const cashfree = Cashfree({ mode });

    toast("🔐 Opening checkout...");

    await cashfree.checkout({
      paymentSessionId,
      redirectTarget: "_self",
    });
  } catch (e) {
    console.error(e);
    toast("❌ Subscribe failed: " + (e.message || e));
  }
}

// ----------------------------
// ✅ NEW: SUBSCRIBE ALL-APP (₹299 / ₹499) - Cashfree
// ----------------------------
async function subscribeAllApp(planType) {
  const user = await ensureAuth();

  if (!user) {
    if (confirm("🔒 Please login to subscribe. Go to login?")) {
      window.location.href = "login.html";
    }
    return;
  }

  if (!window.functions) {
    toast("❌ Firebase Functions not loaded");
    return;
  }

  if (typeof window.Cashfree !== "function") {
    toast("❌ Cashfree SDK not loaded");
    return;
  }

  const already = await hasActiveAllAppSubscription();
  if (already) {
    toast("✅ You already have an active All-Access plan");
    return;
  }

  const phone = await _getPhoneFromUser();
  if (!phone) {
    toast("❌ Invalid mobile number");
    return;
  }

  const price = planType === "all_app_quarterly" ? ALLAPP_QUARTERLY_PRICE : ALLAPP_MONTHLY_PRICE;
  const label = planType === "all_app_quarterly" ? "3 Months - All Creators" : "1 Month - All Creators";

  const ok = confirm(`Subscribe to ${label}?\n\n💰 Price: ₹${price}\n📚 All creators unlocked\n\nContinue?`);
  if (!ok) return;

  try {
    toast("⏳ Creating order...");

    const createOrder = window.functions.httpsCallable("createCashfreeAllAppSubscriptionOrder");
    const resp = await createOrder({ planType, phone });

    const data = resp.data || {};
    const orderId = data.orderId;
    const paymentSessionId = data.paymentSessionId;
    const env = (data.env || "sandbox").toLowerCase();

    if (!orderId || !paymentSessionId) {
      throw new Error("Invalid order response");
    }

    const mode = env === "production" ? "production" : "sandbox";
    const cashfree = Cashfree({ mode });

    toast("🔐 Opening checkout...");

    await cashfree.checkout({
      paymentSessionId,
      redirectTarget: "_self",
    });
  } catch (e) {
    console.error(e);
    toast("❌ Subscribe failed: " + (e.message || e));
  }
}

// ----------------------------
// CANCEL (Auto-renew OFF)
// ----------------------------
async function cancelSubscription(subscriptionId, creatorName) {
  const user = await ensureAuth();
  if (!user) return;

  const ok = confirm(`Cancel auto-renew for ${creatorName}?\n\nSubscription expiry tak active rahegi.`);
  if (!ok) return;

  try {
    await db.collection("subscriptions").doc(subscriptionId).update({
      autoRenew: false,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
    });
    toast("✅ Auto-renew disabled");
    setTimeout(() => window.location.reload(), 600);
  } catch (e) {
    console.error(e);
    toast("❌ Cancel failed (rules?).");
  }
}

// EXPORTS
window.hasActiveSubscription = hasActiveSubscription;
window.hasActiveCreatorSubscription = hasActiveCreatorSubscription;
window.hasActiveAllAppSubscription = hasActiveAllAppSubscription;
window.getMySubscriptions = getMySubscriptions;
window.subscribeToCreator = subscribeToCreator;
window.subscribeAllApp = subscribeAllApp;
window.cancelSubscription = cancelSubscription;
window.SUB_PRICE_RUPEES = SUB_PRICE_RUPEES;
window.SUB_ORIGINAL_PRICE_RUPEES = SUB_ORIGINAL_PRICE_RUPEES;
window.ALLAPP_MONTHLY_PRICE = ALLAPP_MONTHLY_PRICE;
window.ALLAPP_QUARTERLY_PRICE = ALLAPP_QUARTERLY_PRICE;

console.log("✅ Subscription System Ready (CASHFREE)");
