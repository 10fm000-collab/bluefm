// ============================================
// BOOK DETAIL SHEET (SECURE + DAILY SUB QUOTA UI)
// Book tap → Chapter list sheet → Play selected chapter
// ✅ Coin unlock status from Firestore: users/{uid}/chapter_unlocks/{bookId}
// ✅ Subscription status via hasActiveSubscription(creatorId)
// ✅ Subscription daily quota UI (SUB only till unlockedUntil from subscription_progress)
// ❌ No localStorage-based unlocks
// ============================================

console.log("📚 Book Detail Sheet loading (SECURE + quota UI)...");

const BD_FREE_CHAPTERS = 10;
const BD_CHAPTER_COIN_COST = 10;

// Keep current sheet state (so async updates don’t update old sheet)
const BookDetailState = {
  bookId: null,
  unlocks: new Map(), // chapterNum -> untilMs
  isSubscribed: false,
  subUnlockedUntil: BD_FREE_CHAPTERS, // ✅ subscription daily unlockedUntil (min free limit)
};

async function ensureAuthBookDetail(timeoutMs = 5000) {
  if (window.currentUser) return window.currentUser;

  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    await new Promise((r) => setTimeout(r, 100));
    if (window.currentUser) return window.currentUser;
  }
  return null;
}

// IST date key (YYYY-MM-DD) — matches backend logic
function dateKeyISTClient() {
  const istMs = Date.now() + 330 * 60 * 1000; // +5:30
  const d = new Date(istMs);
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

async function loadUnlocksForBookFromFirestore(bookId) {
  const user = await ensureAuthBookDetail();
  if (!user || !bookId) return new Map();

  try {
    const ref = db
      .collection("users")
      .doc(user.uid)
      .collection("chapter_unlocks")
      .doc(bookId);

    const snap = await ref.get();
    if (!snap.exists) return new Map();

    const data = snap.data() || {};
    const chapters = data.chapters || {};
    const now = Date.now();

    const map = new Map();

    for (const [chStr, untilVal] of Object.entries(chapters)) {
      const ch = parseInt(chStr, 10);
      if (!Number.isInteger(ch)) continue;

      let untilMs = 0;
      if (untilVal && typeof untilVal.toDate === "function") {
        untilMs = untilVal.toDate().getTime();
      } else if (typeof untilVal === "string") {
        const t = Date.parse(untilVal);
        if (!isNaN(t)) untilMs = t;
      }

      if (untilMs > now) map.set(ch, untilMs);
    }

    return map;
  } catch (e) {
    console.warn("loadUnlocksForBookFromFirestore failed:", e);
    return new Map();
  }
}

function isUnlockedFromMap(unlocksMap, chapterNum) {
  const until = unlocksMap.get(chapterNum);
  return typeof until === "number" && until > Date.now();
}

// Read subscription_progress and (if needed) trigger daily grant via getChapterStreamUrl(11)
async function getSubUnlockedUntilForBook(book) {
  const user = await ensureAuthBookDetail();
  if (!user || !book?.id) return BD_FREE_CHAPTERS;

  // Subscription quota is only meaningful for premium books with creator
  if (!book.isPremium || !book.creatorId) return BD_FREE_CHAPTERS;
  if (typeof window.hasActiveSubscription !== "function") return BD_FREE_CHAPTERS;

  let isSubscribed = false;
  try {
    isSubscribed = await window.hasActiveSubscription(book.creatorId);
  } catch (_) {}
  if (!isSubscribed) return BD_FREE_CHAPTERS;

  let unlockedUntil = BD_FREE_CHAPTERS;
  let lastGrantDate = null;

  try {
    const snap = await db
      .collection("users")
      .doc(user.uid)
      .collection("subscription_progress")
      .doc(book.id)
      .get();

    if (snap.exists) {
      const data = snap.data() || {};
      unlockedUntil = Math.max(
        BD_FREE_CHAPTERS,
        Number(data.unlockedUntil || BD_FREE_CHAPTERS)
      );
      lastGrantDate = data.lastGrantDate || null;
    }
  } catch (e) {
    console.warn("subscription_progress read failed:", e);
  }

  // If not granted today, trigger server grant (safe) by calling getChapterStreamUrl(11).
  // This updates subscription_progress server-side and returns unlockedUntil.
  const today = dateKeyISTClient();
  if (lastGrantDate !== today && window.functions) {
    try {
      const fn = window.functions.httpsCallable("getChapterStreamUrl");
      const r = await fn({ bookId: book.id, chapter: BD_FREE_CHAPTERS + 1 });
      if (typeof r.data?.unlockedUntil === "number") {
        unlockedUntil = Math.max(unlockedUntil, r.data.unlockedUntil);
      }
    } catch (_) {
      // ignore errors here (maybe locked for some reason)
    }
  }

  return unlockedUntil;
}

// ============================================
// OPEN BOOK (called from app.js / cards)
// ============================================

window.openBook = async function (bookId) {
  let book = (window.allAudiobooks || []).find((b) => b.id === bookId);

  if (!book) {
    try {
      const doc = await db.collection("audiobooks").doc(bookId).get();
      if (!doc.exists) {
        showToast("❌ Book not found");
        return;
      }
      book = { id: doc.id, ...doc.data() };
      if (!window.allAudiobooks) window.allAudiobooks = [];
      window.allAudiobooks.push(book);
    } catch (e) {
      showToast("❌ " + (e.message || e));
      return;
    }
  }

  addToHistory(book);
  openBookDetailSheet(book);
};

// ============================================
// SHEET UI
// ============================================

function openBookDetailSheet(book) {
  // Remove old sheet
  const old = document.getElementById("bookDetailSheet");
  const oldOverlay = document.getElementById("bookDetailOverlay");
  if (old) old.remove();
  if (oldOverlay) oldOverlay.remove();

  // Reset state for this book
  BookDetailState.bookId = book.id;
  BookDetailState.unlocks = new Map();
  BookDetailState.isSubscribed = false;
  BookDetailState.subUnlockedUntil = BD_FREE_CHAPTERS;

  const totalChapters = book.totalChapters || 1;
  const cover = book.coverUrl || book.safeCoverUrl || "";
  const author = book.creatorName || book.author || "Unknown";
  const plays = formatPlaysLocal(book.plays || 0);
  const cat = (book.category || "").trim();

  // Initial (fast) render
  const chaptersHtml = buildChaptersHtml(book);

  // Overlay
  const overlay = document.createElement("div");
  overlay.id = "bookDetailOverlay";
  overlay.style.cssText = `
    position: fixed; inset: 0;
    background: rgba(0,0,0,0.6);
    z-index: 3500;
    backdrop-filter: blur(2px);
  `;
  overlay.addEventListener("click", closeBookDetailSheet);

  // Sheet
  const sheet = document.createElement("div");
  sheet.id = "bookDetailSheet";
  sheet.style.cssText = `
    position: fixed;
    bottom: 0; left: 0; right: 0;
    background: var(--bg-card);
    border-radius: 24px 24px 0 0;
    z-index: 3501;
    max-height: 85vh;
    display: flex;
    flex-direction: column;
    transform: translateY(100%);
    transition: transform 0.35s cubic-bezier(0.32,0.72,0,1);
    padding-bottom: env(safe-area-inset-bottom);
    font-family: inherit;
  `;

  sheet.innerHTML = `
    <!-- Handle -->
    <div style="width:40px;height:4px;background:rgba(255,255,255,0.20);
                border-radius:2px;margin:10px auto 0;flex-shrink:0;"></div>

    <!-- Book Info Header -->
    <div style="display:flex;align-items:center;gap:14px;
                padding:16px 18px 12px;flex-shrink:0;">
      <div style="width:80px;height:80px;border-radius:14px;overflow:hidden;
                  background:var(--bg-dark);flex-shrink:0;">
        <img src="${cover}"
             style="width:100%;height:100%;object-fit:cover;"
             onerror="this.style.display='none'">
      </div>

      <div style="flex:1;min-width:0;">
        <div style="font-size:16px;font-weight:900;color:#F3F4F6;
                    white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
          ${escLocal(book.title || "Untitled")}
        </div>

        <div style="margin-top:4px;font-size:12px;font-weight:600;
                    color:var(--text-gray-light);">
          By ${escLocal(author)}
        </div>

        <div style="margin-top:6px;display:flex;gap:8px;align-items:center;">
          <span style="font-size:11px;font-weight:700;color:var(--secondary);">
            <i class="fa-solid fa-play" style="font-size:9px;"></i>
            ${plays} plays
          </span>

          ${
            cat
              ? `<span style="padding:3px 8px;border-radius:6px;
                    font-size:10px;font-weight:900;color:#fff;
                    background:${catColorLocal(cat)};">
                   ${escLocal(cat)}
                 </span>`
              : ""
          }
        </div>
      </div>
    </div>

    <!-- Play All / Chapter count row -->
    <div style="display:flex;align-items:center;justify-content:space-between;
                padding:0 18px 12px;flex-shrink:0;">
      <div style="font-size:13px;font-weight:900;color:#E5E7EB;">
        ${totalChapters} Chapter${totalChapters > 1 ? "s" : ""}
      </div>

      <button onclick="playFromSheet('${book.id}', 1)"
              style="display:flex;align-items:center;gap:8px;
                     padding:10px 20px;border-radius:999px;border:none;
                     background:linear-gradient(135deg,var(--primary),var(--secondary));
                     color:#fff;font-size:13px;font-weight:900;
                     cursor:pointer;font-family:inherit;">
        <i class="fa-solid fa-play"></i> Play All
      </button>
    </div>

    <!-- Divider -->
    <div style="height:1px;background:rgba(255,255,255,0.07);flex-shrink:0;"></div>

    <!-- Chapters List -->
    <div id="bookDetailChapterList"
         style="overflow-y:auto;flex:1;padding:8px 0;">
      ${chaptersHtml}
    </div>
  `;

  document.body.appendChild(overlay);
  document.body.appendChild(sheet);
  document.body.style.overflow = "hidden";

  // Animate in
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      sheet.style.transform = "translateY(0)";
    });
  });

  // Async: load unlocks + subscription + subscription_progress and update UI
  hydrateAccessStateAndUpdate(book).catch(() => {});
}

async function hydrateAccessStateAndUpdate(book) {
  const openingBookId = BookDetailState.bookId;
  if (!openingBookId || openingBookId !== book.id) return;

  const tasks = [];

  // Unlocks
  tasks.push(
    (async () => {
      const unlocks = await loadUnlocksForBookFromFirestore(book.id);
      return { unlocks };
    })()
  );

  // Subscription + unlockedUntil
  tasks.push(
    (async () => {
      let isSubscribed = false;

      if (
        window.currentUser &&
        typeof window.hasActiveSubscription === "function" &&
        book.creatorId
      ) {
        try {
          isSubscribed = await window.hasActiveSubscription(book.creatorId);
        } catch (_) {}
      }

      let subUnlockedUntil = BD_FREE_CHAPTERS;
      if (isSubscribed) {
        subUnlockedUntil = await getSubUnlockedUntilForBook(book);
      }

      return { isSubscribed, subUnlockedUntil };
    })()
  );

  const results = await Promise.all(tasks);

  if (BookDetailState.bookId !== book.id) return;

  for (const r of results) {
    if (r.unlocks) BookDetailState.unlocks = r.unlocks;
    if (typeof r.isSubscribed === "boolean") BookDetailState.isSubscribed = r.isSubscribed;
    if (typeof r.subUnlockedUntil === "number") {
      BookDetailState.subUnlockedUntil = Math.max(BD_FREE_CHAPTERS, r.subUnlockedUntil);
    }
  }

  updateChapterListUI(book);
}

function buildChaptersHtml(book) {
  const total = book.totalChapters || 1;
  let html = "";

  for (let i = 1; i <= total; i++) {
    const isFree = i <= BD_FREE_CHAPTERS;

    const coinUnlocked = isUnlockedFromMap(BookDetailState.unlocks, i);

    // ✅ subscription now only unlocks till subUnlockedUntil (daily quota)
    const viaSub =
      BookDetailState.isSubscribed &&
      book.isPremium &&
      !isFree &&
      i <= (BookDetailState.subUnlockedUntil || BD_FREE_CHAPTERS);

    let icon, tagText, tagColor;

    if (isFree) {
      icon = `<i class="fa-solid fa-unlock" style="color:#10B981;font-size:16px;"></i>`;
      tagText = "FREE";
      tagColor = "#10B981";
    } else if (viaSub) {
      icon = `<i class="fa-solid fa-crown" style="color:var(--secondary);font-size:16px;"></i>`;
      tagText = "SUB";
      tagColor = "var(--secondary)";
    } else if (coinUnlocked) {
      icon = `<i class="fa-solid fa-unlock" style="color:var(--secondary);font-size:16px;"></i>`;
      tagText = "Unlocked";
      tagColor = "var(--secondary)";
    } else {
      icon = `<i class="fa-solid fa-lock" style="color:#F59E0B;font-size:16px;"></i>`;
      tagText = `🪙 ${BD_CHAPTER_COIN_COST}`;
      tagColor = "#F59E0B";
    }

    html += `
      <div onclick="playFromSheet('${book.id}', ${i})"
           style="display:flex;align-items:center;gap:14px;
                  padding:14px 18px;cursor:pointer;
                  transition:background 0.15s;"
           onmouseover="this.style.background='rgba(255,255,255,0.05)'"
           onmouseout="this.style.background='transparent'">

        <div style="width:22px;text-align:center;flex-shrink:0;">
          ${icon}
        </div>

        <div style="flex:1;font-size:15px;font-weight:700;color:#fff;">
          Chapter ${i}
        </div>

        <div style="font-size:12px;font-weight:800;color:${tagColor};">
          ${tagText}
        </div>

        <div style="width:36px;height:36px;border-radius:999px;
                    background:rgba(124,58,237,0.18);
                    display:flex;align-items:center;justify-content:center;
                    flex-shrink:0;">
          <i class="fa-solid fa-play"
             style="color:var(--primary);font-size:13px;"></i>
        </div>
      </div>
    `;
  }

  return html;
}

function updateChapterListUI(book) {
  const container = document.getElementById("bookDetailChapterList");
  if (!container) return;
  container.innerHTML = buildChaptersHtml(book);
}

// ============================================
// PLAY FROM SHEET
// ============================================

window.playFromSheet = function (bookId, chapterNum) {
  closeBookDetailSheet();

  const book = (window.allAudiobooks || []).find((b) => b.id === bookId);
  if (!book) {
    showToast("❌ Book not found");
    return;
  }

  // Player handles lock/unlock securely (subscription quota + coin unlock fallback)
  if (typeof window.playAudiobookAtChapter === "function") {
    window.playAudiobookAtChapter(bookId, book, chapterNum);
  } else if (typeof window.playAudiobook === "function") {
    window.playAudiobook(bookId, book);
  }
};

// ============================================
// CLOSE SHEET
// ============================================

function closeBookDetailSheet() {
  const sheet = document.getElementById("bookDetailSheet");
  const overlay = document.getElementById("bookDetailOverlay");

  // reset state
  BookDetailState.bookId = null;
  BookDetailState.unlocks = new Map();
  BookDetailState.isSubscribed = false;
  BookDetailState.subUnlockedUntil = BD_FREE_CHAPTERS;

  if (sheet) {
    sheet.style.transform = "translateY(100%)";
    setTimeout(() => sheet.remove(), 350);
  }
  if (overlay) {
    overlay.style.opacity = "0";
    setTimeout(() => overlay.remove(), 350);
  }
  document.body.style.overflow = "";
}
window.closeBookDetailSheet = closeBookDetailSheet;

// ============================================
// Helpers
// ============================================

function formatPlaysLocal(num) {
  const n = Number(num || 0);
  if (n >= 1000000) return (n / 1000000).toFixed(1) + "M";
  if (n >= 1000) return (n / 1000).toFixed(1) + "K";
  return String(n);
}

function catColorLocal(cat) {
  switch ((cat || "").toLowerCase()) {
    case "romance":
      return "#E91E63";
    case "horror":
      return "#FF5722";
    case "fantasy":
    case "epic fantasy":
      return "#9C27B0";
    case "sci-fi":
      return "#2196F3";
    case "thriller":
      return "#FF9800";
    default:
      return "#DB2777";
  }
}

function escLocal(s) {
  return String(s ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function addToHistory(book) {
  let h = JSON.parse(localStorage.getItem("historyBooks") || "[]");
  h = h.filter((b) => (b.id || b) !== book.id);
  h.unshift({
    id: book.id,
    title: book.title,
    author: book.author,
    coverUrl: book.coverUrl,
  });
  localStorage.setItem("historyBooks", JSON.stringify(h.slice(0, 10)));
}

function showToast(msg) {
  if (typeof window.showToast === "function") {
    window.showToast(msg);
    return;
  }

  const old = document.querySelector(".toast-notification");
  if (old) old.remove();
  const t = document.createElement("div");
  t.className = "toast-notification";
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.classList.add("show"), 80);
  setTimeout(() => {
    t.classList.remove("show");
    setTimeout(() => t.remove(), 300);
  }, 3000);
}

console.log("✅ Book Detail Sheet ready (SECURE + quota UI)");