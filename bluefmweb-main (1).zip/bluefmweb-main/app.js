// ============================================
// BLUEFM - MAIN APP (v4 - Final + BACK FIX)
// Home | Creators | My Library | My Store
// Profile = Topbar avatar se
// ============================================

console.log("🚀 App Starting (v4)...");

const ADMIN_EMAILS = ['vikassingh44999@gmail.com'];

window.__heroTimer = null;
window.heroGo = null;
window.__currentCreatorProfile = null;
window.__creatorAudiobooks = [];
window.__myRating = null;
window.__userCoins = 0;

// Router ready flag
window.__routerReady = false;

// ============================================
// INIT
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  console.log("✅ DOM Loaded");
  setupNavListeners();
  initializeUserData();
  attachAuthListener();

  // ✅ Hash Router (browser back will work inside app)
  window.addEventListener('hashchange', routeFromHash);
  window.__routerReady = true;

  // First route
  routeFromHash();
});

// ============================================
// ROUTER (HASH BASED)
// ============================================

function routeFromHash() {
  const hash = window.location.hash || '#home';

  // autoplay case
  if (hash.startsWith('#play-')) {
    setActiveNav('home');
    loadHomePage();
    checkAutoPlayFromHash(); // plays then cleans hash
    return;
  }

  // creator profile route
  if (hash.startsWith('#creator-')) {
    const creatorId = hash.replace('#creator-', '');
    setActiveNav('creators');
    loadCreatorProfile(creatorId);
    return;
  }

  // profile route
  if (hash === '#profile') {
    // optional: keep current tab highlight OR none. Here we keep home off.
    // setActiveNav('home');
    if (typeof window.loadProfilePage === 'function') window.loadProfilePage();
    return;
  }

  const page = hash.replace('#', '');

  switch (page) {
    case 'home':
      setActiveNav('home');
      loadHomePage();
      break;
    case 'creators':
      setActiveNav('creators');
      loadCreatorsPage();
      break;
    case 'library':
      setActiveNav('library');
      loadLibraryPage();
      break;
    case 'store':
      setActiveNav('store');
      window.loadStorePage();
      break;
    default:
      setActiveNav('home');
      loadHomePage();
  }
}

// In-app back helper (profile/creator back buttons me use kar sakte ho)
window.goBackInApp = function (fallbackHash = '#home') {
  if (history.length > 1) history.back();
  else window.location.hash = fallbackHash;
};

// ============================================
// AUTH LISTENER
// ============================================

function attachAuthListener() {
  try {
    if (window.auth && typeof window.auth.onAuthStateChanged === 'function') {
      window.auth.onAuthStateChanged(async (user) => {
        window.currentUser = user || null;
        updateTopBarInitial();

        // If user lands directly on #profile, re-render after auth is available
        if (window.location.hash === '#profile' && typeof window.loadProfilePage === 'function') {
          window.loadProfilePage();
        }

        // Firestore se coins load
        if (user) {
          try {
            const doc = await db.collection('users').doc(user.uid).get();
            if (doc.exists) {
              const coins = doc.data().coins || 0;
              window.__userCoins = coins;
              localStorage.setItem('userCoins', coins.toString());
            }
          } catch (e) {
            console.warn('Coins load:', e);
          }
        }
      });
    }
  } catch (e) {
    console.warn("Auth listener:", e);
  }
}

function initializeUserData() {
  if (!localStorage.getItem('likedBooks'))
    localStorage.setItem('likedBooks', JSON.stringify([]));
  if (!localStorage.getItem('historyBooks'))
    localStorage.setItem('historyBooks', JSON.stringify([]));
  if (!localStorage.getItem('userCoins'))
    localStorage.setItem('userCoins', '0');
}

// ============================================
// AUTO PLAY FROM HASH
// ============================================

function checkAutoPlayFromHash() {
  const hash = window.location.hash;
  if (!hash || !hash.startsWith('#play-')) return;

  const bookId = hash.replace('#play-', '');
  const bookDataStr = sessionStorage.getItem('autoPlayBook');

  if (bookDataStr) {
    try {
      const book = JSON.parse(bookDataStr);
      sessionStorage.removeItem('autoPlayBook');
      if (!book.title) { fetchAndPlayBook(bookId); return; }
      waitForUserThenPlay(book.id, book);

      // ✅ clean hash to #home (without triggering hashchange)
      history.replaceState(null, '', window.location.href.replace(/#.*$/, '') + '#home');
    } catch (e) {
      sessionStorage.removeItem('autoPlayBook');
    }
  } else {
    fetchAndPlayBook(bookId);
  }
}

async function fetchAndPlayBook(bookId) {
  try {
    const doc = await db.collection('audiobooks').doc(bookId).get();
    if (!doc.exists) { showToast('❌ Audiobook not found'); return; }
    const book = { id: doc.id, ...doc.data() };
    waitForUserThenPlay(book.id, book);

    // ✅ clean hash to #home
    history.replaceState(null, '', window.location.href.replace(/#.*$/, '') + '#home');
  } catch (e) {
    showToast('❌ Failed to load audiobook');
  }
}

function waitForUserThenPlay(bookId, book) {
  const wait = setInterval(() => {
    if (window.currentUser) {
      clearInterval(wait);
      if (!window.allAudiobooks) window.allAudiobooks = [];
      if (!window.allAudiobooks.find(b => b.id === book.id)) {
        window.allAudiobooks.push(book);
      }
      safePlay(bookId, book);
    }
  }, 300);
  setTimeout(() => clearInterval(wait), 5000);
}

// ============================================
// NAV SETUP
// ============================================

function setupNavListeners() {
  const navItems = document.querySelectorAll('.nav-item');
  navItems.forEach(item => {
    item.addEventListener('click', function (e) {
      e.preventDefault();
      navigateTo(this.getAttribute('data-page')); // ✅ only set hash
    });
  });
}

// ============================================
// NAVIGATION (hash only)
// ============================================

function navigateTo(page) {
  window.location.hash = `#${page}`;
}

// Active nav tab set
function setActiveNav(page) {
  document.querySelectorAll('.nav-item').forEach(n => {
    n.classList.toggle('active', n.getAttribute('data-page') === page);
  });
}

// ============================================
// HOME PAGE
// ============================================

function loadHomePage() {
  const mainContent = document.getElementById('mainContent');
  if (!mainContent) return;

  if (window.__heroTimer) {
    clearInterval(window.__heroTimer);
    window.__heroTimer = null;
  }

  mainContent.innerHTML = `
  <div class="home-page">

    <div class="home-topbar">
      <div class="topbar-row">
        <div class="brand">
          <i class="fa-solid fa-headphones brand-icon"></i>
          <span>BlueFM</span>
        </div>
        <div class="topbar-spacer"></div>
        <button class="icon-btn" onclick="openSearch()" aria-label="Search">
          <i class="fa-solid fa-magnifying-glass"></i>
        </button>
        <div class="profile-chip" id="topbarProfileChip"
             onclick="goProfile()" title="Profile">
          ${getUserInitial()}
        </div>
      </div>
    </div>

    <div class="hero-wrap" id="heroMount">
      <div class="hero">
        <div class="hero-overlay"></div>
        <div class="hero-content">
          <div class="hero-title">Loading...</div>
          <div class="hero-subtitle">Please wait</div>
        </div>
      </div>
    </div>

    <div id="sectionsMount">
      <div class="loading-container" style="padding:26px 16px;">
        <div class="loading-spinner"></div>
      </div>
    </div>

  </div>`;

  loadAudiobooks();
  updateTopBarInitial();
}

function updateTopBarInitial() {
  const el = document.getElementById('topbarProfileChip');
  if (el) el.textContent = getUserInitial();
}

// ============================================
// LOAD AUDIOBOOKS
// ============================================

async function loadAudiobooks() {
  try {
    const snapshot = await db.collection('audiobooks')
      .orderBy('createdAt', 'desc')
      .get();

    if (snapshot.empty) {
      const sm = document.getElementById('sectionsMount');
      if (sm) sm.innerHTML = `
        <div class="no-books" style="padding:40px 16px;">
          <div style="font-size:34px;margin-bottom:10px;">📚</div>
          No audiobooks yet
        </div>`;
      const hm = document.getElementById('heroMount');
      if (hm) hm.innerHTML = '';
      return;
    }

    window.allAudiobooks = [];
    snapshot.forEach(doc => window.allAudiobooks.push({ id: doc.id, ...doc.data() }));

    console.log(`✅ Loaded ${window.allAudiobooks.length} audiobooks`);
    renderHomeFromBooks(window.allAudiobooks);

  } catch (err) {
    console.error("❌ Load error:", err);
    const sm = document.getElementById('sectionsMount');
    if (sm) sm.innerHTML = `
      <div class="no-books" style="padding:40px 16px;">
        ❌ ${esc(err.message)}
      </div>`;
  }
}

// ============================================
// HOME RENDER
// ============================================

function renderHomeFromBooks(all) {
  const recent = [...all].sort((a, b) => getCreatedAtMs(b) - getCreatedAtMs(a));
  const popular = [...all].sort((a, b) => (b.plays || 0) - (a.plays || 0));

  renderHero(popular.slice(0, 3));

  let html = '';
  html += renderBookRow('📚 Recently Added', recent.slice(0, 12));
  html += renderBookRow('⭐ Most Popular', popular.slice(0, 12));
  html += renderTopCharts(popular.slice(0, 5));

  // Categories
  const cats = {};
  all.forEach(b => {
    const cat = (b.category || '').trim() || 'General';
    if (!cats[cat]) cats[cat] = [];
    cats[cat].push(b);
  });

  const preferredOrder = [
    'Romance', 'Fantasy', 'Sci-Fi',
    'Horror', 'Thriller', 'Magical Realism', 'Epic Fantasy',
  ];

  const ordered = [];
  preferredOrder.forEach(c => { if (cats[c]) ordered.push(c); });
  Object.keys(cats).forEach(c => {
    if (!ordered.includes(c) && c !== 'General') ordered.push(c);
  });
  if (cats['General']) ordered.push('General');

  ordered.forEach(cat => {
    const list = [...cats[cat]].sort((a, b) => (b.plays || 0) - (a.plays || 0));
    html += renderBookRow(cat, list.slice(0, 12));
  });

  const sm = document.getElementById('sectionsMount');
  if (sm) sm.innerHTML = html;
}

// ============================================
// HERO BANNER
// ============================================

function renderHero(items) {
  const heroMount = document.getElementById('heroMount');
  if (!heroMount) return;

  if (!items || items.length === 0) {
    heroMount.innerHTML = '';
    return;
  }

  let index = 0;

  const paint = () => {
    const book = items[index];
    const cover = getCover(book);
    const genre = ((book.category || 'General').trim() || 'General');

    heroMount.innerHTML = `
    <div class="hero">
      <div class="hero-bg" style="background-image:url('${cover}')"></div>
      <div class="hero-overlay"></div>
      <div class="hero-content">
        <div class="pills">
          <div class="pill trending">🔴 TRENDING</div>
          <div class="pill genre"
               style="background:${genreColorPill(genre)}">${esc(genre)}</div>
        </div>
        <div class="hero-title">${esc(book.title || 'Untitled')}</div>
        <div class="hero-subtitle">
          By ${esc(book.creatorName || book.author || 'Unknown')}
          • ${formatPlays(book.plays || 0)} plays
        </div>
        <button class="hero-play" onclick="openBook('${book.id}')">
          <i class="fa-solid fa-play"></i> Play Now
        </button>
      </div>
      <div class="hero-dots">
        ${items.map((_, i) => `
          <div class="hero-dot ${i === index ? 'active' : ''}"
               onclick="heroGo(${i})"></div>
        `).join('')}
      </div>
    </div>`;
  };

  window.heroGo = (i) => { index = i; paint(); restart(); };

  const restart = () => {
    if (window.__heroTimer) clearInterval(window.__heroTimer);
    if (items.length <= 1) return;
    window.__heroTimer = setInterval(() => {
      index = (index + 1) % items.length;
      paint();
    }, 4000);
  };

  paint();
  restart();
}

// ============================================
// BOOK ROW
// ============================================

function renderBookRow(title, books) {
  if (!books || books.length === 0) return '';

  return `
  <section class="section">
    <div class="section-head">
      <div class="section-title">${esc(title)}</div>
      <div class="section-action">
        <span>See All</span>
        <i class="fa-solid fa-chevron-right"></i>
      </div>
    </div>
    <div class="row-scroll">
      ${books.map(b => renderBookCard(b)).join('')}
    </div>
  </section>`;
}

function renderBookCard(book) {
  const cover = getCover(book);
  const plays = formatPlays(book.plays || 0);
  const cat = (book.category || '').trim();
  const showTag = cat && cat.toLowerCase() !== 'general';
  const tag = showTag
    ? `<div class="cat-tag" style="background:${categoryColor(cat)}">${esc(cat)}</div>`
    : '';
  const creator = (book.creatorName || '').trim();
  const sub = `${plays} plays${creator ? ' · ' + creator : ''}`;

  return `
  <div class="book-card" onclick="openBook('${book.id}')">
    <div class="book-cover">
      <img src="${cover}" alt="${esc(book.title || '')}"
           onerror="this.src='https://placehold.co/400x400/12131A/FFFFFF?text=BlueFM'">
      <div class="plays-badge">${plays}+</div>
      ${tag}
    </div>
    <div class="book-title">${esc(book.title || 'Untitled')}</div>
    <div class="book-sub">${esc(sub)}</div>
  </div>`;
}

// ============================================
// TOP CHARTS
// ============================================

function renderTopCharts(books) {
  if (!books || books.length === 0) return '';

  return `
  <section class="section">
    <div class="section-head">
      <div style="display:flex;align-items:center;gap:8px;">
        <div class="section-title">🏆 Top Charts</div>
        <div style="font-size:11px;color:var(--text-gray-light);font-weight:600;">
          Leaderboard
        </div>
      </div>
      <div class="section-action">
        <span>See All</span>
        <i class="fa-solid fa-chevron-right"></i>
      </div>
    </div>
    <div class="topcharts-wrap">
      <div class="topcharts-list">
        ${books.map((b, i) => topChartItem(b, i + 1)).join('<div class="topcharts-sep"></div>')}
      </div>
    </div>
  </section>`;
}

function topChartItem(book, rank) {
  const isTop3 = rank <= 3;
  const rankColor = rank === 1 ? '#FFD700'
    : rank === 2 ? '#C0C0C0'
      : rank === 3 ? '#CD7F32'
        : '#6B7280';
  const cover = getCover(book);
  const trophy = isTop3
    ? `<div class="rankicon" style="color:${rankColor}">
         <i class="fa-solid fa-trophy"></i>
       </div>`
    : '';
  const itemStyle = isTop3
    ? `border:1.5px solid ${hexToRgba(rankColor, 0.30)};
       background:linear-gradient(90deg,
         ${hexToRgba(rankColor, 0.15)},
         ${hexToRgba(rankColor, 0.05)});`
    : '';

  return `
  <div class="topcharts-item" onclick="openBook('${book.id}')"
       style="${itemStyle}">
    <div class="rankbox">
      ${trophy}
      <div class="ranknum ${isTop3 ? 'top' : ''}"
           style="${isTop3 ? `color:${rankColor}` : ''}">#${rank}</div>
    </div>
    <div class="tc-cover">
      <img src="${cover}"
           onerror="this.src='https://placehold.co/200x200/12131A/FFFFFF?text=BlueFM'">
    </div>
    <div class="tc-info">
      <div class="tc-title">${esc(book.title || 'Untitled')}</div>
      <div class="tc-author">
        ${esc(book.creatorName || book.author || 'Unknown')}
      </div>
      <div class="tc-plays">
        <i class="fa-regular fa-circle-play"></i>
        ${formatPlays(book.plays || 0)} plays
      </div>
    </div>
    <div class="tc-play"><i class="fa-solid fa-play"></i></div>
  </div>`;
}

// ============================================
// LIBRARY PAGE
// ============================================

function loadLibraryPage() {
  const mainContent = document.getElementById('mainContent');
  const historyBooks = getHistoryBooksWithData();
  const likedBooks = getLikedBooksWithData();
  const hasAny = historyBooks.length > 0 || likedBooks.length > 0;

  mainContent.innerHTML = `
  <div class="library-page">
    <div class="library-topbar">
      <div class="library-header-row">
        <div class="lib-icon-box">
          <i class="fa-solid fa-bookmark"></i>
        </div>
        <div class="lib-title">My Library</div>
      </div>
    </div>

    ${!hasAny ? `
      <div class="library-empty">
        <i class="fa-regular fa-bookmark"></i>
        <h3>Nothing here yet</h3>
        <p>Start listening and open books.<br>
           Your history and liked books will appear here.</p>
      </div>
    ` : ''}

    ${historyBooks.length > 0 ? `
      <section class="section">
        <div class="section-head">
          <div class="section-title">⏱️ Recently Played</div>
        </div>
        <div class="row-scroll">
          ${historyBooks.map(b => renderLibBookCard(b)).join('')}
        </div>
      </section>
    ` : ''}

    ${likedBooks.length > 0 ? `
      <section class="section">
        <div class="section-head">
          <div class="section-title">❤️ Saved</div>
        </div>
        <div class="row-scroll">
          ${likedBooks.map(b => renderLibBookCard(b)).join('')}
        </div>
      </section>
    ` : ''}
  </div>`;
}

function renderLibBookCard(b) {
  const id = b.id || '';
  const title = b.title || 'Untitled';
  const author = b.creatorName || b.author || '';
  const cover = b.coverUrl || '';

  return `
  <div class="lib-book-card" onclick="openBook('${id}')">
    <div class="lib-book-cover">
      <img src="${cover || 'https://placehold.co/264x312/12131A/FFFFFF?text=BlueFM'}"
           onerror="this.src='https://placehold.co/264x312/12131A/FFFFFF?text=BlueFM'">
    </div>
    <div class="lib-book-title">${esc(title)}</div>
    <div class="lib-book-sub">${esc(author)}</div>
  </div>`;
}

function getHistoryBooksWithData() {
  const history = JSON.parse(localStorage.getItem('historyBooks') || '[]');
  return history.map(item => {
    if (typeof item === 'string') {
      const full = (window.allAudiobooks || []).find(b => b.id === item);
      return full || { id: item, title: 'Untitled', author: '' };
    }
    return item;
  }).filter(Boolean);
}

function getLikedBooksWithData() {
  const liked = JSON.parse(localStorage.getItem('likedBooks') || '[]');
  return liked.map(item => {
    if (typeof item === 'string') {
      const full = (window.allAudiobooks || []).find(b => b.id === item);
      return full || { id: item, title: 'Untitled', author: '' };
    }
    return item;
  }).filter(Boolean);
}

// ============================================
// CREATORS PAGE (SPA)
// ============================================

let allCreators = [];

async function loadCreatorsPage() {
  const mainContent = document.getElementById('mainContent');

  mainContent.innerHTML = `
  <div class="creators-page">
    <div class="creators-topbar">
      <div class="creators-header-row">
        <div class="creators-icon-box">
          <i class="fa-solid fa-users"></i>
        </div>
        <div class="creators-page-title">Creators</div>
      </div>
      <div class="creator-search-wrap">
        <i class="fa-solid fa-magnifying-glass creator-search-icon"></i>
        <input class="creator-search-input" type="text"
               id="creatorSearchInput"
               placeholder="Search creators...">
      </div>
    </div>
    <div id="creatorsListMount">
      <div class="loading-container" style="padding:40px 16px;">
        <div class="loading-spinner"></div>
      </div>
    </div>
  </div>`;

  setTimeout(() => {
    const inp = document.getElementById('creatorSearchInput');
    if (inp) {
      inp.addEventListener('input', (e) => {
        const term = e.target.value.toLowerCase().trim();
        const filtered = term
          ? allCreators.filter(c =>
            (c.channelName || '').toLowerCase().includes(term) ||
            (c.description || '').toLowerCase().includes(term))
          : allCreators;
        renderCreatorsList(filtered);
      });
    }
  }, 100);

  await fetchAndRenderCreators();
}

async function fetchAndRenderCreators() {
  try {
    const snapshot = await db.collection('creators')
      .where('isApproved', '==', true)
      .where('isActive', '==', true)
      .get();

    allCreators = [];
    snapshot.forEach(doc => allCreators.push({ uid: doc.id, ...doc.data() }));
    allCreators.sort((a, b) => (b.totalSubscribers || 0) - (a.totalSubscribers || 0));

    renderCreatorsList(allCreators);

  } catch (err) {
    const m = document.getElementById('creatorsListMount');
    if (m) m.innerHTML = `
      <div class="no-books" style="padding:40px 16px;">
        ❌ ${esc(err.message)}
      </div>`;
  }
}

function renderCreatorsList(creators) {
  const mount = document.getElementById('creatorsListMount');
  if (!mount) return;

  if (creators.length === 0) {
    mount.innerHTML = `
    <div class="library-empty">
      <i class="fa-solid fa-users"></i>
      <h3>No creators found</h3>
      <p>Try a different search</p>
    </div>`;
    return;
  }

  mount.innerHTML = `
  <div style="padding:4px 0 8px;">
    ${creators.map(c => renderCreatorCard(c)).join('')}
  </div>`;
}

function renderCreatorCard(c) {
  const avatar = c.profileImage ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(c.channelName || 'C')}&background=7C3AED&color=fff&size=112`;
  const books = c.totalAudiobooks || 0;
  const subs = formatCount(c.totalSubscribers || 0);

  // ✅ IMPORTANT: use hash route so browser back works
  return `
  <div class="creator-list-card" onclick="window.location.hash='#creator-${c.uid}'">
    <img class="creator-list-avatar"
         src="${avatar}"
         onerror="this.src='https://ui-avatars.com/api/?name=${encodeURIComponent(c.channelName || 'C')}&background=7C3AED&color=fff&size=112'"
         alt="${esc(c.channelName || 'Creator')}">
    <div class="creator-list-info">
      <div class="creator-list-name">${esc(c.channelName || 'Creator')}</div>
      <div class="creator-list-sub">${books} books · ${subs} subscribers</div>
    </div>
    <i class="fa-solid fa-chevron-right creator-list-arrow"></i>
  </div>`;
}

// ============================================
// CREATOR PROFILE (SPA)
// ============================================

async function loadCreatorProfile(creatorId) {
  const mainContent = document.getElementById('mainContent');

  mainContent.innerHTML = `
  <div class="creator-profile-page">
    <div class="cp-topbar">
      <button class="cp-back-btn"
              onclick="window.location.hash='#creators'">
        <i class="fa-solid fa-arrow-left"></i>
      </button>
      <div class="cp-topbar-title">Creator Profile</div>
    </div>
    <div class="loading-container" style="padding:60px 16px;">
      <div class="loading-spinner"></div>
    </div>
  </div>`;

  try {
    const creatorDoc = await db.collection('creators').doc(creatorId).get();
    if (!creatorDoc.exists) {
      showToast('❌ Creator not found');
      window.location.hash = '#creators';
      return;
    }

    const creator = { uid: creatorDoc.id, ...creatorDoc.data() };
    window.__currentCreatorProfile = creator;
    window.__myRating = null;

    // Subscription check
    let isSubscribed = false;
    if (window.currentUser && typeof window.hasActiveSubscription === 'function') {
      try {
        isSubscribed = await window.hasActiveSubscription(creatorId);
      } catch (_) {}
    }

    // My rating
    if (window.currentUser) {
      try {
        const rDoc = await db.collection('creators').doc(creatorId)
          .collection('ratings').doc(window.currentUser.uid).get();
        if (rDoc.exists) window.__myRating = rDoc.data().rating;
      } catch (_) {}
    }

    renderCreatorProfile(creator, isSubscribed);
    loadCreatorBooks(creatorId);

  } catch (err) {
    showToast('❌ ' + err.message);
    window.location.hash = '#creators';
  }
}

function renderCreatorProfile(c, isSubscribed) {
  const mainContent = document.getElementById('mainContent');
  const avatar = c.profileImage ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(c.channelName || 'C')}&background=7C3AED&color=fff&size=300`;

  const myRating = window.__myRating;
  const starsHTML = [1, 2, 3, 4, 5].map(s => `
    <button class="cp-star ${(myRating || 0) >= s ? 'filled' : ''}"
            onclick="submitCreatorRating(${s}, '${c.uid}')">★</button>
  `).join('');

  const subscribeBtn = isSubscribed
    ? `<div class="cp-subscribed-box">
         <i class="fa-solid fa-circle-check"></i> Subscribed
       </div>
       <div class="cp-subscribed-note">
         You have an active subscription.
         Premium chapters will unlock automatically.
       </div>`
: `<button class="cp-subscribe-btn"
           onclick="handleCreatorSubscribe('${c.uid}',
           '${esc(c.channelName)}')">
     Subscribe for ₹199/month
   </button>`;

  mainContent.innerHTML = `
  <div class="creator-profile-page">

    <div class="cp-topbar">
      <button class="cp-back-btn"
              onclick="window.location.hash='#creators'">
        <i class="fa-solid fa-arrow-left"></i>
      </button>
      <div class="cp-topbar-title">Creator Profile</div>
    </div>

    <div style="overflow-y:auto; padding-bottom:140px;">

      <div class="cp-avatar-wrap">
        <img class="cp-avatar" src="${avatar}"
             onerror="this.src='https://ui-avatars.com/api/?name=C&background=7C3AED&color=fff&size=300'"
             alt="${esc(c.channelName || 'Creator')}">
      </div>

      <div class="cp-name">${esc(c.channelName || 'Creator')}</div>
      <div class="cp-role">Audio Fiction Creator</div>

      ${(c.description || '').trim()
        ? `<div class="cp-desc">${esc(c.description)}</div>`
        : ''}

      <div class="cp-stats">
        <div class="cp-stat-card">
          <div class="cp-stat-value">${c.totalAudiobooks || 0}</div>
          <div class="cp-stat-label">Series</div>
        </div>
        <div class="cp-stat-card">
          <div class="cp-stat-value">${formatCount(c.totalSubscribers || 0)}</div>
          <div class="cp-stat-label">Subscribers</div>
        </div>
      </div>

      <div class="cp-stats" style="padding-top:10px;">
        <div class="cp-stat-card" style="flex:1;">
          <div class="cp-stat-value">${(c.rating || 0).toFixed(1)}</div>
          <div class="cp-stat-label">Rating</div>
        </div>
      </div>

      ${window.currentUser ? `
        <div class="cp-rate-wrap">
          <div class="cp-rate-label">Rate this creator</div>
          <div class="cp-stars">${starsHTML}</div>
          ${myRating ? `<div class="cp-my-rating-text">You rated: ${myRating} ★</div>` : ''}
        </div>
      ` : ''}

      <div class="cp-subscribe-wrap">${subscribeBtn}</div>

      <div class="cp-books-title">Audiobooks</div>

      <div class="cp-books-grid" id="creatorBooksGrid">
        <div class="loading-container"
             style="grid-column:span 2; padding:30px 0;">
          <div class="loading-spinner"></div>
        </div>
      </div>

    </div>
  </div>`;
}

async function loadCreatorBooks(creatorId) {
  const grid = document.getElementById('creatorBooksGrid');
  if (!grid) return;

  try {
    const snapshot = await db.collection('audiobooks')
      .where('creatorId', '==', creatorId)
      .get();

    window.__creatorAudiobooks = [];
    snapshot.forEach(doc => {
      window.__creatorAudiobooks.push({ id: doc.id, ...doc.data() });
    });

    if (window.__creatorAudiobooks.length === 0) {
      grid.innerHTML = `
      <div style="grid-column:span 2; padding:20px 0;
                  color:var(--text-gray-light); font-weight:600;">
        No audiobooks yet
      </div>`;
      return;
    }

    // allAudiobooks me add
    if (!window.allAudiobooks) window.allAudiobooks = [];
    window.__creatorAudiobooks.forEach(b => {
      if (!window.allAudiobooks.find(x => x.id === b.id))
        window.allAudiobooks.push(b);
    });

    grid.innerHTML = window.__creatorAudiobooks.map(b => renderBookCard(b)).join('');

  } catch (err) {
    if (grid) grid.innerHTML = `
      <div style="grid-column:span 2; color:var(--text-gray-light);">
        ❌ ${esc(err.message)}
      </div>`;
  }
}

window.handleCreatorSubscribe = function (creatorId, creatorName) {
  if (!window.currentUser) { showToast('❌ Please login first'); return; }
  if (typeof window.subscribeToCreator === 'function') {
    window.subscribeToCreator(creatorId, creatorName);
  } else {
    showToast('Subscription coming soon');
  }
};

window.submitCreatorRating = async function (rating, creatorId) {
  if (!window.currentUser) { showToast('❌ Login required'); return; }

  window.__myRating = rating;

  document.querySelectorAll('.cp-star').forEach((btn, i) => {
    btn.classList.toggle('filled', i < rating);
  });

  const ratingText = document.querySelector('.cp-my-rating-text');
  if (ratingText) ratingText.textContent = `You rated: ${rating} ★`;

  try {
    await db.collection('creators').doc(creatorId)
      .collection('ratings').doc(window.currentUser.uid)
      .set({
        rating,
        updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
      });
    showToast('⭐ Rating submitted!');
  } catch (e) {
    showToast('❌ Rating failed: ' + e.message);
  }
};

// ============================================
// TOPBAR ACTIONS
// ============================================

window.goProfile = function () {
  // ✅ Use hash so browser back works
  window.location.hash = '#profile';
};

window.openSearch = function () {
  showToast('🔍 Search — coming soon!');
};

// ============================================
// PLAY HELPER
// ============================================

function safePlay(bookId, book) {
  if (typeof window.playAudiobook === 'function') {
    window.playAudiobook(bookId, book);
  } else {
    showToast('Player not ready');
  }
}

function addToHistory(book) {
  let h = JSON.parse(localStorage.getItem('historyBooks') || '[]');
  h = h.filter(b => (b.id || b) !== book.id);
  h.unshift({
    id: book.id,
    title: book.title,
    author: book.author,
    coverUrl: book.coverUrl,
  });
  localStorage.setItem('historyBooks', JSON.stringify(h.slice(0, 10)));
}

// ============================================
// HELPERS
// ============================================

function getUserInitial() {
  const u = window.currentUser;
  const name = (u && (u.displayName || u.email)) || 'U';
  return String((name.trim()[0] || 'U')).toUpperCase();
}

function getCover(book) {
  return book.coverUrl || book.safeCoverUrl ||
    'https://placehold.co/400x400/12131A/FFFFFF?text=BlueFM';
}

function getCreatedAtMs(book) {
  const c = book.createdAt;
  if (!c) return 0;
  if (typeof c.toMillis === 'function') return c.toMillis();
  if (typeof c.seconds === 'number') return c.seconds * 1000;
  return Number(c) || 0;
}

function formatPlays(num) {
  const n = Number(num || 0);
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(n >= 10000 ? 0 : 1) + 'K';
  return String(n);
}

function formatCount(n) {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n / 1000).toFixed(n >= 10000 ? 0 : 1) + 'K';
  return String(n);
}

function categoryColor(cat) {
  switch ((cat || '').toLowerCase()) {
    case 'romance': return '#E91E63';
    case 'horror': return '#FF5722';
    case 'fantasy':
    case 'epic fantasy': return '#9C27B0';
    case 'sci-fi': return '#2196F3';
    case 'thriller': return '#FF9800';
    default: return '#DB2777';
  }
}

function genreColorPill(genre) {
  switch ((genre || '').toLowerCase()) {
    case 'thriller': return '#F97316';
    case 'sci-fi': return '#06B6D4';
    case 'fantasy':
    case 'epic fantasy': return '#A855F7';
    case 'romance': return '#F43F5E';
    case 'horror': return '#DC2626';
    case 'mystery': return '#F59E0B';
    case 'comedy': return '#22C55E';
    default: return 'rgba(255,255,255,0.20)';
  }
}

function esc(s) {
  return String(s ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function hexToRgba(hex, a) {
  const h = String(hex).replace('#', '');
  if (h.length !== 6) return `rgba(156,163,175,${a})`;
  return `rgba(${parseInt(h.slice(0, 2), 16)},${parseInt(h.slice(2, 4), 16)},${parseInt(h.slice(4, 6), 16)},${a})`;
}

function showToast(msg) {
  const old = document.querySelector('.toast-notification');
  if (old) old.remove();
  const t = document.createElement('div');
  t.className = 'toast-notification';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.classList.add('show'), 80);
  setTimeout(() => {
    t.classList.remove('show');
    setTimeout(() => t.remove(), 300);
  }, 3000);
}

// ============================================
// EXPORTS (global)
// ============================================

window.routeFromHash       = routeFromHash;
window.navigateTo          = navigateTo;
window.setActiveNav        = setActiveNav;
window.loadHomePage        = loadHomePage;
window.loadLibraryPage     = loadLibraryPage;
window.loadCreatorsPage    = loadCreatorsPage;
window.loadCreatorProfile  = loadCreatorProfile;
window.addToHistory        = addToHistory;
window.showToast           = showToast;
window.formatPlays         = formatPlays;
window.getCover            = getCover;
window.esc                 = esc;

console.log('✅ App Ready (v4 — Hash router enabled for Back button)');
