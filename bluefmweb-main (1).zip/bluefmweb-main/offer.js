console.log("🎁 Offer Page Loading...");

// ============================================
// Wait until firebase-config.js has fully initialized window.db/window.functions
// ============================================
function waitForFirebase(callback, attempts = 0) {
  if (window.db && window.functions) {
    callback();
    return;
  }
  if (attempts > 100) { // ~10 seconds max wait
    console.error("❌ Firebase failed to initialize in time");
    showError("Failed to connect. Please refresh the page.");
    return;
  }
  setTimeout(() => waitForFirebase(callback, attempts + 1), 100);
}

// ============================================
// Get offer ID from URL (?offer=xxx), default 'special49'
// ============================================
function getOfferIdFromUrl() {
  const params = new URLSearchParams(window.location.search);
  return params.get("offer") || "special49";
}

const OFFER_ID = getOfferIdFromUrl();
let currentOffer = null;

// ============================================
// Load offer details from Firestore
// ============================================
async function loadOffer() {
  try {
    const doc = await window.db.collection("offers").doc(OFFER_ID).get();

    if (!doc.exists) {
      document.getElementById("offerTitle").textContent = "Offer not found";
      document.getElementById("offerDesc").textContent = "This offer link is invalid or has expired.";
      document.getElementById("payBtn").disabled = true;
      document.getElementById("payBtn").textContent = "Not Available";
      return;
    }

    const offer = doc.data();
    currentOffer = { id: OFFER_ID, ...offer };

    document.getElementById("offerTitle").textContent = offer.title || "Special Offer";
    document.getElementById("offerDesc").textContent = offer.description || "";
    document.getElementById("offerPrice").textContent = "₹" + (offer.price || 0);

    if (offer.oldPrice) {
      const oldPriceEl = document.getElementById("offerOldPrice");
      oldPriceEl.textContent = "₹" + offer.oldPrice;
      oldPriceEl.style.display = "inline";
    }

    if (offer.active === false) {
      document.getElementById("payBtn").disabled = true;
      document.getElementById("payBtn").textContent = "Offer Not Active";
      showError("This offer is currently not active.");
    } else {
      document.getElementById("payBtn").disabled = false;
    }

  } catch (err) {
    console.error("Load offer error:", err);
    document.getElementById("offerTitle").textContent = "Error loading offer";
    document.getElementById("offerDesc").textContent = err.message || "Please try again later.";
    document.getElementById("payBtn").disabled = true;
  }
}

// ============================================
// Validate phone number (Indian mobile)
// ============================================
function isValidPhone(phone) {
  const cleaned = phone.replace(/\D/g, "").replace(/^91/, "");
  return /^[6-9]\d{9}$/.test(cleaned);
}

function showError(msg) {
  const el = document.getElementById("errorMsg");
  el.textContent = msg;
  el.style.display = "block";
}

function hideError() {
  document.getElementById("errorMsg").style.display = "none";
}

// ============================================
// Handle Pay Now click
// ============================================
async function handlePay() {
  hideError();

  const name = document.getElementById("nameInput").value.trim();
  const phone = document.getElementById("phoneInput").value.trim();

  if (!name || name.length < 2) {
    showError("Please enter your full name.");
    return;
  }

  if (!isValidPhone(phone)) {
    showError("Please enter a valid 10-digit mobile number.");
    return;
  }

  if (!currentOffer) {
    showError("Offer details not loaded. Please refresh.");
    return;
  }

  const payBtn = document.getElementById("payBtn");
  payBtn.disabled = true;
  payBtn.innerHTML = '<span class="spinner-small"></span> Processing...';

  try {
    const createOrder = window.functions.httpsCallable("createCashfreeOfferOrder");
    const result = await createOrder({
      name,
      phone,
      offerId: OFFER_ID
    });

    const data = result.data;
    console.log("🔍 Order Result:", data);   // ✅ ab sahi jagah pe hai, koi error nahi ayega

    if (!data || !data.paymentSessionId) {
      throw new Error("Failed to create payment order.");
    }

const env = (data.env || "sandbox").toLowerCase();
const mode = env === "production" ? "production" : "sandbox";
const cashfree = Cashfree({ mode });

    cashfree.checkout({
      paymentSessionId: data.paymentSessionId,
      redirectTarget: "_self"
    });

  } catch (err) {
    console.error("Payment error:", err);
    showError(err.message || "Payment failed to start. Please try again.");
    payBtn.disabled = false;
    payBtn.textContent = "Pay Now";
  }
}

// ============================================
// Init
// ============================================
document.addEventListener("DOMContentLoaded", () => {
  waitForFirebase(() => {
    console.log("✅ Firebase ready, loading offer:", OFFER_ID);
    loadOffer();

    document.getElementById("payBtn").addEventListener("click", handlePay);

    // Auto-format phone input to digits only
    document.getElementById("phoneInput").addEventListener("input", (e) => {
      e.target.value = e.target.value.replace(/\D/g, "").slice(0, 10);
    });
  });
});
