BLUEFM — SLUGIFY / COVER-UPLOAD FIX
====================================

Problem:
  Cover upload Worker pe "Bad X-File-Name" (400) de raha tha.
  Wajah: jis story ka title special-char / space / hyphen se shuru hota tha,
  uski ID hyphen se banti thi (jaise "-meri-kahani"). Worker ka security check
  sirf letter/number se shuru hone wali ID allow karta hai, isliye cover reject.

Fix:
  server/routes/admin.js me slugify() ab leading/trailing hyphen strip karta hai,
  taaki har story ID letter/number se shuru ho. Cover + audio dono ke liye sahi.

Apply (Windows PowerShell):
  1) Is zip ko C:\Users\User\Downloads\bluefm-fixed\bluefm me extract karo (overwrite).
  2) Backend redeploy:
       cd C:\Users\User\Downloads\bluefm-fixed\bluefm
       npm run fb:prepare
       cd firebase
       firebase deploy --only functions:web --project nodio-575bf
  3) Admin panel me purani (failed) story DELETE karo, phir usi title se DOBARA banao.
     Nayi ID ab letter/number se shuru hogi aur cover upload ho jayega.

Note: Ye fix sirf NAYI stories ki ID sahi karta hai. Purani failed story ko
delete karke dobara banana zaroori hai.
