BLUEFM — DOMAIN SWITCH (bluefm.qzz.io -> bluefm.vercel.app)
=============================================================

Kya hua:
  Free domain bluefm.qzz.io expire ho gaya (NXDOMAIN). Ab site ka main domain
  https://bluefm.vercel.app hai. Ye hotfix Worker CORS + Cashfree return/webhook
  + mobile return URL ko naye domain pe switch karta hai.

Files:
  cloudflare/wrangler.toml              -> Worker ALLOWED_ORIGINS me vercel added
  firebase-web/api.js                   -> APP_URL + ALLOWED_ORIGINS = vercel
  firebase/functions-web/callables.cjs  -> WEB_RETURN_BASE_URL = vercel

Apply (Windows PowerShell), order me:
  1) Is zip ko C:\Users\User\Downloads\bluefm-fixed\bluefm me extract karo (overwrite).

  2) WORKER redeploy (upload CORS ke liye):
       cd C:\Users\User\Downloads\bluefm-fixed\bluefm\cloudflare
       npx wrangler deploy

  3) BACKEND redeploy (Cashfree return/webhook domain ke liye):
       cd C:\Users\User\Downloads\bluefm-fixed\bluefm
       npm run fb:prepare
       cd firebase
       firebase deploy --only functions:web --project nodio-575bf

  4) Site kholo: https://bluefm.vercel.app  (Ctrl+Shift+R hard reload)
     Admin: https://bluefm.vercel.app/admin

Note: Frontend me koi hardcoded domain nahi hai (relative /api use karta hai),
isliye frontend/Vercel redeploy ki zaroorat NAHI hai.
