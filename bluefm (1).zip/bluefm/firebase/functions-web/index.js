/**
 * BLUEFM — Cloud Functions entry point (codebase "web").
 *
 * Two backends live here on purpose:
 *
 *  ── webApi ─────────────────────────────────────────────────────────────
 *    The REST API the website already talks to (/api/*). It is the SAME
 *    Express app as local dev (server/app.js), mounted as a Cloud Function and
 *    backed by Firestore. This is what keeps client/src completely untouched.
 *
 *  ── web* callables ─────────────────────────────────────────────────────
 *    A native Firebase surface (onCall) for future clients that want Firestore
 *    listeners / FCM instead of polling. Shares the same collections.
 */
import './loadEnv.js';
import { webApi } from '../../firebase-web/api.js';

export { webApi };

const c = await (async () => {
  try {
    return await import('./callables.js');
  } catch (err) {
    console.error('[functions-web] callables unavailable:', err.message);
    return {};
  }
})();

export const webHome = c.webHome;
export const webStory = c.webStory;
export const webGetEntitlements = c.webGetEntitlements;
export const webGetStreamUrl = c.webGetStreamUrl;
export const webSaveProgress = c.webSaveProgress;
export const webCreatePassOrder = c.webCreatePassOrder;
export const webVerifyPassPayment = c.webVerifyPassPayment;
export const webCashfreeWebhook = c.webCashfreeWebhook;
export const webAdminGrantPass = c.webAdminGrantPass;
export const webAdminStats = c.webAdminStats;
