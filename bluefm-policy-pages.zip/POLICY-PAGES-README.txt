BLUEFM — POLICY / CONTACT PAGES (Cashfree compliance)
=====================================================

Adds 4 static, crawlable pages + footer links:
  /privacy.html   Privacy Policy
  /terms.html     Terms & Conditions
  /refund.html    Refund & Cancellation Policy
  /contact.html   Contact Us

Support email: BLUEFMOFFICIAL01@GMAIL.COM
Refund rule: verified technical issue / failed payment / duplicate payment.
No refund for change-of-mind or normally used/expired digital passes.

Apply (Windows PowerShell):
  1) Extract this zip into C:\Users\User\Downloads\bluefm-fixed\bluefm (overwrite).
  2) Frontend redeploy ONLY (no Firebase/Worker needed):
       cd C:\Users\User\Downloads\bluefm-fixed\bluefm
       vercel --prod
  3) Hard reload https://bluefm.vercel.app and check footer links:
       https://bluefm.vercel.app/privacy.html
       https://bluefm.vercel.app/terms.html
       https://bluefm.vercel.app/refund.html
       https://bluefm.vercel.app/contact.html

Note: These pages help Cashfree review/compliance. The domain whitelisting
error is separate; bluefm.vercel.app is already approved, so use a NEW order
after approval (old orders created before approval may still show the error).
