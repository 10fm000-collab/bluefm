import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../lib/api.js';
import { useApi, useAuth, usePlayer, useToast } from '../lib/store.jsx';
import {
  StoryCard, Section, WideCard, SkeletonRail, ErrorState, EmptyState, Sheet,
} from '../components/Ui.jsx';
import { InstallBanner, SiteFooter } from '../components/Layout.jsx';
import {
  IconBolt, IconBookmark, IconChevronRight, IconClock, IconHeadphones,
  IconLock, IconPlay, IconSparkle, IconStar, IconTrend, IconUnlock, GenreIcon, IconInfo,
} from '../components/Icons.jsx';
import { compact, countdown, money, plural } from '../lib/format.js';

export default function Home() {
  const { data, loading, error, refetch } = useApi('/api/home');
  const { user } = useAuth();
  const player = usePlayer();
  const toast = useToast();
  const navigate = useNavigate();
  const [heroIdx, setHeroIdx] = useState(0);
  const [unlock, setUnlock] = useState(null);

  const featured = data?.featured || [];

  useEffect(() => {
    if (featured.length < 2) return undefined;
    const t = setInterval(() => setHeroIdx((i) => (i + 1) % featured.length), 7000);
    return () => clearInterval(t);
  }, [featured.length]);

  if (loading) return <HomeSkeleton />;
  if (error) return <div className="page"><ErrorState error={error} onRetry={refetch} /></div>;

  const hero = featured[heroIdx] || featured[0];

  const startStory = async (story) => {
    if (!user) return navigate('/signin', { state: { from: `/story/${story.slug}` } });
    if (story.access?.status !== 'active') {
      return setUnlock(story);
    }
    try {
      const d = await api.get(`/api/stories/${story.slug}`);
      const firstIncomplete = d.episodes.find((e) => !e.progress?.completed) || d.episodes[0];
      await player.play({
        story: d.story,
        episode: firstIncomplete,
        queue: d.episodes,
        resumeAt: firstIncomplete?.progress?.position || 0,
      });
      player.setExpanded(true);
    } catch (err) {
      if (err.code === 'access_locked' || err.code === 'access_expired') setUnlock(story);
      else toast.error(err.message);
    }
  };

  const resume = async (item) => {
    try {
      const d = await api.get(`/api/stories/${item.storyId}`);
      const ep = d.episodes.find((e) => e.id === item.episodeId) || d.episodes[0];
      await player.play({ story: d.story, episode: ep, queue: d.episodes, resumeAt: item.position });
      player.setExpanded(true);
    } catch (err) {
      if (err.code === 'access_locked' || err.code === 'access_expired') {
        const st = data.trending.find((s) => s.slug === item.storyId) || { slug: item.storyId, title: item.storyTitle };
        setUnlock(st);
      } else toast.error(err.message);
    }
  };

  return (
    <div className={`page${player.track ? ' has-player' : ''}`}>
      {!user && (
        <div className="banner-note" style={{ marginTop: 14 }}>
          <IconInfo />
          <div style={{ flex: 1 }}>
            <b>Welcome to BLUEFM.</b> Unlock any story from ₹1 — one story per pass, no subscription.
            <div className="mt-8">
              <Link to="/signin" className="btn btn--primary btn--sm">Sign in to start listening</Link>
            </div>
          </div>
        </div>
      )}
      <InstallBanner />

      {/* -------------------------------------------------------- hero */}
      {hero && (
        <section className="hero" aria-roledescription="carousel" aria-label="Featured stories">
          <div className="hero__bg" style={{ backgroundImage: `url(${hero.cover2x || hero.cover})` }} />
          <div className="hero__scrim" />
          <div className="hero__body">
            <div className="hero__eyebrow">
              <IconBolt width="13" height="13" /> Featured series
            </div>
            <h1 className="hero__title">{hero.title}</h1>
            <p className="hero__tagline">{hero.tagline || hero.synopsis}</p>
            <div className="hero__meta">
              <span className="pill pill--gold"><IconStar width="10" height="10" /> {hero.rating?.toFixed(1)}</span>
              <span>{plural(hero.episodeCount, 'Episode')}</span>
              <span className="dot" />
              <span style={{ textTransform: 'capitalize' }}>{hero.genre?.join(' · ')}</span>
              <span className="dot" />
              <span>{hero.language}</span>
            </div>
            <div className="hero__actions">
              <button type="button" className="btn btn--primary" onClick={() => startStory(hero)}>
                {hero.access?.status === 'active' ? <><IconPlay width="15" height="15" /> Continue listening</> : <><IconLock width="15" height="15" /> Unlock from {money(data.plans?.[0]?.amount || 100)}</>}
              </button>
              <Link to={`/story/${hero.slug}`} className="btn btn--glass">Details</Link>
            </div>
          </div>
          <div className="hero__dots" role="tablist" aria-label="Choose featured story">
            {featured.map((f, i) => (
              <button
                key={f.id}
                type="button"
                role="tab"
                aria-selected={i === heroIdx}
                aria-label={f.title}
                className={i === heroIdx ? 'active' : ''}
                onClick={() => setHeroIdx(i)}
              />
            ))}
          </div>
        </section>
      )}

      {/* ---------------------------------------------- continue listening */}
      {user && data.continueListening.length > 0 && (
        <Section title="Continue listening" icon={<IconClock />}>
          <div className="rail rail--wide">
            {data.continueListening.map((item) => (
              <WideCard
                key={`${item.storyId}-${item.episodeId}`}
                item={item}
                onPlay={() => resume(item)}
                sub={`Ep ${item.episodeNumber} · ${item.episodeTitle} · ${item.percent}%`}
              />
            ))}
          </div>
        </Section>
      )}

      {/* ------------------------------------------------ my purchased */}
      {user && data.myPurchased.length > 0 && (
        <Section title="My purchased stories" icon={<IconUnlock />} action="See all" href="/library">
          <div className="rail">
            {data.myPurchased.map((s) => (
              <div key={s.id}>
                <StoryCard story={s} />
                {s.access?.expiresAt && (
                  <div className="tiny" style={{ color: 'var(--green)', marginTop: 4, fontWeight: 700 }}>
                    {countdown(Date.parse(s.access.expiresAt) - Date.now())}
                  </div>
                )}
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* ---------------------------------------------------- trending */}
      <Section title="Trending audio series" icon={<IconTrend />} action="See all" href="/explore?sort=trending">
        <div className="rail">
          {data.trending.length ? data.trending.map((s) => <StoryCard key={s.id} story={s} priority />) : <EmptyState title="Nothing trending yet" />}
        </div>
      </Section>

      {/* ------------------------------------------------ recently added */}
      <Section title="Recently added" icon={<IconSparkle />} action="See all" href="/explore?sort=latest">
        <div className="rail">
          {data.recentlyAdded.map((s) => <StoryCard key={s.id} story={s} />)}
        </div>
      </Section>

      {/* ---------------------------------------------------- categories */}
      <Section title="Browse categories" icon={<IconBookmark />}>
        <div className="category-grid">
          {data.categories.map((c) => (
            <button
              key={c.id}
              type="button"
              className="category-tile"
              onClick={() => navigate(`/explore?genre=${c.id}`)}
            >
              <GenreIcon id={c.icon} />
              <span className="category-tile__name">{c.name}</span>
              <span className="category-tile__count">{plural(c.count || 0, 'story').replace('storys', 'stories')}</span>
            </button>
          ))}
        </div>
      </Section>

      {/* ------------------------------------------------------ popular */}
      <Section title="Popular this week" icon={<IconHeadphones />} action="See all" href="/explore?sort=popular">
        <div className="rail">
          {data.popular.map((s) => <StoryCard key={s.id} story={s} />)}
        </div>
      </Section>

      {/* -------------------------------------------------- recommended */}
      <Section title={user ? `Picked for you${user.name ? `, ${user.name.split(' ')[0]}` : ''}` : 'Recommended'} icon={<IconStar />}>
        <div className="rail">
          {data.recommended.map((s) => <StoryCard key={s.id} story={s} />)}
        </div>
      </Section>

      {/* -------------------------------------------- recently played */}
      {user && data.recentlyPlayed.length > 0 && (
        <Section title="Recently played episodes" icon={<IconClock />}>
          <div className="story-grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))' }}>
            {data.recentlyPlayed.map((item) => (
              <WideCard
                key={item.storyId + item.episodeId}
                item={item}
                onPlay={() => resume(item)}
                sub={`Ep ${item.episodeNumber} · ${item.episodeTitle}`}
              />
            ))}
          </div>
        </Section>
      )}

      {/* ------------------------------------------------------ pricing */}
      <Section title="Simple passes. One story at a time." icon={<IconBolt />}>
        <div className="row row--wrap" style={{ gap: 10, alignItems: 'stretch' }}>
          {data.plans.map((plan) => (
            <div key={plan.id} className="plan-card" style={{ flex: '1 1 160px' }}>
              <div className="plan-card__head">
                <span className="plan-card__title">{plan.label}</span>
                {plan.badge && <span className="pill pill--new">{plan.badge}</span>}
              </div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 26, fontWeight: 700, margin: '6px 0 2px' }}>
                {money(plan.amount)}
              </div>
              <div className="plan-card__hint">
                {plan.hours >= 24 ? `${Math.round(plan.hours / 24)} ${plan.hours >= 48 ? 'days' : 'day'}` : `${plan.hours} hours`} · one selected story
              </div>
            </div>
          ))}
        </div>
        <p className="tiny dim mt-12">
          Each pass unlocks <b>one story</b>. Other stories stay locked until you buy another pass. Access starts
          after payment is verified on our servers.
        </p>
      </Section>

      <SiteFooter />

      <UnlockSheet story={unlock} onClose={() => setUnlock(null)} />
    </div>
  );
}

function UnlockSheet({ story, onClose }) {
  const navigate = useNavigate();
  if (!story) return null;
  return (
    <Sheet open={!!story} onClose={onClose} title="Unlock this story" subtitle={story.title}>
      <div className="banner-note" style={{ marginBottom: 16 }}>
        <IconLock />
        <div>This story is locked. Choose a pass on the story page to start listening.</div>
      </div>
      <button type="button" className="btn btn--primary btn--block" onClick={() => { onClose(); navigate(`/story/${story.slug}`); }}>
        View plans
      </button>
    </Sheet>
  );
}

function HomeSkeleton() {
  return (
    <div className="page">
      <div className="skel skel-hero" />
      <div className="mt-32"><SkeletonRail /></div>
      <div className="mt-32"><SkeletonRail /></div>
    </div>
  );
}
