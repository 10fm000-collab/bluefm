BLUEFM — HINDI / NON-ENGLISH TITLE FIX (cover + audio upload)
==============================================================

Problem:
  Hindi (Devanagari) title jaise "हे परी, प्लीज़ मुझे अकेला छोड़ दो!" se story-ID
  nahi banti thi (code sirf English letters rakhta tha). Isliye cover/audio ka
  filename invalid hota tha aur Worker "Bad X-File-Name" dekar reject karta tha.
  English title me ID ban jaati thi isliye wo upload ho jaata tha.

Fix (server/routes/admin.js):
  - Agar title se English ID na bane (pure Hindi), to apne-aap safe ID generate
    hoti hai: story-<time>-<random>. Title Hindi hi rehta hai (display ke liye).
  - slug bhi fallback se bharta hai.
  - Leading/trailing hyphen strip (pichla fix) included.

Apply (Windows PowerShell):
  1) Is zip ko C:\Users\User\Downloads\bluefm-fixed\bluefm me extract karo (overwrite).
  2) Backend redeploy (ye domain-switch + Hindi fix dono ek saath live karega):
       cd C:\Users\User\Downloads\bluefm-fixed\bluefm
       npm run fb:prepare
       cd firebase
       firebase deploy --only functions:web --project nodio-575bf
  3) https://bluefm.vercel.app/admin kholo -> Ctrl+Shift+R.
  4) Purani failed Hindi story DELETE karo, phir USI Hindi title se dobara banao.
     Ab cover + MP3 dono upload honge.

Note: Ye fix sirf NAYI stories ki ID sahi karta hai. Purani failed story ko
delete karke dobara banana zaroori hai.
