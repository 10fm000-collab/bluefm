# BLUEFM — Real backend (Firebase + Cashfree + Backblaze B2)

Ye folder aapke **existing production app se alag** hai. Kuch bhi purane app ka
chhua nahi gaya: na `audiobooks`, na `users`, na `subscriptions`, na APK.
Naya app alag collections (`web_*`) aur alag Cloud Functions codebase (`web`)
use karta hai, isliye dono ek hi Firebase project me safely reh sakte hain.

```
firebase/
  firebase.json              # functions:web + firestore rules + hosting
  firestore.rules            # sirf web_* collections + shared admins
  firestore.indexes.json     # web_* composite indexes
  functions-web/
    index.js                 # saara web backend (callable + webhook)
    package.json
scripts/
  migrate-to-firebase.js     # local store -> Firestore (web_*) + B2 upload
```

## 1. Prices (double kar diye)

| Plan | Pehle | Ab | Duration |
|------|-------|-----|----------|
| Daily | ₹1 | **₹2** | 24 ghante |
| Weekly | ₹7 | **₹14** | 168 ghante (7 din) |
| Monthly | ₹30 | **₹60** | 720 ghante (30 din) |

Amount **sirf server** decide karta hai (`PLANS` in `functions-web/index.js` aur
`server/config.js`). Client kabhi amount nahi bhej sakta. Ek pass = ek story
(wahi model, jaisa aapne kaha).

## 2. Cloud Functions (callable list)

| Function | Kaam |
|----------|------|
| `webHome` | Home rails, featured/trending/recent, continue listening |
| `webStory` | Story + episodes; `audioKey` client ko kabhi nahi jaata |
| `webCreatePassOrder` | Cashfree order banata hai → `payment_session_id` |
| `webVerifyPassPayment` | Server-to-server order lookup (`PAID`) → pass grant |
| `webCashfreeWebhook` | Signed webhook, idempotent by event id |
| `webGetStreamUrl` | Entitlement check + **600s ka B2 signed URL** |
| `webSaveProgress` | Progress sirf active pass pe |
| `webGetEntitlements` | User ke saare passes (active/expired) |
| `webAdminGrantPass` | Admin bulk manual grant (audit ke saath) |
| `webAdminStats` | Revenue / active passes / failures |

**Security ka core rule:** access sabhi jagah *server time* pe check hota hai.
Frontend ka "success", localStorage, URL param, koi bhi client timestamp —
kisi ko trust nahi kiya jaata.

## 3. Cashfree setup

Aapke existing `functions/index.js` wala hi scheme:

- Header: `x-client-id`, `x-client-secret`, `x-api-version: 2025-01-01`
- Order create → `payment_session_id` → Cashfree Checkout
- Verify → `GET /orders/{order_id}`, `order_status === "PAID"`
- Webhook → `base64(HMAC-SHA256(secret, \`${ts}.${rawBody}\`))` vs `x-webhook-signature`
- `WEB_RETURN_BASE_URL=https://bluefm.live`

Secrets set karo (ek hi baar):

```bash
firebase functions:secrets:set CASHFREE_CLIENT_ID
firebase functions:secrets:set CASHFREE_CLIENT_SECRET
firebase functions:secrets:set CASHFREE_ENV        # sandbox | production
firebase functions:secrets:set STREAM_TOKEN_SECRET
firebase functions:secrets:set B2_KEY_ID
firebase functions:secrets:set B2_APP_KEY
firebase functions:secrets:set B2_BUCKET_ID
```

Webhook URL Cashfree dashboard me daalo:

```
https://us-central1-<PROJECT>.cloudfunctions.net/webCashfreeWebhook
```

> `CASHFREE_ENV=production` tabhi karo jab live keys hon — sandbox keys pe
> production URL 401 dega aur ulta bhi.

## 3.5 Delivery: Cloudflare (B2 sirf storage hai)

Aapne sahi pakda — real app me B2 **storage** hai aur **streaming Cloudflare** se
hoti hai. Wahi yahan bhi hai:

```
Browser ──> media.bluefm.live (Cloudflare edge, cache HIT)
                │ cache MISS
                └─> B2 origin (private bucket)
```

- Browser ko kabhi `backblazeb2.com` nahi dikhta
- B2 → Cloudflare egress **free** (Bandwidth Alliance), Cloudflare → user **free**
- Ek object ek baar B2 se aata hai, phir sabko edge se milta hai
- Playback URL: `https://media.bluefm.live/<episodeId>.mp3?t=<HMAC token>`

Server side bas ek env:

```bash
B2_DOWNLOAD_URL=https://media.bluefm.live
STREAM_TOKEN_SECRET=<same value in worker + server>
```

Set hote hi `webGetStreamUrl` / `/api/playback/authorize` ka `delivery`
`cloudflare` ho jaata hai. Bina set kiye B2 signed URL pe fallback hai (kaam
karta hai, lekin egress billable).

Pura setup (B2 custom domain + Cloudflare cache rules + worker deploy):
[`../cloudflare/README.md`](../cloudflare/README.md)

Worker verified hai — `node test/worker.test.mjs` → **8/8**:
token forge/expire/mismatch → 403, valid → 200, dusri request cache HIT
(B2 hit count 1 rehta hai), Range → 206 edge se, path traversal → 400.

## 4. Backblaze B2 (already verified ✅)

Is repo se already test ho chuka hai:

- Naya **private** bucket: `bluefm-web-audio` (id `e0af0a7f83d0af4ba71b0c1e`)
- Aapka existing `nodioaudio` bucket **bilkul untouched**
- Upload ✔ | List ✔ | Signed URL se range stream `206 audio/mpeg` ✔
- Bina auth ke access `401` ✔

Aage ka flow:

```bash
export B2_KEY_ID=...        # naya, bucket-scoped key (recommended)
export B2_APP_KEY=...
export B2_BUCKET_ID=e0af0a7f83d0af4ba71b0c1e
export B2_BUCKET_NAME=bluefm-web-audio
export GOOGLE_APPLICATION_CREDENTIALS=./service-account.json

node scripts/migrate-to-firebase.js            # dry run
node scripts/migrate-to-firebase.js --apply    # 66 audio files upload + web_* docs
```

Audio **kabhi public URL se nahi** milta. Browser ko sirf 10 minute ka signed
URL milta hai, wahi bhi entitlement check ke baad. Pass expire = naya URL nahi =
playback band.

## 5. Local server bhi same model pe chal raha hai

Purana express server (UI same) ab ye support karta hai:

```bash
# local audio (default, dev)
AUDIO_STORAGE=local npm run dev

# B2 se streaming
AUDIO_STORAGE=b2 B2_KEY_ID=... B2_APP_KEY=... B2_BUCKET_ID=... B2_BUCKET_NAME=bluefm-web-audio npm run dev

# Cashfree payments
PAYMENT_PROVIDER=cashfree CASHFREE_CLIENT_ID=... CASHFREE_CLIENT_SECRET=... CASHFREE_ENV=sandbox npm run dev
```

Live proof (is run ka output):

```
login: 200
authorize: 200 | delivery: b2 | access: weekly
url host: f005.backblazeb2.com
B2 stream: 206 audio/mpeg 2048 bytes | mp3: true
locked story authorize: 403 This story is locked. Purchase a pass to listen.
```

## 6. Regression: 17/17 pass

```bash
npm test     # prices ₹2/₹14/₹60 ke hisaab se updated assert
```

## 7. Jo abhi bhi aapse chahiye

| Cheez | Kahan daalna hai |
|-------|------------------|
| `CASHFREE_CLIENT_ID` + `SECRET` | `firebase functions:secrets:set` (ya VS Code `.env`) |
| Cashfree **production** approval | merchant dashboard |
| Firebase project + service account | `firebase use --add` / `GOOGLE_APPLICATION_CREDENTIALS` |
| Rotated B2 key (bucket-scoped) | secrets — purani chat me expose ho gayi thi |
| B2 + Cloudflare custom domain (optional) | `B2_DOWNLOAD_URL` / worker |

## 8. Safety checklist

- [x] Purane collections ko touches nahi: sirf `web_*` + `admins`
- [x] Purane functions codebase se alag (`codebase: "web"`)
- [x] Rules me `web_story_entitlements` ka write **always false** (sirf Admin SDK)
- [x] Audio private bucket + short-lived signed URL
- [x] Webhook signature verify + idempotency
- [x] Price sirf server se
- [x] UI bilkul same (koi design change nahi)
