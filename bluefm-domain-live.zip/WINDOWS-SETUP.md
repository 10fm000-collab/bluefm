# Windows + PowerShell — step by step

Aapka setup: **Windows**, project `nodio-575bf`, domain `bluefm.live`, Vercel
frontend, Firebase backend, B2 storage, Cashfree production.

Har command PowerShell me chalao, `bluefm` folder ke andar.

> **Current domain:** `https://bluefm.live`. `https://www.bluefm.live` aur
> `https://bluefm.vercel.app` fallback ke liye allowed hain. Domain change me
> Cashfree/B2/Cloudflare keys nahi badalti. Latest deploy steps: `DOMAIN-SETUP.md`.

---

## Phase 0 — prerequisites (ek baar)

```powershell
node -v      # v20.x chahiye (v18+ chalega, v20 recommended)
npm -v
git --version
```

Agar Node nahi hai: https://nodejs.org → LTS.

```powershell
npm i -g firebase-tools vercel cross-env
firebase --version
vercel --version
```

> `cross-env` global install zaroori nahi — `npm install` ke baad local me aa
> jaata hai. Global rakhna harmless hai.

---

## Phase 1 — project chalao (2 min)

```powershell
cd C:\path\to\bluefm
npm install
Copy-Item .env.example .env
notepad .env
```

`.env` me ye bharo (details neeche):

```ini
SESSION_SECRET=<32 random chars>
AUDIO_SIGNING_SECRET=<32 random chars>
STREAM_TOKEN_SECRET=<32 random chars>
ADMIN_PASSWORD=<koi strong password>

AUDIO_STORAGE=b2
B2_KEY_ID=<naya bucket-scoped key>
B2_APP_KEY=<naya app key>
B2_BUCKET_ID=e0af0a7f83d0af4ba71b0c1e
B2_BUCKET_NAME=bluefm-web-audio

PAYMENT_PROVIDER=cashfree
CASHFREE_CLIENT_ID=<naya app id>
CASHFREE_CLIENT_SECRET=<naya secret>
CASHFREE_ENV=sandbox

WEB_RETURN_BASE_URL=https://bluefm.live
```

Random secret generate karne ka PowerShell one-liner:

```powershell
[Convert]::ToBase64String((1..32 | ForEach-Object { Get-Random -Max 256 }))
```

Ab chalao:

```powershell
npm start
```

`http://localhost:8080` kholo. Pehli baar seed data chahiye to:

```powershell
npm run seed
```

> **`npm start` ab Windows pe chalta hai** — scripts me `cross-env` laga diya
> hai, isliye `NODE_ENV=production` wali bash syntax ki zaroorat nahi.

---

## Phase 2 — Firebase (nodio-575bf)

### 2.1 login + project select

```powershell
firebase login
cd firebase
firebase use nodio-575bf
```

Verify:

```powershell
firebase projects:list
```
`nodio-575bf` ke aage `(current)` dikhna chahiye.

### 2.2 Firestore + Auth on karo

Firebase Console → project `nodio-575bf`:

- **Firestore Database** → Create database → **asia-south1 (Mumbai)** → Production mode
- **Authentication** → Get started → **Email/Password** enable
- **Functions** → upgrade to **Blaze** (pay-as-you-go; free tier kaafi hai,
  par Cloud Functions ke liye Blaze chahiye)

### 2.3 secrets set karo

PowerShell me ek-ek:

```powershell
firebase functions:secrets:set SESSION_SECRET
firebase functions:secrets:set AUDIO_SIGNING_SECRET
firebase functions:secrets:set STREAM_TOKEN_SECRET
firebase functions:secrets:set ADMIN_PASSWORD
firebase functions:secrets:set CASHFREE_CLIENT_ID
firebase functions:secrets:set CASHFREE_CLIENT_SECRET
firebase functions:secrets:set CASHFREE_ENV        # value: sandbox
firebase functions:secrets:set B2_KEY_ID
firebase functions:secrets:set B2_APP_KEY
firebase functions:secrets:set B2_BUCKET_ID
```

Har command value puchegi — `.env` wali same value paste karo.

> Yehi values locally aur cloud me honi chahiye, warna local me bana token
> cloud pe verify nahi hoga.

### 2.4 deploy

```powershell
cd ..            # wapas bluefm root me
npm run fb:prepare      # server/ + firebase-web/ ko functions folder me copy
cd firebase
firebase deploy --only functions:web
```

Pehli deploy me 3–6 min lagte hain. Success pe URL milega:

```
Function URL (webApi): https://asia-south1-nodio-575bf.cloudfunctions.net/webApi
```

Test:

```powershell
curl https://asia-south1-nodio-575bf.cloudfunctions.net/webApi/api/health
```

`{"ok":true,...}` aana chahiye. **Agar 500 aaye** to:

```powershell
firebase functions:log --only webApi
```

### 2.5 data migrate karo

Service account chahiye (Console → Project settings → Service accounts →
Generate new private key → JSON download):

```powershell
$env:GOOGLE_APPLICATION_CREDENTIALS="C:\path\to\service-account.json"
$env:B2_KEY_ID="<naya key>"
$env:B2_APP_KEY="<naya secret>"
$env:B2_BUCKET_ID="e0af0a7f83d0af4ba71b0c1e"
$env:B2_BUCKET_NAME="bluefm-web-audio"

node scripts/migrate-to-firebase.js                      # dry run
node scripts/migrate-to-firebase.js --apply              # asli write
node scripts/migrate-to-firebase.js --verify             # check
```

`--verify` ka output aisa aana chahiye:

```
[verify] published stories: 10
[verify] episodes: 67
[verify] sample:
  • last-metro         Last Metro
  ...
[verify] ✓ OK — the web app will render this catalogue.
```

Agar `EMPTY` aaye to migration nahi chala — `--apply` dobara.

### 2.6 admin banao

Pehle site pe normal signup karo (email+password), phir:

```powershell
node scripts/make-admin.js aapka@email.com --project=nodio-575bf
```

Ye 3 kaam karta hai:
- `users/{id}.role = "admin"`
- `admins/{firebaseUid}` doc banata hai (rules + functions yahi check karte hain)
- Firebase custom claim `admin: true`

Uske baad `/admin` khulega.

### 2.7 rules + indexes

⚠️ **Pehle backup** (agar project me pehle se rules hain):

```powershell
firebase firestore:rules:get > live-rules-backup.txt
```

`nodio-575bf` naya project hai aur khaali tha, isliye seedha deploy safe hai:

```powershell
firebase deploy --only firestore:rules,firestore:indexes
```

---

## Phase 3 — Vercel + domain bluefm.live

### 3.1 deploy

```powershell
cd C:\path\to\bluefm
vercel login
vercel            # pehli baar: link/create project
vercel --prod
```

`vercel.json` already hai (`/api/*` → Firebase function, SPA fallback, cache
headers). Build command `npm run build`, output `dist/client`.

### 3.2 Firebase web config inject karo

Firebase Console → Project settings → **Your apps** → Web app add karo →
config milta hai. Vercel → Project → Settings → Environment Variables:

| Name | Value |
|------|-------|
| `VITE_FIREBASE_API_KEY` | `AIza...` |
| `VITE_FIREBASE_AUTH_DOMAIN` | `nodio-575bf.firebaseapp.com` |
| `VITE_FIREBASE_PROJECT_ID` | `nodio-575bf` |
| `VITE_FIREBASE_APP_ID` | `1:...:web:...` |

Redeploy: `vercel --prod`

### 3.3 domain lagao

Vercel → Project → Settings → **Domains** me `bluefm.live` aur
`www.bluefm.live` add karo. Registrar/DNS panel me **sirf Vercel ke dikhaye hue
current A/CNAME/TXT values** use karo; kisi purane guide ka hardcoded IP ya
verification token copy mat karo. DNS propagate hone me kuch minutes se hours
lag sakte hain. Dono hosts HTTPS par valid hone chahiye.

```powershell
nslookup bluefm.live
nslookup www.bluefm.live
```

Website code me primary origin `https://bluefm.live` hai. `npm run fb:prepare`
Functions ke local `.env` me `APP_URL`, `WEB_RETURN_BASE_URL` aur
`ALLOWED_ORIGINS` sync karta hai, baaki env values/credentials preserve rehte hain.

### 3.4 CORS

Frontend ab Vercel se, API Firebase se — cross-origin hai. Server side already
`credentials: include` + explicit origin handle karta hai; check karo:

```powershell
curl -i -X OPTIONS https://asia-south1-nodio-575bf.cloudfunctions.net/webApi/api/auth/me `
  -H "Origin: https://bluefm.live" `
  -H "Access-Control-Request-Method: GET"
```

Agar `Access-Control-Allow-Origin` missing ho to `.env`/secrets me
`ALLOWED_ORIGINS=https://bluefm.live,https://www.bluefm.live,https://bluefm.vercel.app` set karo aur redeploy.

> **Cookie ka issue:** cross-site cookie ke liye `SameSite=None; Secure`
> chahiye. Ye already code me handle hai (`NODE_ENV=production` hone pe), par
> agar login ke baad `/api/auth/me` 401 de raha ho to:
> Vercel domain (`bluefm.live`) aur Firebase function domain alag-alag hain —
> isliye cookie `SameSite=None` hona zaroori hai. Chrome DevTools → Application
> → Cookies me check karo ki `secure` aur `none` set hain.

---

## Phase 4 — Cashfree

### 4.1 return URL + whitelist

Existing working Cashfree keys/env ko mat badlo. Code naye orders ke liye ye URLs
banata hai:

```text
Return:  https://bluefm.live/payment/return?order_id={order_id}
Webhook: https://bluefm.live/api/payments/webhooks/cashfree
```

Cashfree Dashboard → Developers/Whitelisting me `https://bluefm.live` (aur www
use karna ho to `https://www.bluefm.live`) approve karwao. Purane failed order
ko retry mat karo; backend deploy ke baad **fresh order** banao. Webhook signing
secret same rehta hai.

### 4.2 test

Sandbox me test card se payment karo. Check:

```powershell
firebase functions:log --only webApi
```

`payment verified` / `entitlement granted` dikhna chahiye.

### 4.3 live jaane se pehle

```powershell
firebase functions:secrets:set CASHFREE_ENV      # production
firebase functions:secrets:set CASHFREE_CLIENT_ID      # live id
firebase functions:secrets:set CASHFREE_CLIENT_SECRET  # live secret
firebase deploy --only functions:web
```

Aur `.env` me bhi same (local ke liye).

---

## Phase 5 — Cloudflare (baad me, jab ready ho)

Abhi B2 direct de raha hai (`f005.backblazeb2.com`). Ye **kaam karta hai** par
B2 egress billable hai. Free karne ke liye `cloudflare/README.md` follow karo.
Jab tak nahi karte, `delivery: "b2"` — theek hai.

---

## Kab kya check karein (troubleshooting)

| Symptom | Wajah | Fix |
|---------|-------|-----|
| Site khulti hai par stories nahi | Firestore khaali ya collection name mismatch | `node scripts/migrate-to-firebase.js --verify` |
| `webApi` 500 | secret missing ya boot fail | `firebase functions:log --only webApi` |
| Login ke baad turant logout | cross-site cookie block | SameSite=None + HTTPS, upar 3.4 dekho |
| `/api/*` 404 Vercel pe | rewrite galat region | `vercel.json` me `asia-south1-nodio-575bf` hona chahiye |
| Payment ke baad access nahi | webhook signature fail | Cashfree dashboard me webhook URL + secret check |
| Audio 401 | STREAM_TOKEN_SECRET alag hai (server vs worker) | dono jagah same value |
| `npm start` fail | purana zip | naya package.json (cross-env) use karo |
| Admin page 403 | `admins/{uid}` doc nahi | `node scripts/make-admin.js` |

---

## Ek nazar me order

```
1. npm install + .env bharo            (5 min)
2. npm start → localhost:8080 chale    (2 min)
3. firebase login + use nodio-575bf    (2 min)
4. Firestore (asia-south1) + Auth on   (5 min)
5. secrets set (11 commands)           (10 min)
6. npm run fb:prepare + deploy         (8 min)
7. migrate --apply + --verify          (5 min)
8. signup + make-admin                 (3 min)
9. firestore:rules deploy              (2 min)
10. vercel deploy + env vars           (10 min)
11. domain + DNS A/TXT                 (5 min + propagation)
12. Cashfree webhook URL               (3 min)
13. sandbox payment test               (5 min)
```
