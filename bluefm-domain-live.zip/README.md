# BLUEFM — Premium Audio Series

A production-shaped, mobile-first audio-series streaming web app: discover original series, buy a pass for **one selected story**, and stream episodes with server-authoritative access control.

> **Running right now:** the app is served at `/` (Express serving the built client + API on the same origin).
> Demo listener `listener@bluefm.app / bluefm123` · Admin `admin@bluefm.app / bluefm-admin-2026`

---

## Phase 2 — real stack

Payments **Cashfree** (₹2 / ₹14 / ₹60), storage **Backblaze B2** (private bucket),
delivery **Cloudflare CDN**, backend **Firebase Functions** in `firebase/functions-web/`.

```
Browser ──> media.bluefm.live (Cloudflare edge, cached)
                 └─ MISS ─> B2 origin (private)
```

B2 egress Cloudflare ke through **free** hai (Bandwidth Alliance), aur browser ko
`backblazeb2.com` kabhi nahi dikhta. Full guide: [`firebase/README.md`](firebase/README.md)
· CDN setup: [`cloudflare/README.md`](cloudflare/README.md)

## What actually works (no decorative controls)

| Area | Status |
| --- | --- |
| Browse home / explore / search / filters / sort | Real DB queries, paginated |
| Story detail + episode list | Public metadata; playback locked |
| Email + password auth, sessions, logout, profile edit, password change | Working |
| Daily ₹2 / Weekly ₹14 / Monthly ₹60 passes | Working, per-story entitlements |
| Payment order → checkout → **server-side signature verification** → webhook | Working (sandbox provider with real HMAC signatures) |
| Failed / cancelled / refunded payments | Handled, no access granted, refund revokes |
| Idempotent webhooks + duplicate verification | Tested – single entitlement, no stacked time |
| Expiry enforcement on every playback request | Tested |
| Signed, short-lived, entitlement-scoped audio URLs + HTTP Range | Working |
| Audio player: play/pause, seek, ±15s, prev/next, autoplay-next, 0.75×–2×, resume, progress sync | Working |
| Mini player + full-screen player, Media Session | Working |
| Favourites, listening history, continue listening | Working |
| Admin: dashboard, story CRUD + cover upload, episode upload (ffprobe duration), reorder, publish, payments table, users, audit log | Working |
| PWA: manifest, icons, service worker, offline page | Working (audio never cached) |
| Google / phone sign-in | **Not configured** — endpoint returns the exact requirement instead of faking it |
| Razorpay live payments | **Adapter implemented, keys required** |
| Firebase Auth / Firestore / B2 | **Adapters documented, credentials required** |

---

## Quick start

```bash
npm install
npm run seed      # builds covers + narration audio + demo data (first run ~60s)
npm run build     # builds the client into dist/client
npm start         # http://localhost:8080
```

Dev mode with HMR: `npm run dev` (API) and `npx vite` (client on :5173, proxies `/api`).

### Tests

```bash
# isolated test instance on :8099
DATA_DIR=/tmp/bluefm-test PORT=8099 node server/seed.js --reset
DATA_DIR=/tmp/bluefm-test PORT=8099 node server/index.js &
BASE=http://localhost:8099 node --test test/
```

17 tests cover auth, locked playback, failed payments, forged signatures, 24h pass maths,
webhook idempotency, per-story isolation, token binding, tampered cookies and admin RBAC.

---

## Configuration

Copy `.env.example` → `.env`. Everything is optional for local runs.

| Variable | Purpose |
| --- | --- |
| `PORT` | Server port (default 8080) |
| `APP_URL` | Public base URL — used to print the webhook URL |
| `DATA_DIR` | Where the JSON store, covers and audio live |
| `SESSION_SECRET` | HMAC secret for session cookies (auto-generated if empty) |
| `AUDIO_SIGNING_SECRET` | HMAC secret for signed playback URLs |
| `AUDIO_TOKEN_TTL` | Playback URL lifetime in seconds (default 600) |
| `AUDIO_STORAGE` | `local` or `b2` (Backblaze adapter) |
| `B2_DOWNLOAD_URL` | Cloudflare CDN base (e.g. `https://media.bluefm.live`) — ye set karte hi delivery Cloudflare ho jaati hai |
| `STREAM_TOKEN_SECRET` | Worker + server ka shared HMAC secret |
| `PAYMENT_PROVIDER` | `sandbox` (default) or `razorpay` |
| `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET` | Live payments |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD` | Bootstrap admin account |
| `AUTH_MODE`, `FIREBASE_PROJECT_ID`, `FIREBASE_SERVICE_ACCOUNT_JSON` | Firebase Auth |

Secrets are read server-side only. Nothing sensitive is ever sent to the client.

---

## Project layout

```
bluefm/
├── client/                 React 19 + React Router (Vite)
│   ├── src/pages/          Home, Explore, Story, SignIn, Library, Profile, Admin
│   ├── src/components/     UI kit, player shell, layout
│   └── src/styles/app.css  Design system (tokens + components)
├── server/
│   ├── index.js            Express app, security headers, SPA fallback
│   ├── routes/             auth, catalog, playback, payments, user, admin
│   ├── services/           payments (settlement/webhooks), catalog shaping
│   ├── lib/                access control, auth, crypto, rate limiting, time
│   ├── payments/provider.js  sandbox + Razorpay adapters
│   ├── db.js               transactional JSON store (Firestore-shaped API)
│   ├── catalog.js          seed content (stories, genres, episode titles)
│   ├── narration.js        narration scripts → generated demo audio
│   └── seed.js             covers (sharp), audio (espeak-ng+ffmpeg), demo data
├── docs/                   architecture, schema, deployment, testing, security
└── test/api.test.js        17 API/security tests
```

## Documentation

- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — audit of the existing-system question, stack decisions, request flows, adapter boundaries
- [`docs/DATABASE_SCHEMA.md`](docs/DATABASE_SCHEMA.md) — every collection, field, index and the Firestore mapping
- [`docs/SECURITY.md`](docs/SECURITY.md) — threat model and the control that answers each threat
- [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md) — env vars, staging/prod, Firebase rules, Razorpay + B2/CDN wiring
- [`docs/TESTING.md`](docs/TESTING.md) — the 18-point test report with results

## Honest limitations

1. **No access to your existing BLUEFM repo / Firebase / B2 credentials.** The app is built as an isolated product with documented adapters so it can be pointed at your infrastructure without touching production collections. See `docs/ARCHITECTURE.md §1`.
2. **Payments run in labelled sandbox mode** — real HMAC signature + webhook verification, no money. Swap `PAYMENT_PROVIDER=razorpay` with merchant keys to go live. ₹1 authorisation requires your merchant account to allow it (Razorpay supports ₹1 orders; some banks reject sub-₹5 cards — validate with a live test transaction).
3. **Demo content is original and AI-assisted**: 10 stories, 67 episodes with generated narration audio, generated cover art. Replace via the admin dashboard.
4. **Voice tracks are short (~35 s)** so the repo stays small; the player, progress and auto-advance behave the same with real-length files.
5. Google/phone sign-in needs Firebase; the server route returns a structured "not configured" response rather than a fake login.
