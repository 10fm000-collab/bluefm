BLUEFM cache hotfix

Extract this zip INTO the bluefm project root (overwrite public/sw.js and vercel.json), then run:

  vercel --prod

After deploy, existing users self-heal on next visit/open tab; no manual cache clearing.
