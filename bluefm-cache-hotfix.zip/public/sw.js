/* BLUEFM service worker — self-healing app-shell cache.
 *
 * v2 hotfix: early builds could cache a broken/HTML response for cover art and
 * serve it forever (stale-while-revalidate + immutable HTTP headers). This
 * version deletes ALL old caches on activate, reloads open tabs once so failed
 * <img> elements retry, and treats covers as network-first with strict
 * image/* validation. Paid audio/auth/payment traffic is NEVER cached.
 */
const VERSION = 'bluefm-v2';
const SHELL = `${VERSION}-shell`;
const STATIC = `${VERSION}-static`;
const COVERS = `${VERSION}-covers`;

// Do not cache "/" as an app shell: navigations must stay network-first so a
// new deployment is picked up immediately. Offline fallback is offline.html.
const SHELL_ASSETS = ['/offline.html', '/manifest.webmanifest', '/icons/icon-192.png'];

function isImageResponse(res) {
  if (!res || !res.ok) return false;
  const type = res.headers.get('content-type') || '';
  return type.toLowerCase().startsWith('image/');
}

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(SHELL);
      await cache.addAll(SHELL_ASSETS.map((u) => new Request(u, { cache: 'reload' })));
      await self.skipWaiting();
    })(),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      const stale = keys.filter((k) => !k.startsWith(VERSION));
      await Promise.all(stale.map((k) => caches.delete(k)));
      await self.clients.claim();

      // One-time upgrade reload: users who already had the broken v1 worker
      // get a fresh page under v2 without manually clearing site data.
      if (stale.length > 0) {
        const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
        await Promise.all(
          clients.map((c) => (c.navigate ? c.navigate(c.url).catch(() => {}) : Promise.resolve())),
        );
      }
    })(),
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  // Never cache or intercept audio, auth or payment traffic.
  if (url.pathname.startsWith('/api/')) return;

  // Let the browser always revalidate the worker script itself.
  if (url.pathname === '/sw.js') return;

  // Hashed build assets: cache-first is safe because filenames change.
  if (url.pathname.startsWith('/assets/')) {
    event.respondWith(
      caches.open(STATIC).then(async (cache) => {
        const hit = await cache.match(request);
        if (hit) return hit;
        const res = await fetch(request);
        if (res.ok) cache.put(request, res.clone());
        return res;
      }),
    );
    return;
  }

  // Icons are small and stable, but keep them in the versioned cache so a
  // version bump can still replace them.
  if (url.pathname.startsWith('/icons/')) {
    event.respondWith(
      caches.open(STATIC).then(async (cache) => {
        const hit = await cache.match(request);
        if (hit) return hit;
        const res = await fetch(request);
        if (res.ok) cache.put(request, res.clone());
        return res;
      }),
    );
    return;
  }

  // Cover art: network-first, bypass the HTTP cache, and only cache real
  // images. This prevents an old 200 HTML fallback / 404 from being served as
  // a cover forever. Offline fallback is allowed only for validated images.
  if (url.pathname.startsWith('/media/covers/')) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(COVERS);

        const hit = await cache.match(request);
        if (hit && !isImageResponse(hit)) await cache.delete(request);

        try {
          const res = await fetch(request, { cache: 'reload' });
          if (isImageResponse(res)) {
            await cache.put(request, res.clone());
            return res;
          }
          return res;
        } catch {
          const fallback = await cache.match(request);
          if (isImageResponse(fallback)) return fallback;
          return Response.error();
        }
      })(),
    );
    return;
  }

  // Navigations: network-first with offline fallback.
  if (request.mode === 'navigate') {
    event.respondWith(
      (async () => {
        try {
          return await fetch(request, { cache: 'no-cache' });
        } catch {
          const cache = await caches.open(SHELL);
          return (await cache.match('/offline.html')) || Response.error();
        }
      })(),
    );
  }
});
