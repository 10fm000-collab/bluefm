# BLUEFM — start here

This is the complete web-project snapshot, including all the fixes and the latest sticky **Download App** button. Read these two files first:

1. [`README.md`](README.md) — what is included, how to build, and safe deploy commands.
2. [`HANDOFF-STATUS.md`](HANDOFF-STATUS.md) — what is already live, user constraints, and pending verification.

The primary site is `https://bluefm.live`. The Android APK is linked from the website header and remains hosted separately on GitHub Releases.

## Important safety notes

- No live secrets or production database export are in this ZIP. Do not ask the owner to paste Cashfree, Firebase, B2, or Cloudflare secret values into chat.
- Cashfree credentials and domain whitelist are already configured by the owner. Do not rotate/re-enter them unless the owner explicitly reports a problem.
- For Firebase Functions, the deploy filter is `functions:web` with `--project nodio-575bf`. Do not deploy Firestore rules/indexes as part of a routine web update.
- Cloudflare is the delivery/upload layer; B2 is storage only.
- Keep the Hindi story title in Hindi. The code generates a safe ASCII storage ID automatically.
- Do not clear production demo/sample data without first running a dry-run and getting the owner's explicit approval to apply it.

For deployment, follow the exact steps in the README and the Windows setup guide. Deploy only the layer whose code changed.
