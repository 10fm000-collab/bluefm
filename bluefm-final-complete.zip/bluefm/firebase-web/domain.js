/**
 * Public website origins (NOT secrets).
 *
 * bluefm.live is the canonical website and Cashfree return origin. The Vercel
 * hostname stays allowed as a fallback. The Worker and B2 keep their own URLs;
 * changing the website domain does not change storage or require new API keys.
 */
export const APP_ORIGIN = 'https://bluefm.live';
export const ALLOWED_ORIGINS = Object.freeze([
  APP_ORIGIN,
  'https://www.bluefm.live',
  'https://bluefm.vercel.app',
]);

export const DOMAIN_ENV = Object.freeze({
  APP_URL: APP_ORIGIN,
  WEB_RETURN_BASE_URL: APP_ORIGIN,
  ALLOWED_ORIGINS: ALLOWED_ORIGINS.join(','),
});

/**
 * Update only the three public domain settings in a Functions .env file.
 * Preserve every unrelated line/value (including any local settings) so a
 * deploy can never overwrite credentials. Duplicate assignments all get the
 * same value, avoiding dotenv last-wins surprises. No file I/O or logging here.
 */
export function applyDomainEnv(source = '') {
  const text = String(source);
  const newline = text.includes('\r\n') ? '\r\n' : '\n';
  let lines = text.split(/\r?\n/);
  for (const [key, value] of Object.entries(DOMAIN_ENV)) {
    const assignment = new RegExp('^(\\s*(?:export\\s+)?' + key + '\\s*=).*$');
    let found = false;
    lines = lines.map((line) => {
      const match = assignment.exec(line);
      if (!match) return line;
      found = true;
      return match[1] + value;
    });
    if (!found) lines.push(`${key}=${value}`);
  }
  return lines.join(newline).replace(/\r?\n$/, '') + newline;
}
