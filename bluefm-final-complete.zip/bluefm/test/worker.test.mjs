/**
 * Cloudflare Worker test — runs the REAL worker code with stubbed Web APIs.
 * Proves: bad/expired token → 403, valid token → 200, Range → 206,
 * second request served from cache (B2 origin hit only once).
 */
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import { ALLOWED_ORIGINS } from '../firebase-web/domain.js';

const SECRET = 'edge_test_secret_123';
const AUDIO = fs.readFileSync('data/media/audio/last-metro-e1.mp3');

/* ---- minimal Web API surface the worker relies on ---- */
const b64u = (buf) => Buffer.from(buf).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');

class Headers2 {
  constructor(init = {}) { this.m = new Map(); for (const [k, v] of Object.entries(init)) this.set(k, v); }
  set(k, v) { this.m.set(k.toLowerCase(), String(v)); }
  get(k) { return this.m.get(k.toLowerCase()) ?? null; }
  has(k) { return this.m.has(k.toLowerCase()); }
  delete(k) { this.m.delete(k.toLowerCase()); }
  *[Symbol.iterator]() { yield* this.m.entries(); }
  entries() { return this.m.entries(); }
}
class Response2 {
  constructor(body, init = {}) {
    this.body = body; this.status = init.status ?? 200; this.headers = init.headers instanceof Headers2 ? init.headers : new Headers2(init.headers || {});
  }
  get ok() { return this.status >= 200 && this.status < 300; }
  async json() { return JSON.parse(Buffer.from(this.body || '{}').toString()); }
  async text() { return Buffer.from(this.body || '').toString(); }
  clone() { return new Response2(this.body, { status: this.status, headers: Object.fromEntries(this.headers) }); }
  async arrayBuffer() { return Buffer.from(this.body || ''); }
}
globalThis.Headers = Headers2;
globalThis.Response = Response2;

let originHits = 0;
let uploadHits = 0;
let lastUploadHeaders = null;
let lastOriginUrl = null;
globalThis.fetch = async (input, init) => {
  const url = typeof input === 'string' ? input : input.url;
  lastOriginUrl = url;
  if (url.includes('b2_authorize_account')) {
    return new Response2(JSON.stringify({
      authorizationToken: 'tok', apiUrl: 'https://api005.backblazeb2.com', accountId: 'acc',
    }), { status: 200 });
  }
  if (url.includes('b2_get_download_authorization')) {
    return new Response2(JSON.stringify({ authorizationToken: 'dl', validDurationInSeconds: 3600 }), { status: 200 });
  }
  if (url.includes('b2_get_upload_url')) {
    return new Response2(JSON.stringify({ uploadUrl: 'https://upload005.backblazeb2.com', authorizationToken: 'up' }), { status: 200 });
  }
  if (url.includes('upload005.backblazeb2.com')) {
    uploadHits++;
    lastUploadHeaders = new Headers2(init?.headers || {});
    const body = init?.body;
    const size = body?.byteLength ?? body?.length ?? 0;
    return new Response2(JSON.stringify({ fileName: lastUploadHeaders.get('X-Bz-File-Name'), fileId: 'fid', contentLength: size }), { status: 200 });
  }
  originHits++;
  // emulate B2 honouring Range
  const range = init?.headers?.get?.('Range') || null;
  if (range) {
    const [, s, e] = /bytes=(\d+)-(\d+)/.exec(range) || [];
    const slice = AUDIO.subarray(Number(s), Number(e) + 1);
    return new Response2(slice, { status: 206, headers: { 'content-type': 'audio/mpeg', 'content-length': slice.length } });
  }
  const isCover = url.includes('/covers/');
  return new Response2(AUDIO, {
    status: 200,
    headers: { 'content-type': isCover ? 'image/webp' : 'audio/mpeg', 'content-length': AUDIO.length },
  });
};

const store = new Map();
globalThis.caches = {
  default: {
    async match(req) { return store.get(req.url) || undefined; },
    async put(req, res) { store.set(req.url, res); },
  },
};

/* ---- token helpers (same format as server/lib/b2.js) ---- */
function token(episodeId, ttlMs = 120000, secret = SECRET) {
  // production contract: { exp, path }
  const body = b64u(JSON.stringify({ exp: Math.floor((Date.now() + ttlMs) / 1000), path: `/${episodeId}.mp3` }));
  const sig = crypto.createHmac('sha256', secret).update(body).digest('base64')
    .replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  return `${body}.${sig}`;
}

const { default: worker } = await import('../cloudflare/worker-stream-auth.js');

const env = {
  ALLOWED_ORIGINS: ALLOWED_ORIGINS.join(','),
  STREAM_TOKEN_SECRET: SECRET,
  B2_ORIGIN_HOST: 'f005.backblazeb2.com',
  B2_BUCKET: 'bluefm-web-audio',
  B2_BUCKET_NAME: 'bluefm-web-audio',
  B2_KEY_ID: 'kid', B2_APP_KEY: 'app', B2_BUCKET_ID: 'bid',
  CACHE_TTL: '604800',
};
const ctx = { waitUntil: (p) => p };
const req = (path, headers = {}) =>
  new Request(`https://media.bluefm.live${path}`, { headers });
// Request shim for node < 22
class Request2 {
  constructor(url, init = {}) { this.url = url; this.method = init.method || 'GET'; this.headers = init.headers instanceof Headers2 ? init.headers : new Headers2(init.headers || {}); this.body = init.body ?? null; }
  async arrayBuffer() { return this.body ?? new ArrayBuffer(0); }
}

const cases = [];
const t = (name, fn) => cases.push([name, fn]);

t('W1. no token → 403', async () => {
  const r = await worker.fetch(new Request2('https://media.bluefm.live/last-metro-e1.mp3'), env, ctx);
  assert.equal(r.status, 401, 'unauthorised token → 401 (production contract)');
});

t('W2. bad signature → 403', async () => {
  const r = await worker.fetch(new Request2(`https://media.bluefm.live/last-metro-e1.mp3?t=${token('last-metro-e1').slice(0, -3)}zzz`), env, ctx);
  assert.equal(r.status, 401, 'unauthorised token → 401 (production contract)');
});

t('W3. expired token → 403', async () => {
  const r = await worker.fetch(new Request2(`https://media.bluefm.live/last-metro-e1.mp3?t=${token('last-metro-e1', -5000)}`), env, ctx);
  assert.equal(r.status, 401, 'unauthorised token → 401 (production contract)');
});

t('W4. token for another file → 403', async () => {
  const r = await worker.fetch(new Request2(`https://media.bluefm.live/monsoon-hearts-e1.mp3?t=${token('last-metro-e1')}`), env, ctx);
  assert.equal(r.status, 401, 'unauthorised token → 401 (production contract)');
});

t('W5. valid token → 200 from origin (MISS), then HIT without touching B2', async () => {
  originHits = 0;
  const url = `https://media.bluefm.live/last-metro-e1.mp3?t=${token('last-metro-e1')}`;
  const first = await worker.fetch(new Request2(url), env, ctx);
  assert.equal(first.status, 200);
  assert.equal(first.headers.get('x-cache-status'), 'MISS');
  assert.equal(first.headers.get('x-stream-provider'), 'cloudflare+b2');
  assert.equal(originHits, 1);

  const second = await worker.fetch(new Request2(url), env, ctx);
  assert.equal(second.status, 200);
  assert.equal(second.headers.get('x-cache-status'), 'HIT');
  assert.equal(originHits, 1, 'B2 must only be hit once');
});

t('W6. Range on a cached object → 206 slice, no origin hit', async () => {
  // ensure the object is warm first (order-independent)
  const base = `https://media.bluefm.live/last-metro-e1.mp3?t=${token('last-metro-e1')}`;
  await worker.fetch(new Request2(base), env, ctx);
  const before = originHits;
  const r = await worker.fetch(
    new Request2(base, { headers: { Range: 'bytes=0-1023' } }),
    env, ctx,
  );
  assert.equal(r.status, 206);
  assert.equal(r.headers.get('content-range'), `bytes 0-1023/${AUDIO.length}`);
  assert.equal(originHits, before, 'range served from edge cache');
});

t('W7. B2 origin is called with a bucket-scoped token, never the user token', async () => {
  assert.ok(lastOriginUrl.includes('/file/'), 'origin url well formed');
  // B2 auth is sent as a header by the worker (aapke original worker jaisa),
  // never as a query param carrying the user token
  assert.ok(!lastOriginUrl.includes('?t='), 'user token never reaches B2');
  assert.ok(!lastOriginUrl.includes('?t='), 'user token never reaches B2');
});

t('W8. path traversal refused', async () => {
  const r = await worker.fetch(new Request2(`https://media.bluefm.live/..%2fsecret.mp3?t=${token('x')}`), env, ctx);
  assert.equal(r.status, 400);
});

function uploadToken(key, { ttlMs = 120000, secret = SECRET, op = 'upload', maxBytes = 1024 * 1024, contentType = 'audio/mpeg' } = {}) {
  const body = b64u(JSON.stringify({ op, exp: Math.floor((Date.now() + ttlMs) / 1000), path: `/${key}`, maxBytes, contentType, uid: 'u_admin' }));
  const sig = crypto.createHmac('sha256', secret).update(body).digest('base64')
    .replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  return `${body}.${sig}`;
}

t('W9. public cover → 200 without a user token', async () => {
  const r = await worker.fetch(new Request2('https://media.bluefm.live/covers/last-metro.webp'), env, ctx);
  assert.equal(r.status, 200);
  assert.equal(r.headers.get('content-type'), 'image/webp');
});

t('W10. valid upload token → B2 upload with SHA-1 (not do_not_verify)', async () => {
  uploadHits = 0;
  const key = 'last-metro-e99.mp3';
  const r = await worker.fetch(new Request2('https://media.bluefm.live/upload', {
    method: 'POST',
    headers: { Authorization: `Bearer ${uploadToken(key)}`, 'X-File-Name': key, 'Content-Type': 'audio/mpeg' },
    body: AUDIO,
  }), env, ctx);
  assert.equal(r.status, 200);
  assert.equal(uploadHits, 1);
  const sha1 = lastUploadHeaders.get('X-Bz-Content-Sha1');
  assert.ok(sha1 && sha1 !== 'do_not_verify', 'real SHA-1 must be sent');
});

t('W11. upload without token → 401', async () => {
  const r = await worker.fetch(new Request2('https://media.bluefm.live/upload', {
    method: 'POST', headers: { 'X-File-Name': 'x.mp3', 'Content-Type': 'audio/mpeg' }, body: AUDIO,
  }), env, ctx);
  assert.equal(r.status, 401);
});

t('W12. upload token for another key → 401', async () => {
  const r = await worker.fetch(new Request2('https://media.bluefm.live/upload', {
    method: 'POST',
    headers: { Authorization: `Bearer ${uploadToken('other.mp3')}`, 'X-File-Name': 'last-metro-e99.mp3', 'Content-Type': 'audio/mpeg' },
    body: AUDIO,
  }), env, ctx);
  assert.equal(r.status, 401);
});

t('W13. stream token cannot be replayed as upload token → 401', async () => {
  const r = await worker.fetch(new Request2('https://media.bluefm.live/upload', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token('last-metro-e99')}`, 'X-File-Name': 'last-metro-e99.mp3', 'Content-Type': 'audio/mpeg' },
    body: AUDIO,
  }), env, ctx);
  assert.equal(r.status, 401);
});

t('W14. new domain + www + Vercel fallback pass upload preflight', async () => {
  for (const origin of ALLOWED_ORIGINS) {
    const r = await worker.fetch(new Request2('https://bluefm-stream.example.workers.dev/upload', {
      method: 'OPTIONS',
      headers: { Origin: origin, 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'authorization,content-type,x-file-name' },
    }), env, ctx);
    assert.equal(r.status, 204);
    assert.equal(r.headers.get('access-control-allow-origin'), origin);
    assert.match(r.headers.get('access-control-allow-headers'), /X-File-Name/);
    assert.match(r.headers.get('access-control-allow-headers'), /Authorization/);
  }
});

t('W15. look-alike domains do not receive a CORS grant', async () => {
  for (const origin of ['https://bluefm.live.example.com', 'https://notbluefm.live', 'https://evil.example']) {
    const r = await worker.fetch(new Request2('https://bluefm-stream.example.workers.dev/upload', {
      method: 'OPTIONS', headers: { Origin: origin, 'Access-Control-Request-Method': 'POST' },
    }), env, ctx);
    assert.equal(r.headers.get('access-control-allow-origin'), null);
  }
});

t('W16. authenticated cover upload from bluefm.live reaches B2 with CORS', async () => {
  uploadHits = 0;
  const key = 'covers/story-domain-test.webp';
  const origin = 'https://bluefm.live';
  const r = await worker.fetch(new Request2('https://bluefm-stream.example.workers.dev/upload', {
    method: 'POST',
    headers: { Origin: origin, Authorization: `Bearer ${uploadToken(key, { contentType: 'image/webp' })}`, 'X-File-Name': key, 'Content-Type': 'image/webp' },
    body: Buffer.from('domain-test-cover'),
  }), env, ctx);
  assert.equal(r.status, 200);
  assert.equal(r.headers.get('access-control-allow-origin'), origin);
  assert.equal(uploadHits, 1);
  assert.equal(lastUploadHeaders.get('X-Bz-File-Name'), key);
});

let pass = 0, fail = 0;
for (const [name, fn] of cases) {
  try { await fn(); console.log('ok  -', name); pass++; }
  catch (e) { console.log('FAIL-', name, '\n     ', e.message); fail++; }
}
console.log(`\n# tests ${cases.length}\n# pass ${pass}\n# fail ${fail}`);
process.exit(fail ? 1 : 0);
