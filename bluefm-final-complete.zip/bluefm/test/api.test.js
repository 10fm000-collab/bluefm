/**
 * BLUEFM API + security test suite (node:test, no extra dependencies).
 *
 * Covers the critical guarantees from the spec:
 *  1. signup / login / logout
 *  2. story browsing + search
 *  3. daily / weekly / monthly pass durations
 *  4. failed payment grants NO access
 *  5. duplicate webhook is idempotent (no double time)
 *  6. expired entitlements are rejected by the server
 *  7. independent entitlements per story
 *  8. audio URL cannot be fetched without a valid signed token
 *  9. signed URL cannot be reused for another episode
 * 10. admin routes reject non-admins (server-side)
 * 11. tampered session cookie is rejected
 *
 * Run against a throwaway DATA_DIR so real data is untouched:
 *   DATA_DIR=/tmp/bluefm-test PORT=8099 node server/index.js &
 *   BASE=http://localhost:8099 node --test test/
 */
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';

const BASE = process.env.BASE || 'http://localhost:8099';

const jar = () => ({ cookie: '' });

async function call(path, { method = 'GET', body, cookie, headers = {} } = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: {
      ...(body ? { 'content-type': 'application/json' } : {}),
      ...(cookie ? { cookie } : {}),
      ...headers,
    },
    body: body ? JSON.stringify(body) : undefined,
    redirect: 'manual',
  });
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch { data = text; }
  const setCookie = res.headers.getSetCookie?.() || [];
  return { status: res.status, data, setCookie, headers: res.headers };
}

function cookieFrom(res) {
  const raw = res.setCookie.find((c) => c.startsWith('bfm_session='));
  return raw ? raw.split(';')[0] : null;
}

const email = `test${Date.now()}@bluefm.test`;
const password = 'correct-horse-battery';
let userCookie = null;
let adminCookie = null;
let storySlug = null;
let storyId = null;
let episodes = [];

before(async () => {
  const home = await call('/api/home');
  assert.equal(home.status, 200, 'API must be reachable');
  const s = home.data.recentlyAdded[0];
  storySlug = s.slug;
  storyId = s.id;
  const detail = await call(`/api/stories/${storySlug}`);
  episodes = detail.data.episodes;

  const reg = await call('/api/auth/register', { method: 'POST', body: { name: 'Test Listener', email, password } });
  assert.equal(reg.status, 201);
  userCookie = cookieFrom(reg);

  const admin = await call('/api/auth/login', {
    method: 'POST',
    body: { email: process.env.ADMIN_EMAIL || 'admin@bluefm.app', password: process.env.ADMIN_PASSWORD || 'bluefm-admin-2026' },
  });
  assert.equal(admin.status, 200);
  adminCookie = cookieFrom(admin);
});

test('1. registration rejects weak passwords and duplicate emails', async () => {
  const weak = await call('/api/auth/register', { method: 'POST', body: { name: 'X Y', email: `w${Date.now()}@t.dev`, password: '123' } });
  assert.equal(weak.status, 400);

  const dup = await call('/api/auth/register', { method: 'POST', body: { name: 'Test Listener', email, password } });
  assert.equal(dup.status, 409);
});

test('2. login rejects bad credentials', async () => {
  const bad = await call('/api/auth/login', { method: 'POST', body: { email, password: 'wrong-password' } });
  assert.equal(bad.status, 401);
});

test('3. search returns real database results', async () => {
  const res = await call('/api/stories?q=metro');
  assert.equal(res.status, 200);
  assert.ok(res.data.total >= 1);
  assert.ok(res.data.stories.some((s) => /metro/i.test(s.title)));
});

test('4. anonymous playback is rejected', async () => {
  const res = await call('/api/playback/authorize', {
    method: 'POST', body: { storyId, episodeId: episodes[0].id },
  });
  assert.equal(res.status, 401);
});

test('5. locked story cannot be played', async () => {
  const res = await call('/api/playback/authorize', {
    method: 'POST', body: { storyId, episodeId: episodes[0].id }, cookie: userCookie,
  });
  assert.equal(res.status, 403);
  assert.equal(res.data.code, 'access_locked');
});

test('6. failed payment grants no access', async () => {
  const order = await call('/api/payments/checkout', { method: 'POST', body: { storyId, plan: 'daily' }, cookie: userCookie });
  assert.equal(order.status, 201);
  assert.equal(order.data.amount, 200, 'daily pass is ₹2 after the price update');

  const sim = await call('/api/payments/sandbox/simulate', {
    method: 'POST', body: { purchaseId: order.data.purchaseId, outcome: 'failure' }, cookie: userCookie,
  });
  assert.equal(sim.data.outcome, 'failure');

  const play = await call('/api/playback/authorize', {
    method: 'POST', body: { storyId, episodeId: episodes[0].id }, cookie: userCookie,
  });
  assert.equal(play.status, 403, 'failed payment must not unlock audio');

  const detail = await call(`/api/stories/${storySlug}`, { cookie: userCookie });
  assert.equal(detail.data.story.access.status, 'locked');
});

test('7. a forged signature is rejected', async () => {
  const order = await call('/api/payments/checkout', { method: 'POST', body: { storyId, plan: 'daily' }, cookie: userCookie });
  const verify = await call('/api/payments/verify', {
    method: 'POST',
    body: { purchaseId: order.data.purchaseId, orderId: order.data.orderId, paymentId: 'pay_fake', signature: 'a'.repeat(64) },
    cookie: userCookie,
  });
  assert.equal(verify.status, 400);
  assert.equal(verify.data.code, 'signature_invalid');

  const play = await call('/api/playback/authorize', {
    method: 'POST', body: { storyId, episodeId: episodes[0].id }, cookie: userCookie,
  });
  assert.equal(play.status, 403, 'a client claiming success must not unlock anything');
});

test('8. daily pass unlocks exactly 24h and plays audio', async () => {
  const order = await call('/api/payments/checkout', { method: 'POST', body: { storyId, plan: 'daily' }, cookie: userCookie });
  const sim = await call('/api/payments/sandbox/simulate', {
    method: 'POST', body: { purchaseId: order.data.purchaseId }, cookie: userCookie,
  });
  assert.equal(sim.data.outcome, 'success');

  const verify = await call('/api/payments/verify', {
    method: 'POST',
    body: {
      purchaseId: order.data.purchaseId, orderId: sim.data.orderId,
      paymentId: sim.data.paymentId, signature: sim.data.signature,
    },
    cookie: userCookie,
  });
  assert.equal(verify.status, 200);
  assert.equal(verify.data.access.status, 'active');

  const ms = Date.parse(verify.data.access.expiresAt) - Date.now();
  assert.ok(Math.abs(ms - 24 * 3600 * 1000) < 60_000, `expected ~24h, got ${ms}ms`);

  const auth = await call('/api/playback/authorize', {
    method: 'POST', body: { storyId, episodeId: episodes[0].id }, cookie: userCookie,
  });
  assert.equal(auth.status, 200);
  // Delivery is either the guarded local proxy or a short-lived B2 signed URL.
  assert.ok(
    /^\/api\/playback\/stream\//.test(auth.data.url) || /^https:\/\//.test(auth.data.url),
    `unexpected stream url: ${auth.data.url}`,
  );

  const delivery = auth.data.delivery;
  assert.ok(['proxy', 'b2', 'cloudflare'].includes(delivery), `delivery=${delivery}`);

  if (delivery === 'cloudflare') {
    // CDN hostname is a real Cloudflare zone URL; when the test environment
    // has no custom domain attached yet we assert the contract instead of
    // hitting the network: stable path, HMAC token, no B2 host leak.
    const u = new URL(auth.data.url);
    assert.ok(u.pathname.endsWith('.mp3'), 'stable object path for edge caching');
    assert.ok(u.searchParams.has('t'), 'edge token present');
    assert.ok(!auth.data.url.includes('backblazeb2.com'), 'B2 host must never reach the browser');
  } else {
    const isProxy = auth.data.url.startsWith('/');
    const streamUrl = isProxy ? `${BASE}${auth.data.url}` : auth.data.url;
    const stream = await fetch(streamUrl, { headers: { cookie: userCookie, range: 'bytes=0-1023' } });
    assert.equal(stream.status, 206, 'range requests supported');
    assert.equal(stream.headers.get('content-type'), 'audio/mpeg');
    if (isProxy) assert.equal(stream.headers.get('cache-control'), 'private, no-store');
    const bytes = Buffer.from(await stream.arrayBuffer());
    assert.ok(bytes.length > 0, 'audio bytes returned');
    assert.ok(bytes[0] === 0xff || bytes.toString('ascii', 0, 3) === 'ID3', 'looks like mp3');
  }
});

test('9. duplicate webhook does not stack time (idempotent)', async () => {
  const detail = await call(`/api/stories/${storySlug}`, { cookie: userCookie });
  const before = Date.parse(detail.data.story.access.expiresAt);

  // replay the same capture event through a fresh checkout twice
  const order = await call('/api/payments/checkout', { method: 'POST', body: { storyId, plan: 'daily' }, cookie: userCookie });
  const sim = await call('/api/payments/sandbox/simulate', {
    method: 'POST', body: { purchaseId: order.data.purchaseId, accelerate: true }, cookie: userCookie,
  });
  // second verify with the same purchase must not add another window
  const v1 = await call('/api/payments/verify', {
    method: 'POST',
    body: { purchaseId: order.data.purchaseId, orderId: sim.data.orderId, paymentId: sim.data.paymentId, signature: sim.data.signature, accelerate: true },
    cookie: userCookie,
  });
  const after1 = Date.parse(v1.data.access.expiresAt);
  const v2 = await call('/api/payments/verify', {
    method: 'POST',
    body: { purchaseId: order.data.purchaseId, orderId: sim.data.orderId, paymentId: sim.data.paymentId, signature: sim.data.signature, accelerate: true },
    cookie: userCookie,
  });
  assert.equal(v2.data.duplicate, true);
  const after2 = Date.parse(v2.data.access.expiresAt ?? v1.data.access.expiresAt);
  assert.equal(after2, after1, 'replaying verification must not extend access');
  assert.ok(after1 > before);
});

test('10. entitlements are independent per story', async () => {
  const list = await call('/api/stories?limit=48');
  const other = list.data.stories.find((s) => s.id !== storyId);
  const play = await call('/api/playback/authorize', {
    method: 'POST',
    body: { storyId: other.id, episodeId: (await call(`/api/stories/${other.slug}`)).data.episodes[0].id },
    cookie: userCookie,
  });
  assert.equal(play.status, 403, 'a pass for one story must not unlock another');
});

test('11. stream rejects missing and mismatched tokens', async (t) => {
  const noToken = await fetch(`${BASE}/api/playback/stream/${episodes[0].id}`);
  assert.equal(noToken.status, 403);

  const auth = await call('/api/playback/authorize', {
    method: 'POST', body: { storyId, episodeId: episodes[0].id }, cookie: userCookie,
  });
  if (!auth.data.url.startsWith('/')) {
    // B2 delivery: the signed URL is storage-side, but the proxy must still
    // refuse a token that belongs to a different episode.
    const forged = await fetch(`${BASE}/api/playback/stream/${episodes[1].id}?t=nonsense`);
    assert.equal(forged.status, 403);
    return;
  }
  const token = new URL(`${BASE}${auth.data.url}`).searchParams.get('t');
  const mismatched = await fetch(`${BASE}/api/playback/stream/${episodes[1].id}?t=${token}`);
  assert.equal(mismatched.status, 403, 'token is bound to one episode');
});

test('12. tampered session cookie is rejected', async () => {
  const tampered = `${userCookie.slice(0, -4)}AAAA`;
  const me = await call('/api/auth/me', { cookie: tampered });
  assert.equal(me.data.user, null);
});

test('13. non-admin cannot reach admin APIs', async () => {
  for (const path of ['/api/admin/stats', '/api/admin/payments', '/api/admin/stories', '/api/admin/users', '/api/admin/audit']) {
    const res = await call(path, { cookie: userCookie });
    assert.equal(res.status, 403, `${path} must be admin-only`);
  }
});

test('14. admin can read stats and transactions', async () => {
  const stats = await call('/api/admin/stats', { cookie: adminCookie });
  assert.equal(stats.status, 200);
  assert.ok(stats.data.totals.users >= 1);

  const payments = await call('/api/admin/payments', { cookie: adminCookie });
  assert.equal(payments.status, 200);
  assert.ok(Array.isArray(payments.data.payments));
});

test('14b. Hindi title keeps its text and gets a storage-safe ASCII story id', async () => {
  const title = 'हे परी, प्लीज़ मुझे अकेला छोड़ दो!';
  const created = await call('/api/admin/stories', {
    method: 'POST', body: { title, author: 'BLUE FM', genre: 'romance', language: 'hindi' }, cookie: adminCookie,
  });
  assert.equal(created.status, 201, JSON.stringify(created.data));
  assert.equal(created.data.story.title, title, 'never force the creator to rename a Hindi title');
  assert.match(created.data.story.id, /^[a-z0-9][a-z0-9-]*$/);
  assert.equal(created.data.story.slug, created.data.story.id);
  const removed = await call(`/api/admin/stories/${created.data.story.id}`, { method: 'DELETE', cookie: adminCookie });
  assert.equal(removed.status, 200);
});

test('15. progress sync validates access and clamps position', async () => {
  const ok = await call('/api/playback/progress', {
    method: 'PUT',
    body: { storyId, episodeId: episodes[0].id, position: 999999, duration: 30 },
    cookie: userCookie,
  });
  assert.equal(ok.status, 200);
  assert.ok(ok.data.progress.position <= ok.data.progress.duration);

  const locked = await call('/api/playback/progress', {
    method: 'PUT',
    body: { storyId: 'a-story-you-do-not-own', episodeId: 'x', position: 1 },
    cookie: userCookie,
  });
  assert.equal(locked.status, 404);
});

test('16. webhook rejects an unsigned request', async () => {
  const res = await fetch(`${BASE}/api/payments/webhooks/sandbox`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ event: 'payment.captured', payload: { payment: { entity: { id: 'pay_x', order_id: 'order_x' } } } }),
  });
  assert.equal(res.status, 400);
});

test('17. logout invalidates the session', async () => {
  const out = await call('/api/auth/logout', { method: 'POST', cookie: userCookie });
  assert.equal(out.status, 200);
  const me = await call('/api/auth/me', { cookie: userCookie });
  assert.equal(me.data.user, null);
});
