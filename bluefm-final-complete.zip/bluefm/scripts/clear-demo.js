#!/usr/bin/env node
/**
 * BLUEFM — safely remove the seeded DEMO catalogue.
 *
 *   node scripts/clear-demo.js --project=nodio-575bf            # dry run
 *   node scripts/clear-demo.js --apply --project=nodio-575bf    # actually delete
 *
 * What it removes (and ONLY this):
 *   • the 10 seeded demo stories + their episodes
 *   • listening history / progress / favorites attached to those demo stories
 *   • the seeded demo listener (u_demo_listener) + its demo purchase/entitlement
 *   • the matching demo MP3 objects in B2 (when B2_* env vars are present)
 *
 * What it NEVER touches:
 *   • real users, real purchases, real entitlements, admin accounts
 *   • any story you created yourself (ids outside the seed list)
 *
 * Requires Google ADC (gcloud auth application-default login) or
 * GOOGLE_APPLICATION_CREDENTIALS, same as make-admin / migrate scripts.
 */
import { STORIES } from '../server/catalog.js';

const argv = process.argv.slice(2);
const APPLY = argv.includes('--apply');
const FORCE = argv.includes('--force');
const PROJECT_ID = (argv.find((a) => a.startsWith('--project=')) || '').split('=')[1]
  || process.env.FIREBASE_PROJECT_ID
  || process.env.GCLOUD_PROJECT
  || 'nodio-575bf';
const PREFIX = process.env.FIRESTORE_PREFIX || '';
const col = (t) => (PREFIX ? `${PREFIX}${t}` : t);

const DEMO_IDS = STORIES.map((s) => s.id);
const DEMO_USER = 'u_demo_listener';
const log = (...a) => console.log(APPLY ? '[apply]' : '[dry-run]', ...a);

const admin = (await import('firebase-admin')).default;
if (!admin.apps.length) {
  admin.initializeApp({ credential: admin.credential.applicationDefault(), projectId: PROJECT_ID });
}
const db = admin.firestore();

async function deleteDocs(docs, label) {
  if (!docs.length) { log(`${label}: 0`); return 0; }
  log(`${label}: ${docs.length}${APPLY ? '' : ' (would delete)'}`);
  if (!APPLY) return docs.length;
  for (let i = 0; i < docs.length; i += 400) {
    const batch = db.batch();
    for (const d of docs.slice(i, i + 400)) batch.delete(d.ref);
    await batch.commit();
  }
  return docs.length;
}

async function main() {
  log(`project=${PROJECT_ID} prefix=${PREFIX || '(none)'}`);
  log(`demo story ids: ${DEMO_IDS.join(', ')}`);

  // Episodes belonging to demo stories
  const epsSnap = await db.collection(col('episodes')).get();
  const demoEps = epsSnap.docs.filter((d) => DEMO_IDS.includes(d.data().storyId));
  const audioKeys = demoEps.map((d) => d.data().audioKey).filter(Boolean);

  // Stories
  const storySnap = await db.collection(col('stories')).get();
  const demoStories = storySnap.docs.filter((d) => DEMO_IDS.includes(d.id));

  // History / progress / favorites tied to demo stories OR the demo user
  const inDemo = (row) => DEMO_IDS.includes(row.storyId) || row.userId === DEMO_USER;
  const histSnap = await db.collection(col('history')).get();
  const hist = histSnap.docs.filter((d) => String(d.id).startsWith('hist_seed_') || inDemo(d.data()));
  const progSnap = await db.collection(col('progress')).get();
  const prog = progSnap.docs.filter((d) => inDemo(d.data()));
  const favSnap = await db.collection(col('favorites')).get();
  const fav = favSnap.docs.filter((d) => inDemo(d.data()));

  const purSnap = await db.collection(col('purchases')).get();

  // Safety: never delete a demo story that a REAL user has paid for.
  const realPaid = purSnap.docs.filter((d) => d.data().status === 'paid'
    && d.data().userId !== DEMO_USER && DEMO_IDS.includes(d.data().storyId));
  if (realPaid.length && !FORCE) {
    console.error(`[clear-demo] ABORT: ${realPaid.length} real paid purchase(s) reference demo stories.`);
    console.error('[clear-demo] Archive those stories instead, or re-run with --force if you are sure.');
    process.exit(2);
  }

  // Demo user + its purchases / entitlements
  const userSnap = await db.collection(col('users')).doc(DEMO_USER).get();
  const demoUser = userSnap.exists ? [userSnap] : [];
  const pur = purSnap.docs.filter((d) => d.data().userId === DEMO_USER);
  const entSnap = await db.collection(col('entitlements')).get();
  const ent = entSnap.docs.filter((d) => d.data().userId === DEMO_USER);

  await deleteDocs(demoEps, 'episodes');
  await deleteDocs(demoStories, 'stories');
  await deleteDocs(hist, 'history');
  await deleteDocs(prog, 'progress');
  await deleteDocs(fav, 'favorites');
  await deleteDocs(pur, 'demo purchases');
  await deleteDocs(ent, 'demo entitlements');
  await deleteDocs(demoUser, 'demo user');

  // B2 audio cleanup (optional — needs B2 env vars locally)
  const { b2Configured, deleteFile } = await import('../server/lib/b2.js');
  if (!b2Configured()) {
    log('B2 not configured locally — skipped audio object cleanup. Set B2_KEY_ID/B2_APP_KEY/B2_BUCKET_ID to also delete demo MP3s.');
  } else {
    let removed = 0;
    for (const key of audioKeys) {
      if (APPLY) removed += await deleteFile(key);
      else removed += 1;
    }
    log(`B2 audio objects: ${removed}${APPLY ? '' : ' (would delete)'}`);
  }

  log(APPLY ? 'Done. Demo catalogue removed.' : 'Dry run complete. Re-run with --apply to delete.');
}

main().catch((err) => { console.error(err); process.exit(1); });
