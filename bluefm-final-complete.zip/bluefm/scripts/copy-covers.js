#!/usr/bin/env node
/**
 * Ensures cover art ships with the static build.
 *
 * WHY: vite's publicDir is <root>/public, but the cover art lives in
 * client/public/media/covers. Without this copy the production build has NO
 * /media/covers/* files, so every hero banner + story card renders broken on
 * Vercel (the API returns cover URLs, but the static host 404s them).
 *
 * Runs automatically as `prebuild` (npm runs prebuild before build).
 */
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve(import.meta.dirname, '..');
const SRC = path.join(ROOT, 'client', 'public', 'media');
const DEST = path.join(ROOT, 'public', 'media');

function copyDir(from, to) {
  fs.mkdirSync(to, { recursive: true });
  let n = 0;
  for (const entry of fs.readdirSync(from, { withFileTypes: true })) {
    const s = path.join(from, entry.name);
    const d = path.join(to, entry.name);
    if (entry.isDirectory()) n += copyDir(s, d);
    else if (entry.isFile()) { fs.copyFileSync(s, d); n++; }
  }
  return n;
}

if (!fs.existsSync(SRC)) {
  console.warn('[copy-covers] no client/public/media found — skipping');
  process.exit(0);
}
const n = copyDir(SRC, DEST);
console.log(`[copy-covers] ${n} media files → public/media (shipped with the build)`);
