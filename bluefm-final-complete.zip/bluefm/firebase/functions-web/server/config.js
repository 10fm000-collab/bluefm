import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const ROOT = path.resolve(import.meta.dirname, '..');

/** Tiny .env loader (no dependency). Values already in process.env win. */
function loadEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const raw of fs.readFileSync(file, 'utf8').split('\n')) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq === -1) continue;
    const key = line.slice(0, eq).trim();
    let val = line.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = val;
  }
}
loadEnv(path.join(ROOT, '.env'));

/** Strip BOM / whitespace / wrapping quotes that break gateway auth with a 401. */
function cleanSecret(v) {
  return String(v || '').replace(/^/, '').trim().replace(/^(['"])([\s\S]*)\1$/, '$2').trim();
}
function normaliseCashfreeEnv(v) {
  const s = cleanSecret(v).toLowerCase();
  if (['production', 'prod', 'live'].includes(s)) return 'production';
  return 'sandbox';
}

const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(ROOT, 'data'));
const isProd = process.env.NODE_ENV === 'production';

/** Generated-once secrets, persisted outside the repo snapshot scope by .gitignore. */
function persistentSecret(name, bytes = 32) {
  const file = path.join(DATA_DIR, '.secrets.json');
  let store = {};
  try { store = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { /* first run */ }
  if (!store[name]) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    store[name] = crypto.randomBytes(bytes).toString('hex');
    fs.writeFileSync(file, JSON.stringify(store, null, 2), { mode: 0o600 });
  }
  return store[name];
}

const envSecret = (key, fallbackName) =>
  process.env[key] || persistentSecret(fallbackName);

export const config = {
  root: ROOT,
  isProd,
  port: Number(process.env.PORT || 8080),
  appUrl: (process.env.APP_URL || `http://localhost:${process.env.PORT || 8080}`).replace(/\/$/, ''),
  dataDir: DATA_DIR,
  mediaDir: path.join(DATA_DIR, 'media'),
  coversDir: path.join(DATA_DIR, 'media', 'covers'),
  audioDir: path.join(DATA_DIR, 'media', 'audio'),
  clientDist: path.join(ROOT, 'dist', 'client'),
  session: {
    secret: envSecret('SESSION_SECRET', 'session'),
    cookieName: 'bfm_session',
    ttlDays: 30,
  },
  audio: {
    signingSecret: envSecret('AUDIO_SIGNING_SECRET', 'audio'),
    tokenTtlSeconds: Number(process.env.AUDIO_TOKEN_TTL || 600),
    storageDriver: process.env.AUDIO_STORAGE || 'local', // local | b2
    publicBase: process.env.AUDIO_PUBLIC_BASE || '',
    // Cloudflare edge in front of the B2 bucket, e.g. https://media.bluefm.live
    // Set this and delivery switches to Cloudflare (free B2 egress).
    cdnBase: (process.env.B2_DOWNLOAD_URL || '').replace(/\/$/, ''),
    edgeSecret: process.env.STREAM_TOKEN_SECRET || envSecret('AUDIO_SIGNING_SECRET', 'audio'),
    b2: {
      keyId: process.env.B2_KEY_ID || '',
      appKey: process.env.B2_APP_KEY || '',
      bucketId: process.env.B2_BUCKET_ID || '',
      bucketName: process.env.B2_BUCKET_NAME || '',
      downloadUrl: process.env.B2_DOWNLOAD_URL || '',
    },
  },
  payment: {
    provider: process.env.PAYMENT_PROVIDER || 'sandbox', // sandbox | cashfree | razorpay
    cashfree: {
      clientId: cleanSecret(process.env.CASHFREE_CLIENT_ID),
      clientSecret: cleanSecret(process.env.CASHFREE_CLIENT_SECRET),
      env: normaliseCashfreeEnv(process.env.CASHFREE_ENV), // sandbox | production
    },
    currency: 'INR',
    razorpay: {
      keyId: process.env.RAZORPAY_KEY_ID || '',
      keySecret: process.env.RAZORPAY_KEY_SECRET || '',
      webhookSecret: process.env.RAZORPAY_WEBHOOK_SECRET || '',
    },
  },
  firebase: {
    projectId: process.env.FIREBASE_PROJECT_ID || '',
    usedForAuth: process.env.AUTH_MODE === 'firebase',
  },
  admin: {
    bootstrapEmail: process.env.ADMIN_EMAIL || 'admin@bluefm.app',
    bootstrapPassword: process.env.ADMIN_PASSWORD || '',
  },
  // NOTE: the brief said "price double kardo" -> ₹1/₹7/₹30 became ₹2/₹14/₹60.
  // Amounts are integer paise (server-side source of truth; the client can never
  // send an amount).
  plans: {
    daily:   { id: 'daily',   label: 'Daily Pass',   amount: 200,  hours: 24,  badge: null },
    weekly:  { id: 'weekly',  label: 'Weekly Pass',  amount: 1400, hours: 168, badge: 'Popular' },
    monthly: { id: 'monthly', label: 'Monthly Pass', amount: 6000, hours: 720, badge: 'Best value' },
  },
  limits: {
    // token-bucket rate limiting for sensitive endpoints
    login:     { capacity: 10, refillPerMin: 10 },
    register:  { capacity: 6,  refillPerMin: 6 },
    checkout:  { capacity: 20, refillPerMin: 20 },
    playback:  { capacity: 120, refillPerMin: 60 },
    write:     { capacity: 120, refillPerMin: 120 },
  },
};

// Cloud Functions / Vercel have no persistent disk — never let mkdir kill boot.
for (const dir of [config.dataDir, config.mediaDir, config.coversDir, config.audioDir]) {
  try { fs.mkdirSync(dir, { recursive: true }); } catch { /* read-only fs in serverless */ }
}

/* Startup diagnostics — say the true state instead of guessing a provider. */
if (config.isProd && config.payment.provider === 'sandbox') {
  console.warn(
    '[BLUEFM] WARNING: PAYMENT_PROVIDER=sandbox — no real money can be charged. ' +
    'Set PAYMENT_PROVIDER=cashfree with CASHFREE_CLIENT_ID / CASHFREE_CLIENT_SECRET before going live.',
  );
}
if (config.payment.provider === 'cashfree' && !config.payment.cashfree.clientId) {
  console.warn('[BLUEFM] WARNING: CASHFREE_CLIENT_ID is empty — checkout will fail until it is set.');
}
if (config.payment.provider === 'cashfree' && (config.payment.cashfree.env || 'sandbox') === 'sandbox' && config.isProd) {
  console.warn('[BLUEFM] PAYMENT_PROVIDER=cashfree in SANDBOX mode — test cards only, no real payments.');
}
if (config.payment.provider === 'cashfree') {
  // Safe diagnostic: show WHICH endpoint + key fingerprint is loaded, never the
  // secret itself. Lets us confirm env/keys without guessing from a bare 401.
  const cf = config.payment.cashfree;
  const fp = (s) => (s ? `${s.slice(0, 4)}…${s.slice(-4)} (len ${s.length})` : 'MISSING');
  // The secret's environment marker is the single most useful 401 clue and is
  // NOT sensitive: Cashfree prod secrets contain "_prod_", sandbox "_test_".
  const kind = /_prod_|_production_|^cfsk_ma_prod/i.test(cf.clientSecret) ? 'PRODUCTION'
    : /_test_|^cfsk_ma_test/i.test(cf.clientSecret) ? 'SANDBOX' : 'unknown';
  const endpoint = cf.env === 'production' ? 'https://api.cashfree.com/pg' : 'https://sandbox.cashfree.com/pg';
  const mismatch = (cf.env === 'production' && kind === 'SANDBOX') || (cf.env === 'sandbox' && kind === 'PRODUCTION');
  console.log(`[BLUEFM] Cashfree diag: env=${cf.env} endpoint=${endpoint} clientId=${fp(cf.clientId)} secret=${fp(cf.clientSecret)} secretLooks=${kind}${mismatch ? ' ⚠️ KEY/ENV MISMATCH — yahi 401 ka reason hai' : ''}`);
}
