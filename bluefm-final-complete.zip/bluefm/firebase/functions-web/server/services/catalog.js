import { db } from '../db.js';
import { getEntitlement, isActive, msRemaining } from '../lib/access.js';
import { config } from '../config.js';

export function episodeOrder(storyId) {
  return db.episodes
    .where('storyId', storyId)
    .filter((e) => e.status === 'published')
    .sort((a, b) => a.number - b.number);
}

export function coverUrl(story, size = '') {
  if (!story) return '';
  // Remote covers live in B2 and are delivered by the Cloudflare Worker under
  // the public `covers/` prefix. Static/demo covers keep the build-time path.
  const ck = String(story.coverKey || '');
  if (ck.startsWith('covers/') && config.audio.cdnBase) {
    const base = ck.replace(/\.webp$/, '');
    return `${config.audio.cdnBase}/${base}${size}.webp`;
  }
  return `/media/covers/${story.id}${size}.webp`;
}

/** Public story shape — never includes audio URLs. */
export function publicStory(story, { access } = {}) {
  if (!story) return null;
  return {
    id: story.id,
    slug: story.slug,
    title: story.title,
    author: story.author,
    narrator: story.narrator,
    tagline: story.tagline,
    synopsis: story.synopsis,
    description: story.description,
    genre: story.genre,
    language: story.language,
    tags: story.tags,
    cover: coverUrl(story),
    cover2x: coverUrl(story, '@2x'),
    thumb: coverUrl(story, '-thumb'),
    lqip: story.lqip,
    rating: story.rating,
    plays: story.plays,
    episodeCount: story.episodeCount,
    totalDuration: story.totalDuration,
    publishedAt: story.publishedAt,
    featuredRank: story.featuredRank,
    trending: Boolean(story.trending),
    isNew: Boolean(story.isNew),
    status: story.status,
    access: access || { status: 'locked' },
  };
}

export function accessSummaryFor(userId, storyId) {
  const ent = getEntitlement(userId, storyId);
  if (!ent) return { status: 'locked' };
  if (!isActive(ent)) {
    return { status: 'expired', plan: ent.plan, expiresAt: ent.expiresAt, purchasedAt: ent.startsAt };
  }
  return {
    status: 'active',
    plan: ent.plan,
    expiresAt: ent.expiresAt,
    purchasedAt: ent.startsAt,
    msRemaining: msRemaining(ent),
    renewalCount: ent.renewalCount || 0,
  };
}

export function publicEpisode(ep, { unlocked, progress } = {}) {
  return {
    id: ep.id,
    storyId: ep.storyId,
    number: ep.number,
    title: ep.title,
    description: ep.description,
    duration: ep.duration,
    narrator: ep.narrator,
    publishedAt: ep.publishedAt,
    status: ep.status,
    unlocked: Boolean(unlocked),
    // Audio is only reachable through the signed /api/playback endpoint.
    progress: progress || null,
  };
}

export const plansPublic = () =>
  Object.values(config.plans).map((p) => ({
    id: p.id,
    label: p.label,
    amount: p.amount,
    currency: config.payment.currency,
    hours: p.hours,
    badge: p.badge,
  }));

export function progressFor(userId, storyId) {
  const map = new Map();
  if (!userId) return map;
  for (const p of db.progress.where('userId', userId)) {
    if (p.storyId === storyId) map.set(p.episodeId, p);
  }
  return map;
}

export function storyStats() {
  const stories = db.stories.all().filter((s) => s.status === 'published');
  const purchases = db.purchases.all().filter((p) => p.status === 'paid');
  const byStory = new Map();
  for (const p of purchases) byStory.set(p.storyId, (byStory.get(p.storyId) || 0) + 1);
  return stories
    .map((s) => ({ ...publicStory(s), purchases: byStory.get(s.id) || 0 }))
    .sort((a, b) => b.purchases - a.purchases);
}

/** Alias kept for readability in route modules. */
export const planPublic = plansPublic;
