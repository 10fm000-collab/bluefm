import { config } from '../config.js';
import { db } from '../db.js';
import { provider, planDurationMsFor } from '../payments/provider.js';
import { getEntitlement } from '../lib/access.js';
import { iso, serverNow } from '../lib/time.js';
import { uid } from '../lib/crypto.js';

export class PaymentError extends Error {
  constructor(message, status = 400, code = 'payment_error') {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export function plansForStory(story) {
  return Object.values(config.plans).map((p) => ({
    id: p.id,
    label: p.label,
    amount: p.amount,
    currency: config.payment.currency,
    hours: p.hours,
    badge: p.badge,
  }));
}

/** Step 1 — create a provider order. Nothing is unlocked here. */
export async function createOrder({ user, story, planId }) {
  const plan = config.plans[planId];
  if (!plan) throw new PaymentError('Unknown plan.', 400, 'bad_plan');
  if (!story || story.status !== 'published') throw new PaymentError('Story not available.', 404, 'story_missing');

  const p = provider();
  // Cashfree requires a real, reachable customer phone. Never send a dummy
  // number to the gateway — it breaks OTP/UPI collect and production KYC.
  const phone = String(user.phone || process.env.DEFAULT_CUSTOMER_PHONE || '').replace(/\D/g, '');
  if (p.id === 'cashfree' && !/^[6-9]\d{9}$/.test(phone)) {
    throw new PaymentError('A valid 10-digit mobile number is required for Cashfree payments.', 400, 'phone_required');
  }
  const purchaseId = uid('pur_');
  const receipt = `bluefm_${purchaseId}`;
  const order = await p.createOrder({
    amount: plan.amount,
    currency: config.payment.currency,
    receipt,
    notes: {
      storyId: story.id,
      plan: plan.id,
      userId: user.id,
      email: user.email || '',
      phone,
    },
  });

  const now = iso();
  db.purchases.set(purchaseId, {
    id: purchaseId,
    userId: user.id,
    storyId: story.id,
    plan: plan.id,
    amount: plan.amount,
    currency: config.payment.currency,
    status: 'created',
    provider: p.id,
    providerOrderId: order.orderId,
    providerPaymentId: null,
    receipt,
    createdAt: now,
    updatedAt: now,
    paidAt: null,
    verifiedAt: null,
    signatureVerified: false,
    webhookVerified: false,
    testAccelerated: false,
    failureReason: null,
  });

  return {
    purchaseId,
    orderId: order.orderId,
    amount: plan.amount,
    currency: config.payment.currency,
    plan: plan.id,
    storyId: story.id,
    provider: p.id,
    checkout: order.checkout,
    testMode: p.id === 'sandbox',
  };
}

/**
 * Idempotent settlement. Safe to call from both the client-verify endpoint and
 * the webhook — whichever arrives first wins, the second becomes a no-op.
 */
export function settlePurchase({ purchaseId, paymentId, source, accelerate }) {
  const purchase = db.purchases.get(purchaseId);
  if (!purchase) throw new PaymentError('Unknown order.', 404, 'order_missing');

  // Idempotency guard: a paid purchase never grants a second entitlement.
  if (purchase.status === 'paid') {
    const ent = getEntitlement(purchase.userId, purchase.storyId);
    return { purchase, entitlement: ent, duplicate: true };
  }

  const plan = config.plans[purchase.plan];
  const nowMs = serverNow();
  const current = getEntitlement(purchase.userId, purchase.storyId);
  // A renewal extends from the existing expiry ONLY when the live entitlement
  // was granted by a DIFFERENT purchase. Re-processing the same order (client
  // verify vs. webhook racing) must never stack time.
  const isRenewal = Boolean(current && current.purchaseId !== purchase.id);
  const activeUntil =
    isRenewal && current.status === 'active' ? Date.parse(current.expiresAt) : null;

  const windowMs = planDurationMsFor(
    { provider: purchase.provider, testAccelerated: Boolean(accelerate) },
    plan.hours,
  );
  // Renewal policy: extend from the current expiry when access is still live.
  const base = activeUntil && activeUntil > nowMs ? activeUntil : nowMs;
  const expiresAt = base + windowMs;

  const patch = {
    status: 'paid',
    providerPaymentId: paymentId || purchase.providerPaymentId || null,
    paidAt: purchase.paidAt || iso(nowMs),
    verifiedAt: iso(nowMs),
    updatedAt: iso(nowMs),
    signatureVerified: source === 'client_verify' || purchase.signatureVerified,
    webhookVerified: source === 'webhook' || purchase.webhookVerified,
    testAccelerated: Boolean(accelerate) || purchase.testAccelerated,
  };
  const updated = db.purchases.patch(purchaseId, patch);

  const entId = `ent_${purchase.userId}_${purchase.storyId}`;
  const entitlement = db.entitlements.set(entId, {
    id: entId,
    userId: purchase.userId,
    storyId: purchase.storyId,
    purchaseId,
    plan: purchase.plan,
    amount: purchase.amount,
    currency: purchase.currency,
    startsAt: iso(nowMs),
    expiresAt: iso(expiresAt),
    status: 'active',
    createdAt: current?.createdAt || iso(nowMs),
    updatedAt: iso(nowMs),
    lastVerifiedAt: iso(nowMs),
    renewalCount: isRenewal ? (current.renewalCount || 0) + 1 : 0,
    accelerated: Boolean(accelerate),
  });

  db.audit.set(uid('aud_'), {
    id: uid('aud_'),
    actorId: purchase.userId,
    actorEmail: db.users.get(purchase.userId)?.email || null,
    action: 'entitlement.granted',
    target: entId,
    meta: { storyId: purchase.storyId, plan: purchase.plan, source, purchaseId },
    at: iso(nowMs),
  });

  return { purchase: updated, entitlement, duplicate: false };
}

export function failPurchase(purchaseId, reason) {
  const purchase = db.purchases.get(purchaseId);
  if (!purchase || purchase.status === 'paid') return purchase;
  return db.purchases.patch(purchaseId, {
    status: 'failed',
    failureReason: reason || 'payment_failed',
    updatedAt: iso(),
  });
}

export function findPurchaseByOrder(orderId) {
  return db.purchases.findOne((p) => p.providerOrderId === orderId);
}

/** Webhook handler — verified, de-duplicated, idempotent. */
export function processWebhook({ eventId, payload }) {
  if (!eventId) throw new PaymentError('Missing event id.', 400, 'missing_event');
  const existing = db.webhookEvents.get(eventId);
  if (existing) return { duplicate: true, event: existing };

  /* Normalise both gateway shapes into one internal event:
   *   Razorpay : payload.event = 'payment.captured', payload.payment.entity.order_id
   *   Cashfree : type = 'PAYMENT_SUCCESS_WEBHOOK', data.order.order_id,
   *              data.payment.payment_status = 'SUCCESS'
   */
  const cfOrder = payload?.data?.order;
  const cfPayment = payload?.data?.payment;
  const isCashfreeShape = Boolean(cfOrder?.order_id || cfPayment?.cf_payment_id);

  const type = isCashfreeShape
    ? (String(cfPayment?.payment_status || '').toUpperCase() === 'SUCCESS'
      ? 'payment.captured'
      : String(payload?.type || '').toUpperCase().includes('FAILED')
        ? 'payment.failed'
        : payload?.type)
    : payload.event;

  const payment = isCashfreeShape
    ? {
      order_id: cfOrder?.order_id,
      id: cfPayment?.cf_payment_id != null ? String(cfPayment.cf_payment_id) : null,
      error_description: cfPayment?.payment_message || 'payment_failed',
      notes: {},
    }
    : payload?.payload?.payment?.entity;

  const refund = isCashfreeShape ? null : payload?.payload?.refund?.entity;
  const orderId = payment?.order_id || refund?.payment_id || null;

  const record = {
    id: eventId,
    type,
    receivedAt: iso(),
    processedAt: null,
    result: 'pending',
    orderId,
    paymentId: payment?.id || null,
    gateway: isCashfreeShape ? 'cashfree' : 'razorpay',
  };

  let entitlement = null;

  try {
    if (type === 'payment.captured' || type === 'order.paid') {
      const purchase = payment?.order_id
        ? findPurchaseByOrder(payment.order_id)
        : findPurchaseByOrder(orderId);
      if (!purchase) throw new PaymentError('No matching order for webhook.', 404, 'order_missing');
      const res = settlePurchase({
        purchaseId: purchase.id,
        paymentId: payment?.id,
        source: 'webhook',
        accelerate: Boolean(payment?.notes?.bluefm_test_accelerated),
      });
      entitlement = res.entitlement;
      record.result = res.duplicate ? 'duplicate_noop' : 'entitlement_granted';
    } else if (type === 'payment.failed') {
      const purchase = findPurchaseByOrder(payment?.order_id);
      if (purchase) failPurchase(purchase.id, payment?.error_description || 'payment_failed');
      record.result = 'marked_failed';
    } else if (type === 'refund.processed' || type === 'refund.created') {
      const purchase =
        db.purchases.findOne((p) => p.providerPaymentId && p.providerPaymentId === refund?.payment_id) ||
        findPurchaseByOrder(orderId);
      if (purchase) {
        db.purchases.patch(purchase.id, { status: 'refunded', updatedAt: iso() });
        // A refund revokes access immediately — access is not a free ride.
        const ent = getEntitlement(purchase.userId, purchase.storyId);
        if (ent && ent.purchaseId === purchase.id) {
          db.entitlements.patch(ent.id, { status: 'revoked', updatedAt: iso() });
        }
      }
      record.result = 'refund_revoked';
    } else {
      record.result = 'ignored';
    }
  } catch (err) {
    record.result = `error: ${err.message}`;
    db.webhookEvents.set(eventId, { ...record, processedAt: iso() });
    throw err;
  }

  db.webhookEvents.set(eventId, { ...record, processedAt: iso() });
  return { duplicate: false, event: record, entitlement };
}
