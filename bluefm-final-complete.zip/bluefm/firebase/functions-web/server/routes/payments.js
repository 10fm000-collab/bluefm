import { Router } from 'express';
import { db } from '../db.js';
import { config } from '../config.js';
import { requireAuth } from '../lib/auth.js';
import { rateLimit } from '../lib/rateLimit.js';
import {
  createOrder, settlePurchase, processWebhook, findPurchaseByOrder, PaymentError,
} from '../services/payments.js';
import { provider } from '../payments/provider.js';
import { accessSummaryFor } from '../services/catalog.js';
import { iso, serverNow } from '../lib/time.js';

const router = Router();

router.get('/plans', (_req, res) => {
  res.json({ plans: Object.values(config.plans), provider: config.payment.provider });
});

/** Step 1 — create order (no access granted). */
router.post('/checkout', requireAuth, rateLimit('checkout', config.limits.checkout), async (req, res, next) => {
  try {
    const { storyId, plan, phone } = req.body || {};
    const story = db.stories.get(String(storyId || ''));
    // Cashfree needs a reachable Indian mobile number. Normalise +91 / spaces
    // and persist it on the account so the customer only types it once.
    const cleanPhone = String(phone || req.user.phone || '')
      .replace(/[\s-]/g, '').replace(/^\+91/, '').replace(/^0+/, '');
    if (provider().id === 'cashfree' && !/^[6-9]\d{9}$/.test(cleanPhone)) {
      throw new PaymentError('Please enter a valid 10-digit mobile number for payment.', 400, 'phone_required');
    }
    if (cleanPhone && cleanPhone !== req.user.phone) {
      req.user.phone = cleanPhone;
      db.users.patch(req.user.id, { phone: cleanPhone, updatedAt: iso() });
    }
    const order = await createOrder({ user: req.user, story, planId: plan });
    res.status(201).json(order);
  } catch (err) {
    if (err instanceof PaymentError) return res.status(err.status).json({ error: err.message, code: err.code });
    next(err);
  }
});

/**
 * Step 2 (client path) — verify signature server-side, then settle.
 * A frontend "success" callback alone can never unlock anything.
 */
router.post('/verify', requireAuth, rateLimit('checkout', config.limits.checkout), async (req, res, next) => {
  try {
    const { purchaseId, orderId, paymentId, signature, accelerate } = req.body || {};
    // The Cashfree return page only knows the gateway order_id, so allow
    // lookup by either our purchaseId or the provider order id.
    const purchase = db.purchases.get(String(purchaseId || ''))
      || (orderId ? findPurchaseByOrder(String(orderId)) : null);
    if (!purchase) throw new PaymentError('Unknown order.', 404, 'order_missing');
    if (purchase.userId !== req.user.id) throw new PaymentError('This order belongs to another account.', 403, 'forbidden');

    const p = provider();
    // Cashfree: no client-side signature. The ONLY trusted check is a
    // server-to-server order lookup (order_status === "PAID").
    const verdict = p.id === 'cashfree'
      ? await p.verifyPayment({ orderId: orderId || purchase.providerOrderId })
      : await p.verifyPayment({ orderId: orderId || purchase.providerOrderId, paymentId, signature });
    if (!verdict.ok) {
      // Cashfree can redirect the customer back before the gateway marks the
      // order PAID. Treat that as pending (retryable), not a failed payment.
      const pending = p.id === 'cashfree' && String(verdict.reason || '').startsWith('order_status_');
      if (pending) {
        return res.status(402).json({
          error: 'Payment is still being confirmed. Please wait a moment.',
          code: 'payment_pending',
          reason: verdict.reason,
        });
      }
      db.purchases.patch(purchase.id, {
        status: 'failed',
        failureReason: `signature_${verdict.reason}`,
        signatureVerified: false,
        updatedAt: iso(),
      });
      db.audit.set(purchase.id + '_fail', {
        id: purchase.id + '_fail', actorId: req.user.id, actorEmail: req.user.email,
        action: 'payment.signature_rejected', target: purchase.id,
        meta: { reason: verdict.reason, provider: p.id }, at: iso(),
      });
      return res.status(400).json({ error: 'Payment could not be verified. No access was granted.', code: 'signature_invalid' });
    }

    const { purchase: updated, entitlement, duplicate } = settlePurchase({
      purchaseId: purchase.id,
      paymentId,
      source: 'client_verify',
      accelerate: Boolean(accelerate),
    });

    res.json({
      ok: true,
      duplicate,
      purchase: {
        id: updated.id, status: updated.status, amount: updated.amount,
        currency: updated.currency, plan: updated.plan, storyId: updated.storyId,
      },
      access: accessSummaryFor(req.user.id, updated.storyId),
      storySlug: db.stories.get(updated.storyId)?.slug || null,
      expiresAt: entitlement?.expiresAt,
    });
  } catch (err) {
    if (err instanceof PaymentError) return res.status(err.status).json({ error: err.message, code: err.code });
    next(err);
  }
});

/** Sandbox-only: simulate the gateway callback (signed, so verification is real). */
router.post('/sandbox/simulate', requireAuth, rateLimit('checkout', config.limits.checkout), async (req, res) => {
  if (config.payment.provider !== 'sandbox') {
    return res.status(404).json({ error: 'Sandbox simulation is disabled for the configured provider.' });
  }
  const { purchaseId, outcome = 'success' } = req.body || {};
  const purchase = db.purchases.get(String(purchaseId || ''));
  if (!purchase || purchase.userId !== req.user.id) return res.status(404).json({ error: 'Order not found' });

  const p = provider();
  if (outcome === 'failure') {
    db.purchases.patch(purchase.id, {
      status: 'failed', failureReason: 'simulated_failure', updatedAt: iso(),
    });
    // Fire a signed webhook too so the failure path is exercised end-to-end.
    const body = JSON.stringify({
      event: 'payment.failed',
      payload: { payment: { entity: { id: `pay_sbx_${Date.now()}`, order_id: purchase.providerOrderId, error_description: 'simulated_failure' } } },
    });
    deliverWebhook(body, p);
    return res.json({ outcome: 'failure' });
  }

  if (outcome === 'abandon') {
    db.purchases.patch(purchase.id, { status: 'cancelled', updatedAt: iso() });
    return res.json({ outcome: 'cancelled' });
  }

  const paymentId = `pay_sbx_${Math.random().toString(36).slice(2, 12)}`;
  const signature = p.sandboxSignature(purchase.providerOrderId, paymentId);

  // Deliver a signed webhook exactly like a real gateway would, then settle.
  const webhookBody = JSON.stringify({
    event: 'payment.captured',
    payload: {
      payment: {
        entity: {
          id: paymentId,
          order_id: purchase.providerOrderId,
          amount: purchase.amount,
          currency: purchase.currency,
          notes: {
            storyId: purchase.storyId,
            plan: purchase.plan,
            bluefm_test_accelerated: Boolean(req.body?.accelerate),
          },
        },
      },
    },
  });
  const hook = deliverWebhook(webhookBody, p);

  res.json({
    outcome: 'success',
    orderId: purchase.providerOrderId,
    paymentId,
    signature,
    webhook: hook,
  });
});

/** Where the webhook should be POSTed in this deployment. */
router.get('/webhook-info', requireAuth, (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Administrator access required.' });
  res.json({
    url: `${config.appUrl}/api/payments/webhooks/${provider().id}`,
    provider: provider().id,
    verifyHeader: provider().id === 'razorpay' ? 'X-Razorpay-Signature' : 'X-Sandbox-Signature',
  });
});

/**
 * Step 2 (server path) — verified webhook. Header signature is checked against
 * the raw body in constant time; event ids make replays harmless.
 */
router.post('/webhooks/:provider', (req, res) => {
  const name = req.params.provider;
  const p = provider();
  if (name !== p.id) return res.status(404).json({ error: 'Unknown provider' });

  const verdict = p.verifyWebhook(req.rawBody || Buffer.from(''), req.headers);
  if (!verdict.ok) {
    db.audit.set(`wh_${serverNow()}`, {
      id: `wh_${serverNow()}`, actorId: null, actorEmail: null,
      action: 'webhook.rejected', target: name, meta: { reason: verdict.reason }, at: iso(),
    });
    return res.status(400).json({ error: 'Invalid webhook signature.' });
  }

  let payload;
  try { payload = JSON.parse(req.rawBody.toString('utf8')); }
  catch { return res.status(400).json({ error: 'Invalid JSON body.' }); }

  const eventId =
    req.headers['x-razorpay-event-id'] ||
    req.headers['x-sandbox-event-id'] ||
    `evt_${payload.event}_${payload?.payload?.payment?.entity?.id || serverNow()}`;

  try {
    const result = processWebhook({ eventId, payload });
    res.json({ received: true, ...result });
  } catch (err) {
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

/** Simulated gateway delivery (in-process), signed with the same secret. */
function deliverWebhook(rawBody, p) {
  const headers = { 'content-type': 'application/json' };
  const crypto = p.id === 'razorpay' ? 'x-razorpay-signature' : 'x-sandbox-signature';
  if (p.id === 'sandbox') headers[crypto] = p.signWebhook(rawBody);
  else {
    // never forge a real provider signature — deliver nothing in production
    return { delivered: false, reason: 'real_provider_webhooks_come_from_gateway' };
  }
  const verdict = p.verifyWebhook(Buffer.from(rawBody), headers);
  if (!verdict.ok) return { delivered: false, reason: verdict.reason };
  const payload = JSON.parse(rawBody);
  const eventId = `evt_${payload.event}_${payload?.payload?.payment?.entity?.id || serverNow()}`;
  try {
    const result = processWebhook({ eventId, payload });
    return { delivered: true, eventId, ...result };
  } catch (err) {
    return { delivered: false, reason: err.message };
  }
}

export default router;
