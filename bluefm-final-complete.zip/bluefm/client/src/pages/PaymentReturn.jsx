import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api } from '../lib/api.js';
import { useAuth } from '../lib/store.jsx';
import { Spinner } from '../components/Ui.jsx';
import { IconCheck, IconAlert } from '../components/Icons.jsx';
import { formatDate } from '../lib/format.js';

/**
 * Landing page for Cashfree's return_url:
 *   /payment/return?order_id=bluefm_pur_...
 *
 * The redirect alone proves nothing — we ask our server to verify the order
 * against Cashfree (order_status === PAID) before showing success. Cashfree
 * can redirect a beat before the order flips to PAID, so we retry a few
 * times while the server reports `payment_pending`.
 */
const MAX_TRIES = 8;
const RETRY_MS = 2500;

export default function PaymentReturn() {
  const [params] = useSearchParams();
  const orderId = params.get('order_id');
  const navigate = useNavigate();
  const { user, ready } = useAuth();
  const [state, setState] = useState({ status: 'checking', result: null, error: null });
  const started = useRef(false);

  useEffect(() => {
    if (!ready || !user || !orderId || started.current) return undefined;
    started.current = true;
    let cancelled = false;
    let timer = null;

    const attempt = async (triesLeft) => {
      try {
        const result = await api.post('/api/payments/verify', { orderId });
        if (!cancelled) setState({ status: 'success', result, error: null });
      } catch (err) {
        if (cancelled) return;
        if (err.code === 'payment_pending' && triesLeft > 0) {
          timer = setTimeout(() => attempt(triesLeft - 1), RETRY_MS);
          return;
        }
        setState({ status: 'failed', result: null, error: err.message });
      }
    };
    attempt(MAX_TRIES);

    return () => { cancelled = true; if (timer) clearTimeout(timer); };
  }, [ready, user, orderId]);

  if (!orderId) {
    return (
      <div className="page">
        <div className="container" style={{ maxWidth: 480, paddingTop: 40 }}>
          <div className="form-error">No order id found in the payment return link.</div>
          <Link className="btn btn--primary btn--block mt-16" to="/library">Go to Library</Link>
        </div>
      </div>
    );
  }

  if (ready && !user) {
    return (
      <div className="page">
        <div className="container" style={{ maxWidth: 480, paddingTop: 40 }}>
          <h1 style={{ fontSize: 22, marginBottom: 8 }}>Confirming your payment</h1>
          <p className="muted small" style={{ marginBottom: 16 }}>
            Please sign in with the same account you used to pay, so we can confirm the order
            <span className="mono"> {orderId}</span>.
          </p>
          <button
            type="button"
            className="btn btn--primary btn--block btn--lg"
            onClick={() => navigate('/signin', { state: { from: `/payment/return?order_id=${orderId}` } })}
          >
            Sign in to confirm
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="container" style={{ maxWidth: 480, paddingTop: 40 }}>
        {state.status === 'checking' && (
          <div className="center" style={{ padding: '40px 0' }}>
            <Spinner label="Confirming payment with Cashfree…" />
            <p className="form-note" style={{ marginTop: 16 }}>
              Order <span className="mono">{orderId}</span>. Please don’t close this page.
            </p>
          </div>
        )}

        {state.status === 'success' && state.result && (
          <div className="center">
            <div
              style={{
                width: 64, height: 64, borderRadius: '50%', margin: '6px auto 16px',
                display: 'grid', placeItems: 'center',
                background: 'rgba(46,230,168,0.14)', border: '1px solid rgba(46,230,168,0.35)',
              }}
            >
              <IconCheck width="26" height="26" style={{ color: 'var(--green)' }} />
            </div>
            <h1 style={{ fontSize: 22, marginBottom: 6 }}>Payment successful</h1>
            <p className="small muted" style={{ marginBottom: 16 }}>
              Your pass is active
              {state.result.access?.expiresAt ? <> until <b>{formatDate(state.result.access.expiresAt)}</b></> : null}.
            </p>
            <div className="stack">
              {state.result.storySlug && (
                <Link className="btn btn--primary btn--block btn--lg" to={`/story/${state.result.storySlug}`}>
                  Start listening
                </Link>
              )}
              <Link className="btn btn--ghost btn--block" to="/library">Go to Library</Link>
            </div>
          </div>
        )}

        {state.status === 'failed' && (
          <div>
            <div className="banner-note banner-note--warn" style={{ marginBottom: 14 }}>
              <IconAlert />
              <div>
                <b>Payment not confirmed yet.</b> {state.error}
              </div>
            </div>
            <p className="small muted" style={{ marginBottom: 16 }}>
              If money was deducted, don’t pay again — the gateway webhook usually confirms the order
              within a minute. Check Library → Purchases, or retry below.
            </p>
            <div className="stack">
              <button
                type="button"
                className="btn btn--primary btn--block"
                onClick={() => { started.current = false; setState({ status: 'checking', result: null, error: null }); window.location.reload(); }}
              >
                Check again
              </button>
              <Link className="btn btn--ghost btn--block" to="/library">Go to Library</Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
