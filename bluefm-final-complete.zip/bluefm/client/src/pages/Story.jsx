import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../lib/api.js';
import { openCashfreeCheckout } from '../lib/cashfree.js';
import { useApi, useAuth, usePlayer, useToast } from '../lib/store.jsx';
import {
  Spinner, ErrorState, Sheet, StoryCard, Section,
} from '../components/Ui.jsx';
import {
  IconAlert, IconArrowLeft, IconCheck, IconCheckCircle, IconClock, IconHeadphones,
  IconHeart, IconInfo, IconLock, IconPause, IconPlay, IconShare, IconStar, IconUnlock,
  IconBolt, IconMicrophone, IconBook,
} from '../components/Icons.jsx';
import {
  approxDuration, clock, countdown, formatDate, money, plural,
} from '../lib/format.js';

export default function Story() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const player = usePlayer();
  const toast = useToast();

  const { data, loading, error, refetch, setData } = useApi(`/api/stories/${slug}`);
  const [expandDesc, setExpandDesc] = useState(false);
  const [purchaseOpen, setPurchaseOpen] = useState(false);
  const [plan, setPlan] = useState('weekly');
  const [favorite, setFavorite] = useState(false);

  useEffect(() => {
    if (data) setFavorite(Boolean(data.favorite));
  }, [data]);

  useEffect(() => {
    if (!data) return;
    document.title = `${data.story.title} · BLUEFM`;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute('content', data.story.synopsis || data.story.description);
    return () => { document.title = 'BLUEFM — Premium Audio Series'; };
  }, [data]);

  /* live countdown for active access */
  const [, setTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setTick((x) => x + 1), 30000);
    return () => clearInterval(t);
  }, []);

  if (loading) return <div className="page"><Spinner label="Loading story" /></div>;
  if (error) {
    return (
      <div className="page">
        <div className="mt-16"><Link to="/" className="btn btn--ghost btn--sm"><IconArrowLeft width="15" height="15" /> Back home</Link></div>
        <ErrorState error={error} onRetry={refetch} />
      </div>
    );
  }

  const { story, episodes, plans, related } = data;
  const access = story.access || { status: 'locked' };
  const unlocked = access.status === 'active';
  const currentEp = player.track?.story?.id === story.id ? player.track.episode : null;

  const inProgress = episodes.find((e) => e.progress && !e.progress.completed && e.progress.position > 0);
  const nextUp = inProgress || episodes.find((e) => !e.progress?.completed) || episodes[0];

  const playEpisode = async (ep) => {
    if (!user) return navigate('/signin', { state: { from: `/story/${story.slug}` } });
    if (currentEp?.id === ep.id) {
      player.toggle();
      player.setExpanded(true);
      return;
    }
    if (!unlocked) {
      setPurchaseOpen(true);
      return;
    }
    try {
      await player.play({
        story, episode: ep, queue: episodes,
        resumeAt: ep.progress?.position || 0,
      });
      player.setExpanded(true);
    } catch (err) {
      if (err.code === 'access_locked' || err.code === 'access_expired') setPurchaseOpen(true);
      else toast.error(err.message);
    }
  };

  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) await navigator.share({ title: story.title, text: story.tagline, url });
      else { await navigator.clipboard.writeText(url); toast.success('Link copied'); }
    } catch { /* dismissed */ }
  };

  const toggleFavorite = async () => {
    if (!user) return navigate('/signin', { state: { from: `/story/${story.slug}` } });
    try {
      if (favorite) {
        await api.del(`/api/me/favorites/${story.id}`);
        setFavorite(false);
        toast.info('Removed from favourites');
      } else {
        await api.put(`/api/me/favorites/${story.id}`);
        setFavorite(true);
        toast.success('Added to favourites');
      }
    } catch (err) { toast.error(err.message); }
  };

  return (
    <div className={`page${player.track ? ' has-player' : ''}`} style={{ paddingLeft: 0, paddingRight: 0 }}>
      {/* ------------------------------------------------------ hero */}
      <div className="story-hero">
        <div className="story-hero__bg" style={{ backgroundImage: `url(${story.cover})` }} />
        <div className="story-hero__fade" />
        <div className="story-hero__inner" style={{ paddingLeft: 16, paddingRight: 16 }}>
          <div className="story-hero__cover">
            <img src={story.cover2x || story.cover} alt={`${story.title} cover`} width="600" height="900" />
          </div>
          <div className="story-hero__info" style={{ flex: 1 }}>
            <div className="row" style={{ marginBottom: 10, gap: 6 }}>
              <button type="button" className="icon-btn" onClick={() => navigate(-1)} aria-label="Go back" style={{ width: 34, height: 34 }}>
                <IconArrowLeft width="16" height="16" />
              </button>
              <div style={{ flex: 1 }} />
              <button type="button" className="icon-btn" onClick={share} aria-label="Share story" style={{ width: 34, height: 34 }}>
                <IconShare width="16" height="16" />
              </button>
              <button
                type="button"
                className="icon-btn"
                onClick={toggleFavorite}
                aria-label={favorite ? 'Remove from favourites' : 'Add to favourites'}
                style={{ width: 34, height: 34, color: favorite ? 'var(--red)' : 'var(--text)' }}
              >
                <IconHeart filled={favorite} width="16" height="16" />
              </button>
            </div>
            <h1 className="story-hero__title">{story.title}</h1>
            <div className="story-hero__author">by {story.author} · narrated by {story.narrator}</div>
            <div className="story-hero__badges">
              {story.trending && <span className="pill pill--trend"><IconBolt width="10" height="10" /> Trending</span>}
              {story.isNew && <span className="pill pill--new">New</span>}
              {unlocked ? (
                <span className="pill pill--unlocked"><IconUnlock width="10" height="10" /> Unlocked</span>
              ) : access.status === 'expired' ? (
                <span className="pill pill--expired">Pass expired</span>
              ) : (
                <span className="pill pill--locked"><IconLock width="10" height="10" /> Locked</span>
              )}
            </div>
            <div className="story-hero__stats">
              <span><b>{story.rating?.toFixed(1)}</b> ★</span>
              <span><b>{story.episodeCount}</b> episodes</span>
              <span><b>{approxDuration(story.totalDuration)}</b> total</span>
            </div>
          </div>
        </div>
      </div>

      <div style={{ padding: '0 16px' }}>
        {/* ------------------------------------------------- access */}
        {unlocked && (
          <div className="access-banner access-banner--active">
            <IconCheckCircle />
            <div>
              <div>Full access active · {access.plan} pass</div>
              <div className="tiny" style={{ opacity: 0.8, marginTop: 2 }}>
                Expires {formatDate(access.expiresAt)} at {new Date(access.expiresAt).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' })}
              </div>
            </div>
            <div className="access-banner__time">
              {countdown(Date.parse(access.expiresAt) - Date.now())}
            </div>
          </div>
        )}
        {access.status === 'expired' && (
          <div className="access-banner access-banner--expired">
            <IconAlert />
            <div>
              <div>Your pass for this story has expired</div>
              <div className="tiny" style={{ opacity: 0.8, marginTop: 2 }}>Expired {formatDate(access.expiresAt)} · unlock again to continue</div>
            </div>
          </div>
        )}
        {!unlocked && access.status !== 'expired' && (
          <div className="access-banner">
            <IconLock />
            <div>
              <div>This story is locked</div>
              <div className="tiny dim" style={{ marginTop: 2 }}>Unlock from {money(plans[0]?.amount || 100)} for 24 hours</div>
            </div>
          </div>
        )}

        {/* ------------------------------------------------ actions */}
        <div className="detail-actions">
          {unlocked ? (
            <button type="button" className="btn btn--primary btn--lg" onClick={() => playEpisode(nextUp)}>
              {currentEp ? (player.playing ? <><IconPause width="16" height="16" /> Pause</> : <><IconPlay width="16" height="16" /> Resume</>)
                : inProgress ? <><IconPlay width="16" height="16" /> Continue listening</>
                  : <><IconPlay width="16" height="16" /> Start listening</>}
            </button>
          ) : (
            <button type="button" className="btn btn--primary btn--lg" onClick={() => setPurchaseOpen(true)}>
              <IconUnlock width="16" height="16" /> {access.status === 'expired' ? 'Renew access' : 'Unlock this story'}
            </button>
          )}
          <Link to={`/story/${story.slug}#episodes`} className="btn btn--glass btn--lg" style={{ flex: '0 1 auto' }}>
            <IconHeadphones width="16" height="16" /> Episodes
          </Link>
        </div>

        {/* --------------------------------------------------- body */}
        <div className="detail-body">
          <div>
            <Section title="About this series" icon={<IconBook />}>
              <p className={`description-text${expandDesc ? '' : ' clamped'}`}>{story.description}</p>
              <button type="button" className="read-more" onClick={() => setExpandDesc((v) => !v)}>
                {expandDesc ? 'Show less' : 'Read more'}
              </button>
            </Section>

            <Section title="Episodes" icon={<IconHeadphones />}>
              <div className="tiny dim" id="episodes">
                {unlocked
                  ? `All ${episodes.length} episodes are unlocked with your pass.`
                  : 'Browse every episode. Playback unlocks after purchase.'}
              </div>
              <div className="episode-list">
                {episodes.map((ep) => {
                  const pct = ep.progress?.duration
                    ? Math.min(100, Math.round((ep.progress.position / ep.progress.duration) * 100))
                    : 0;
                  const isCurrent = currentEp?.id === ep.id;
                  return (
                    <button
                      key={ep.id}
                      type="button"
                      className={`episode${isCurrent ? ' is-current' : ''}${!ep.unlocked ? ' is-locked' : ''}`}
                      onClick={() => playEpisode(ep)}
                      aria-label={`Episode ${ep.number}: ${ep.title}${ep.unlocked ? '' : ', locked'}`}
                    >
                      <span className="episode__num">{isCurrent && player.playing ? '▶' : ep.number}</span>
                      <span className="episode__body">
                        <span className="episode__title">{ep.title}</span>
                        <span className="episode__meta">
                          <IconClock width="11" height="11" /> {clock(ep.duration)}
                          {ep.progress?.completed && <><IconCheck width="11" height="11" /> Played</>}
                          {isCurrent && <span style={{ color: 'var(--blue-bright)' }}>Playing</span>}
                        </span>
                        {pct > 0 && <span className="episode__progress"><i style={{ width: `${pct}%` }} /></span>}
                      </span>
                      <span className="episode__action">
                        {!ep.unlocked ? <IconLock /> : isCurrent && player.playing ? <IconPause /> : <IconPlay />}
                      </span>
                    </button>
                  );
                })}
              </div>
            </Section>

            {related.length > 0 && (
              <Section title="You may also like" icon={<IconStar />}>
                <div className="rail">
                  {related.map((s) => <StoryCard key={s.id} story={s} />)}
                </div>
              </Section>
            )}
          </div>

          {/* aside: plans / metadata */}
          <aside className="detail-aside">
            {!unlocked && (
              <div className="plan-card">
                <div className="plan-card__head">
                  <span className="plan-card__title">{access.status === 'expired' ? 'Renew your pass' : 'Unlock this story'}</span>
                </div>
                <div className="plan-card__hint">One pass unlocks one story. No auto-renewal.</div>
                <div className="plan-options">
                  {plans.map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      className={`plan-option${plan === p.id ? ' active' : ''}`}
                      onClick={() => setPlan(p.id)}
                      aria-pressed={plan === p.id}
                    >
                      <span className="plan-option__radio" />
                      <span className="plan-option__label">
                        <span className="plan-option__name">
                          {p.label}
                          {p.badge && <span className="pill pill--new" style={{ height: 18, fontSize: 9.5 }}>{p.badge}</span>}
                        </span>
                        <span className="plan-option__sub">
                          {p.hours >= 24 ? `${Math.round(p.hours / 24)} ${p.hours >= 48 ? 'days' : 'day'} of access` : `${p.hours}h access`}
                        </span>
                      </span>
                      <span className="plan-option__price">{money(p.amount)}</span>
                    </button>
                  ))}
                </div>
                <button type="button" className="btn btn--primary btn--block" onClick={() => setPurchaseOpen(true)}>
                  <IconUnlock width="15" height="15" /> Unlock {story.title}
                </button>
                <p className="plan-note">
                  Access begins only after payment is verified by our server. You’ll see the exact expiry
                  date and remaining time here.
                </p>
              </div>
            )}

            {unlocked && (
              <div className="plan-card">
                <div className="plan-card__head">
                  <span className="plan-card__title">Your access</span>
                  <span className="pill pill--unlocked">Active</span>
                </div>
                <div className="meta-table mt-12">
                  <div className="meta-row"><dt>Plan</dt><dd style={{ textTransform: 'capitalize' }}>{access.plan}</dd></div>
                  <div className="meta-row"><dt>Purchased</dt><dd>{formatDate(access.purchasedAt)}</dd></div>
                  <div className="meta-row"><dt>Expires</dt><dd>{formatDate(access.expiresAt)}</dd></div>
                  <div className="meta-row"><dt>Remaining</dt><dd style={{ color: 'var(--green)' }}>{countdown(Date.parse(access.expiresAt) - Date.now())}</dd></div>
                </div>
                <button type="button" className="btn btn--ghost btn--block mt-16" onClick={() => setPurchaseOpen(true)}>
                  <IconBolt width="15" height="15" /> Extend access
                </button>
                <p className="plan-note">Extending adds time to your current expiry — you never lose paid time.</p>
              </div>
            )}

            <div className="plan-card mt-16">
              <div className="plan-card__title" style={{ marginBottom: 12 }}>Details</div>
              <dl className="meta-table">
                <div className="meta-row"><dt>Genre</dt><dd style={{ textTransform: 'capitalize' }}>{story.genre.join(', ')}</dd></div>
                <div className="meta-row"><dt>Language</dt><dd>{story.language}</dd></div>
                <div className="meta-row"><dt>Narrator</dt><dd>{story.narrator}</dd></div>
                <div className="meta-row"><dt>Released</dt><dd>{formatDate(story.publishedAt)}</dd></div>
                <div className="meta-row"><dt>Episodes</dt><dd>{plural(episodes.length, 'episode')}</dd></div>
                <div className="meta-row"><dt>Total length</dt><dd>{approxDuration(story.totalDuration)}</dd></div>
                <div className="meta-row"><dt>Rating</dt><dd style={{ color: 'var(--gold)' }}>{story.rating?.toFixed(1)} ★</dd></div>
              </dl>
            </div>
          </aside>
        </div>
      </div>

      <PurchaseSheet
        open={purchaseOpen}
        onClose={() => setPurchaseOpen(false)}
        story={story}
        plans={plans}
        initialPlan={plan}
        onSuccess={(accessData) => {
          setData({
            ...data,
            story: { ...story, access: accessData },
            episodes: episodes.map((e) => ({ ...e, unlocked: true })),
          });
          refetch();
        }}
        signedIn={Boolean(user)}
        onPlayNext={() => playEpisode(nextUp)}
      />
    </div>
  );
}

/* ====================================================== purchase flow */
function PurchaseSheet({ open, onClose, story, plans, initialPlan, onSuccess, signedIn, onPlayNext }) {
  const navigate = useNavigate();
  const toast = useToast();
  const { user } = useAuth();
  const [plan, setPlan] = useState(initialPlan);
  const [step, setStep] = useState('select'); // select | processing | redirecting | checkout | done | failed
  const [order, setOrder] = useState(null);
  const [error, setError] = useState(null);
  const [accelerate, setAccelerate] = useState(false);
  const [result, setResult] = useState(null);
  const [provider, setProvider] = useState(null);
  const [phone, setPhone] = useState('');

  useEffect(() => {
    if (open) {
      setStep('select'); setOrder(null); setError(null); setResult(null); setPlan(initialPlan);
      setPhone(user?.phone || '');
      api.get('/api/payments/plans')
        .then((d) => setProvider(d.provider || 'sandbox'))
        .catch(() => setProvider('cashfree'));
    }
  }, [open, initialPlan, user]);

  const selected = plans.find((p) => p.id === plan);
  const cleanPhone = phone.replace(/\D/g, '').replace(/^91(?=\d{10}$)/, '').replace(/^0+/, '');
  const phoneOk = /^[6-9]\d{9}$/.test(cleanPhone);

  const start = async () => {
    if (!signedIn) return navigate('/signin', { state: { from: `/story/${story.slug}` } });
    if (provider === 'cashfree' && !phoneOk) {
      setError('Please enter a valid 10-digit mobile number. Cashfree needs it for payment confirmation.');
      return;
    }
    setStep('processing');
    setError(null);
    try {
      const d = await api.post('/api/payments/checkout', {
        storyId: story.id,
        plan,
        ...(provider === 'cashfree' ? { phone: cleanPhone } : {}),
      });
      setOrder(d);
      if (d.checkout?.kind === 'cashfree') {
        setStep('redirecting');
        await openCashfreeCheckout({
          paymentSessionId: d.checkout.paymentSessionId,
          env: d.checkout.env,
        });
        // With redirectTarget '_self' the browser normally navigates away.
        // If the SDK resolves in-page, send the user to the return/verify page.
        navigate(`/payment/return?order_id=${encodeURIComponent(d.orderId)}`);
        return;
      }
      setStep('checkout');
    } catch (err) {
      if (err.code === 'phone_required') setProvider('cashfree');
      setError(err.message);
      setStep('select');
    }
  };

  /* sandbox gateway: simulate the provider, then verify the signature server-side */
  const simulate = async (outcome) => {
    setStep('processing');
    try {
      const sim = await api.post('/api/payments/sandbox/simulate', {
        purchaseId: order.purchaseId, outcome, accelerate,
      });
      if (sim.outcome !== 'success') {
        setError(outcome === 'failure' ? 'Payment failed. No access was granted.' : 'Payment cancelled. No access was granted.');
        setStep('failed');
        return;
      }
      const verified = await api.post('/api/payments/verify', {
        purchaseId: order.purchaseId,
        orderId: sim.orderId,
        paymentId: sim.paymentId,
        signature: sim.signature,
        accelerate,
      });
      setResult(verified);
      setStep('done');
      onSuccess(verified.access);
    } catch (err) {
      setError(err.message);
      setStep('failed');
    }
  };

  return (
    <Sheet
      open={open}
      onClose={() => { if (step !== 'processing') onClose(); }}
      title={step === 'done' ? 'You’re all set' : `Unlock ${story.title}`}
      subtitle={step === 'select' ? 'Choose a pass. One story per purchase.' : undefined}
    >
      {step === 'select' && (
        <>
          <div className="plan-options">
            {plans.map((p) => (
              <button
                key={p.id}
                type="button"
                className={`plan-option${plan === p.id ? ' active' : ''}`}
                onClick={() => setPlan(p.id)}
                aria-pressed={plan === p.id}
              >
                <span className="plan-option__radio" />
                <span className="plan-option__label">
                  <span className="plan-option__name">
                    {p.label}
                    {p.badge && <span className="pill pill--new" style={{ height: 18, fontSize: 9.5 }}>{p.badge}</span>}
                  </span>
                  <span className="plan-option__sub">
                    {p.hours >= 24 ? `${Math.round(p.hours / 24)} ${p.hours >= 48 ? 'days' : 'day'} of access` : `${p.hours}h access`}
                  </span>
                </span>
                <span className="plan-option__price">{money(p.amount)}</span>
              </button>
            ))}
          </div>

          <div className="banner-note" style={{ marginBottom: 14 }}>
            <IconInfo />
            <div>
              This unlocks <b>only {story.title}</b>. Other stories stay locked. Access is granted on our server
              after payment verification and expires automatically.
            </div>
          </div>

          {provider === 'cashfree' && (
            <div className="field" style={{ marginBottom: 14 }}>
              <label htmlFor="pay-phone">Mobile number</label>
              <input
                id="pay-phone"
                type="tel"
                inputMode="numeric"
                autoComplete="tel-national"
                maxLength={14}
                placeholder="10-digit mobile number"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="input"
              />
              <p className="form-note" style={{ marginTop: 6, textAlign: 'left' }}>
                Cashfree needs a valid mobile number for payment confirmation. It’s saved to your account for next time.
              </p>
            </div>
          )}

          {error && <div className="form-error">{error}</div>}

          <button
            type="button"
            className="btn btn--primary btn--block btn--lg"
            onClick={start}
            disabled={provider === 'cashfree' && !phoneOk}
          >
            Pay {money(selected?.amount || 0)} securely
          </button>
          <p className="form-note">
            {provider === 'cashfree' ? (
              <>You’ll be redirected to Cashfree’s secure checkout. Access unlocks only after server-side verification.</>
            ) : (
              <>Test mode is active on this deployment — no money is charged.{' '}
                <a href="#security" onClick={(e) => e.preventDefault()}>How verification works</a></>
            )}
          </p>
        </>
      )}

      {(step === 'processing' || step === 'redirecting') && (
        <div className="center" style={{ padding: '28px 0' }}>
          <Spinner label={step === 'redirecting' ? 'Opening Cashfree checkout…' : 'Contacting payment gateway'} />
          {step === 'redirecting' && (
            <p className="form-note" style={{ marginTop: 14 }}>
              Please complete the payment on the next screen. You’ll be brought back here automatically.
            </p>
          )}
        </div>
      )}

      {step === 'checkout' && order && (
        <>
          <div className="banner-note banner-note--warn" style={{ marginBottom: 14 }}>
            <IconAlert />
            <div>
              <b>Sandbox checkout.</b> This deployment uses BLUEFM’s simulated gateway so the full flow is
              testable. Order <span className="mono">{order.orderId}</span> · {money(order.amount)}
            </div>
          </div>

          <div className="stack">
            <button
              type="button"
              className="btn btn--primary btn--block btn--lg"
              onClick={() => simulate('success')}
            >
              <IconCheck width="16" height="16" /> Authorise test payment
            </button>
            <button type="button" className="btn btn--ghost btn--block" onClick={() => simulate('failure')}>
              Simulate failed payment
            </button>
            <button type="button" className="btn btn--ghost btn--block" onClick={() => simulate('abandon')}>
              Cancel checkout
            </button>
          </div>

          <label className="row mt-16" style={{ gap: 9, fontSize: 12, color: 'var(--text-2)', alignItems: 'flex-start' }}>
            <input
              type="checkbox"
              checked={accelerate}
              onChange={(e) => setAccelerate(e.target.checked)}
              style={{ marginTop: 2, width: 16, height: 16, accentColor: 'var(--blue)' }}
            />
            <span>
              <b>Demo fast-forward</b> — compress this pass to ~{Math.max(1, Math.round((selected?.hours || 24) / 10))}% of
              its duration so expiry and renewal can be tested without waiting.
            </span>
          </label>

          <p className="form-note">
            Nothing unlocks until the server verifies the payment signature and webhook. Try a failed payment
            to confirm access is denied.
          </p>
        </>
      )}

      {step === 'done' && result && (
        <div className="center">
          <div
            style={{
              width: 64, height: 64, borderRadius: '50%', margin: '6px auto 16px',
              display: 'grid', placeItems: 'center',
              background: 'rgba(46,230,168,0.14)', border: '1px solid rgba(46,230,168,0.35)',
            }}
          >
            <IconCheck width="26" height="26" style={{ color: 'var(--green)' }} />
          </div>
          <h3 style={{ fontSize: 18, marginBottom: 6 }}>Access granted</h3>
          <p className="small muted" style={{ marginBottom: 16 }}>
            {story.title} is unlocked until <b>{formatDate(result.access?.expiresAt)}</b>
            {result.access?.msRemaining ? ` (${countdown(result.access.msRemaining)})` : ''}.
          </p>
          <button
            type="button"
            className="btn btn--primary btn--block btn--lg"
            onClick={() => {
              onClose();
              onPlayNext?.();
            }}
          >
            <IconHeadphones width="16" height="16" /> Start listening
          </button>
          <p className="form-note">Your pass is stored on the server and shown in Library → Purchases.</p>
        </div>
      )}

      {step === 'failed' && (
        <>
          <div className="form-error">{error}</div>
          <div className="stack">
            <button type="button" className="btn btn--primary btn--block" onClick={() => setStep('select')}>
              Try again
            </button>
            <button type="button" className="btn btn--ghost btn--block" onClick={onClose}>Close</button>
          </div>
          <p className="form-note">
            Access was <b>not</b> granted. Failed transactions stay in your history for reference.
          </p>
        </>
      )}
    </Sheet>
  );
}
