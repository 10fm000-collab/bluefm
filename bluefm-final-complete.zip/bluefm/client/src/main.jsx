import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import './styles/app.css';
import { AuthProvider, PlayerProvider, ToastProvider, usePlayer } from './lib/store.jsx';
import { TopBar, BottomNav, ScrollToTop } from './components/Layout.jsx';
import { MiniPlayer, FullPlayer } from './components/Player.jsx';
import Home from './pages/Home.jsx';
import Explore from './pages/Explore.jsx';
import Story from './pages/Story.jsx';
import SignIn from './pages/SignIn.jsx';
import Library from './pages/Library.jsx';
import Profile from './pages/Profile.jsx';
import Admin from './pages/Admin.jsx';
import PaymentReturn from './pages/PaymentReturn.jsx';
import NotFound from './pages/NotFound.jsx';

function Shell() {
  const location = useLocation();
  const player = usePlayer();
  const isAuth = location.pathname === '/signin';
  const isAdmin = location.pathname.startsWith('/admin');
  const hideNav = player.expanded || isAuth;

  return (
    <div className="app-shell">
      {!isAuth && <TopBar />}
      <main id="main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/explore" element={<Explore />} />
          <Route path="/story/:slug" element={<Story />} />
          <Route path="/signin" element={<SignIn />} />
          <Route path="/library" element={<Library />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/payment/return" element={<PaymentReturn />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      {!isAuth && !isAdmin && <BottomNav hidden={hideNav} />}
      <MiniPlayer />
      <FullPlayer />
    </div>
  );
}

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <PlayerProvider>
            <ScrollToTop />
            <Shell />
          </PlayerProvider>
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>
  </React.StrictMode>,
);

if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  });
}
