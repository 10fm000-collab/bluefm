# BLUEFM — Deployment

> This is a historical/general deployment reference. For the already-running
> production site, use `../README.md` and `../HANDOFF-STATUS.md`: project
> `nodio-575bf`, domain `bluefm.live`, Cashfree, Cloudflare delivery, and the
> `functions:web` codebase. Do not apply the old sample hosting/payment values
> below to the live project or redeploy rules/indexes for routine updates.

## 1. Build & run

```bash
npm ci
npm run seed          # first deploy only (or when you want demo content)
npm run build         # dist/client
NODE_ENV=production npm start
```

The server serves `dist/client` and the API on one origin, so no CORS or proxy config is needed.

## 2. Environments

Keep staging and production fully separate (different `DATA_DIR`, different secrets, different
Razorpay keys — use Razorpay **test mode** in staging).

| | staging | production |
| --- | --- | --- |
| `APP_URL` | https://staging.bluefm.app | https://bluefm.app |
| `DATA_DIR` | /var/lib/bluefm/staging | /var/lib/bluefm/prod |
| `PAYMENT_PROVIDER` | `sandbox` or razorpay test keys | `razorpay` |
| `AUDIO_STORAGE` | local | `b2` |
| `NODE_ENV` | production | production |

## 3. Hosting options

**Container (recommended)** — single node process behind a reverse proxy:

```dockerfile
FROM node:20-slim
WORKDIR /app
RUN apt-get update && apt-get install -y ffmpeg && rm -rf /var/lib/apt/lists/*
COPY package*.json ./
RUN npm ci --omit=dev
COPY . .
RUN npm run build
ENV NODE_ENV=production PORT=8080
EXPOSE 8080
CMD ["node", "server/index.js"]
```

Mount a persistent volume at `DATA_DIR` (store + media). Add a CDN (Cloudflare) in front for
`/media/covers/*` and `/assets/*`.

**Firebase Hosting + Cloud Run** — put the API on Cloud Run and Firebase Hosting rewrites
`/api/**` and `/media/**` to it. `firebase.json`:

```json
{ "hosting": {
    "public": "dist/client",
    "rewrites": [
      { "source": "/api/**", "run": { "serviceId": "bluefm-api", "region": "asia-south1" } },
      { "source": "**", "destination": "/index.html" }
    ]
} }
```

## 4. Environment variables

See `.env.example`. Minimum for production:

```env
NODE_ENV=production
APP_URL=https://bluefm.app
DATA_DIR=/var/lib/bluefm
SESSION_SECRET=<64 hex chars>
AUDIO_SIGNING_SECRET=<64 hex chars>
PAYMENT_PROVIDER=razorpay
RAZORPAY_KEY_ID=rzp_live_...
RAZORPAY_KEY_SECRET=...
RAZORPAY_WEBHOOK_SECRET=...
AUDIO_STORAGE=b2
AUDIO_PUBLIC_BASE=https://cdn.bluefm.app
ADMIN_EMAIL=admin@bluefm.app
ADMIN_PASSWORD=<strong, then change from the UI>
```

Generate secrets: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`.

## 5. Firestore security rules (for the new isolated collections)

Deploy **only** after creating the new collections. These rules do not reference any existing
collection, so the current APK/website is unaffected.

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    function isAdmin() {
      return request.auth != null
        && exists(/databases/$(database)/documents/admin_users/$(request.auth.uid));
    }

    // Public catalog: read-only for everyone, writable by admins only.
    match /stories_web/{id}   { allow read: if true;  allow write: if isAdmin(); }
    match /episodes_web/{id}  { allow read: if true;  allow write: if isAdmin(); }
    match /categories/{id}    { allow read: if true;  allow write: if isAdmin(); }

    // Entitlements: owner may read, NEVER write. Only the Admin SDK (Cloud Functions)
    // may create or extend access after a verified payment.
    match /story_entitlements/{id} {
      allow read: if request.auth != null && resource.data.userId == request.auth.uid;
      allow write: if false;
    }

    match /purchases_web/{id} {
      allow read: if request.auth != null && resource.data.userId == request.auth.uid;
      allow write: if false;
    }

    match /users/{uid} {
      allow read, update: if request.auth != null && request.auth.uid == uid
                            && !request.resource.data.diff(resource.data).affectedKeys()
                                 .hasAny(['role', 'disabled']);
      allow create: if false; // created by the server
      allow delete: if false;
    }

    match /listening_progress/{id} {
      allow read, write: if request.auth != null && request.resource.data.userId == request.auth.uid;
    }
    match /listening_history/{id} {
      allow read: if request.auth != null && resource.data.userId == request.auth.uid;
      allow create: if request.auth != null && request.resource.data.userId == request.auth.uid;
      allow update, delete: if false;
    }
    match /favorites/{id} {
      allow read, write: if request.auth != null && request.resource.data.userId == request.auth.uid;
    }

    match /admin_users/{uid} { allow read: if isAdmin(); allow write: if false; }
    match /audit_logs/{id}   { allow read: if isAdmin(); allow write: if false; }
  }
}
```

Note the deliberate `allow write: if false` on entitlements — access is granted **only** by trusted
server code (Cloud Functions using the Admin SDK), never by a client SDK call.

## 6. Razorpay + audio CDN

**Razorpay**
1. Dashboard → Settings → API keys → generate **live** keys → `RAZORPAY_KEY_ID` / `_SECRET`.
2. Settings → Webhooks → add `https://<APP_URL>/api/payments/webhooks/razorpay`
   with events `payment.captured`, `payment.failed`, `refund.processed`; copy the secret into
   `RAZORPAY_WEBHOOK_SECRET`.
3. Set `PAYMENT_PROVIDER=razorpay`, restart, then load a story page: the checkout sheet switches to
   Razorpay Checkout. Verify one live ₹1 transaction — some issuing banks block sub-₹5 card
   authorisations even though Razorpay accepts the order. If that happens, keep the price and offer
   UPI intent (usually fine at ₹1) rather than silently changing pricing.
4. Webhook endpoint must be a public HTTPS URL (Razorpay will not call staging on localhost).

**Backblaze B2 + Cloudflare**
1. `AUDIO_STORAGE=b2`, `AUDIO_PUBLIC_BASE=https://cdn.bluefm.app`.
2. Keep existing object keys (`last-metro-e1.mp3` …) — no re-upload required.
3. In the `b2` storage driver, `authorizeFile(story, episode, ttl)` should return a
   B2 download-authorization-token URL (or a Cloudflare signed URL) valid for ~600 s, so access
   follows the same entitlement check as the local driver. Range requests are supported by B2 natively.
4. Cloudflare cache rule: bypass cache for URLs carrying a signature/`t=` parameter, cache
   `/media/covers/*` aggressively.

## 7. PWA / domain

- Serve over HTTPS (required for service worker, install prompt and Media Session).
- `public/manifest.webmanifest` already declares `display: standalone`, `start_url: /?source=pwa`,
  maskable icon, shortcuts and theme colour `#05070f`.
- `public/sw.js` caches the shell only and is version-prefixed (`bluefm-v1-*`) — bump `VERSION` when
  you ship breaking shell changes.

## 8. Production smoke test (run after every deploy)

```bash
B=https://bluefm.app
curl -fsS $B/api/health
curl -fsS $B/api/home | head -c 200
curl -s -o /dev/null -w "%{http_code}\n" $B/api/playback/stream/last-metro-e1   # expect 403
curl -s -o /dev/null -w "%{http_code}\n" $B/api/admin/stats                     # expect 401
```

Then manually: sign up → buy daily pass → play → confirm expiry text → sign out → confirm locked.

## 9. Operational notes

- Restart flushes the JSON store gracefully (SIGTERM handler). Back up `DATA_DIR` (store + media).
- For Firestore, replace `server/db.js` and keep everything else — routes only use the six adapter
  methods.
- Move rate limiting to Redis when running more than one instance.
- Add a cron/Cloud Function to flip stale entitlements proactively (the app already does it lazily).

## Real stack: Firebase + Cashfree + Backblaze B2 (+ Cloudflare)

Detailed setup: [`firebase/README.md`](../firebase/README.md).

### Payment provider switch

```bash
# local / staging
PAYMENT_PROVIDER=sandbox

# real Cashfree (sandbox keys)
PAYMENT_PROVIDER=cashfree
CASHFREE_CLIENT_ID=...
CASHFREE_CLIENT_SECRET=...
CASHFREE_ENV=sandbox

# real Cashfree (live)
CASHFREE_ENV=production
```

Cashfree amount **rupees** me leta hai, isliye server `amountPaise / 100` bhejta
hai. Verify hamesha `GET /orders/{id}` se hota hai — client kuch bhi bhej de.

### Audio delivery switch

```bash
AUDIO_STORAGE=local   # dev
AUDIO_STORAGE=b2      # private bucket + 600s signed URLs
B2_BUCKET_NAME=bluefm-web-audio
```

B2 signing fail ho jaye to playback **proxy** pe fall back ho jaata hai (user ko
kuch nahi dikhta, sirf warning log hota hai).

### Plans (server-side truth)

| id | amount | hours |
|----|--------|-------|
| daily | ₹2 (200 paise) | 24 |
| weekly | ₹14 (1400 paise) | 168 |
| monthly | ₹60 (6000 paise) | 720 |

Price badalna ho to sirf `server/config.js` + `firebase/functions-web/index.js`
ke `PLANS` object me badlo — client ko chhune ki zaroorat nahi.
