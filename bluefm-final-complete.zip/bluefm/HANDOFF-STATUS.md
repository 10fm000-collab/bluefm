# BLUEFM — handoff notes for future support

Read this file before proposing another deploy or asking the owner for setup details. It is a source-code handoff, not a credential file.

## Confirmed production state

- Primary site is `https://bluefm.live`; `www.bluefm.live` is accepted/redirected and `bluefm.vercel.app` is the fallback origin.
- Vercel project is `bluefmtts-projects/bluefm`. The latest website deploy, including the **Download App** header button, reported `Ready`. The CLI may still print the old `bluefm.qzz.io` alias; the owner has confirmed the live domain, and the current build was verified on `bluefm.live`. Do not treat that legacy alias line alone as a failed deploy.
- The header button downloads the APK from `https://github.com/bluefmtts/bluefm-/releases/latest/download/bluefm0.6.apk`.
- Firebase project is `nodio-575bf`. The correct deploy filter is `functions:web` (not `functions:webApi`); deploy from the `firebase/` folder and include `--project nodio-575bf`.
- Cloudflare Worker: `https://bluefm-stream.singhvikas21571.workers.dev`. It handles delivery and upload; B2 (`bluefm-web-audio`) is storage only.
- Cashfree keys are already set and payments have worked. The owner already handled the domain whitelist. **Do not ask for keys again or change them.** New orders should use the live-domain return/webhook URLs from the code.
- Policy pages are present: `/privacy.html`, `/terms.html`, `/refund.html`, `/contact.html`; support email is `BLUEFMOFFICIAL01@GMAIL.COM`. Refund stance: verified technical issue, failed/debited payment, or duplicate charge only.
- The Hindi title `हे परी, प्लीज़ मुझे अकेला छोड़ दो!` must remain Hindi. The code generates a safe ASCII storage ID; never tell the owner to rename the story.

## Owner preferences / deployment rules

- Give one copy-paste PowerShell command at a time, with the full Windows path, then wait for its output.
- Do not put URLs inside copy-paste commands; their chat client mangles them. Give URLs as clickable links separately.
- Never request or paste secrets. Use `firebase functions:secrets:set` or `wrangler secret put` hidden prompts if a secret operation is ever required.
- Avoid unnecessary redeploys. Vercel frontend, Firebase Functions, and Cloudflare Worker are separate layers; deploy only the layer changed.
- Do not run `fb:deploy` for normal web changes because it also deploys rules/indexes. Use `npm run fb:prepare`, then `firebase deploy --only functions:web --project nodio-575bf` from `firebase/` only when the Functions source changed.
- Demo-clear is destructive: dry-run first, and only use `--apply` after the owner explicitly approves.
- Local admin uploads to the live Worker can fail CORS; use the live admin panel for production upload verification.

## Remaining checks previously noted

These are verification tasks, not permission to change or delete data automatically:

1. Confirm the real Hindi story, cover, and MP3 upload from the live admin panel. The production code fix is deployed; keep the title unchanged.
2. Finish Cloudflare delivery verification: successful real upload, authorized playback selects `delivery: "cloudflare"`, and MP3 responses carry `X-Stream-Provider: cloudflare+b2`.
3. Only after confirming real content works, review the demo-clear dry-run with the owner before applying it and redeploying the backend if needed.
4. The live `/signin` page currently displays scaffold demo/test-account UI, including a demo admin string. The owner’s real admin account is separate. Do not treat demo values as owner credentials; ask before removing/redeploying that UI, and ensure demo accounts/data are cleared through the approved process.
5. A prior code audit flagged `server/routes/playback.js` around the `signEdgeToken` call for checking that the episode path is included. Confirm against live behavior/tests before changing it.

A fresh payment attempt after the domain change was not explicitly reported in the chat; do not assume failure. If the owner wants payment verification, create a **fresh order**—do not retry a previously failed order.

## Code/package details

- This archive combines `bluefm-fixed.zip` with the payment, Cloudflare upload, slug/Hindi ID, domain, policy, cache, and Download App hotfixes. It is one complete source snapshot, not a bundle of nested hotfix ZIPs.
- The archive includes local sample media and build output, but no `.env`, private keys, service-account credentials, production user/payment data, or production B2 uploads.
- `npm run build` is the frontend build check. `npm run test:worker` and `npm run test:cloud` are isolated checks; the full API/Cashfree harness also requires the repository's test setup and media tooling.
