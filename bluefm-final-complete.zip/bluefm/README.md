# BLUEFM — complete website source

This folder is the complete source snapshot for the BLUEFM web app. It includes the latest approved website changes: Cashfree checkout and server-side verification, the Firebase `web` backend, Cloudflare upload/stream delivery, Hindi-safe internal story IDs, policy pages/footer, the `bluefm.live` domain settings, and the sticky **Download App** button.

## Live website and services

- Primary website: **https://bluefm.live**
- `www.bluefm.live` is accepted and may redirect to the primary host.
- `bluefm.vercel.app` remains a fallback origin.
- Android APK download button points to the BLUEFM GitHub Release: `https://github.com/bluefmtts/bluefm-/releases/latest/download/bluefm0.6.apk`.
- Firebase project: `nodio-575bf`; deploy the existing `functions:web` codebase only.
- Cloudflare Worker handles signed audio delivery and browser-to-Worker uploads; Backblaze B2 is storage only.
- Payments use Cashfree. Access is granted only after server-side payment verification.
- Support: `BLUEFMOFFICIAL01@GMAIL.COM`. Refund policy is technical issue, failed payment or duplicate charge only.

See [`HANDOFF-STATUS.md`](HANDOFF-STATUS.md) for current deployment status, standing instructions, and known follow-ups. See [`DOMAIN-SETUP.md`](DOMAIN-SETUP.md) and [`WINDOWS-SETUP.md`](WINDOWS-SETUP.md) for deployment details.

## Project contents

- `client/` — React/Vite website, admin panel, PWA, and download button.
- `server/`, `firebase-web/` — Express API and Firebase integration source.
- `firebase/` — Firestore rules/indexes and the `functions:web` deployment project.
- `cloudflare/` — signed stream/upload Worker; no Backblaze credentials are hardcoded.
- `public/` — legal/support pages, PWA assets, and public media.
- `scripts/` — Functions preparation, media setup, migration, admin, and demo-clear tools.
- `test/` — API, Cashfree, Cloudflare Worker, and cloud-configuration tests.
- `data/media/` — bundled local sample/demo audio and covers for development; this is **not** a backup of production uploads or Firestore data.

The original sign-in screen still contains local demo/test-account UI from the scaffold. Those values are not owner credentials; see `HANDOFF-STATUS.md` before treating that screen as final public-facing copy.

## Local build

Use Node.js 22. From this folder:

```powershell
npm ci
npm run build
```

`npm run build` creates `dist/client`. For a local website/API run, configure a local `.env` from `.env.example` first; do not copy production secrets into the archive or chat.

## Tests

The isolated Worker and cloud configuration suites run as follows. `test:cloud`
expects the Functions mirror and domain-only local `.env` to have been generated
first; that `.env` is intentionally not shipped in this ZIP.

```powershell
npm run fb:prepare
npm run test:worker
npm run test:cloud
```

The broader API/Cashfree suite uses the repository test harness and media tools;
see [`docs/TESTING.md`](docs/TESTING.md).

## Deploy only when the corresponding layer changes

- Website/Vercel: `vercel --prod` from this folder.
- Functions: run `npm run fb:prepare` here, then from `firebase/` run `firebase deploy --only functions:web --project nodio-575bf`.
- Worker: `npm run cf:deploy` from this folder.

Do not use `functions:webApi` (wrong deploy filter) or include Firestore rules/indexes in a routine website update. `npm run fb:deploy` also includes rules/indexes, so use the explicit command above. No deploy is needed for an unchanged layer.

## Secrets and production data

This snapshot intentionally excludes `.env`, Cashfree secrets, Firebase service-account files, B2 keys, Cloudflare Worker secrets, `node_modules`, and production Firestore/user/payment records. Keep secrets in the existing Vercel/Firebase/Cloudflare secret stores and set them only through their hidden prompts. Never paste secret values into chat. `.env.example` contains placeholders, not live credentials.

The local sample media is included so the project structure and local development paths are complete. Production uploads live in the private B2 bucket and their metadata/access records live in Firebase; they are not exported into this source ZIP. The APK itself remains a separate GitHub Release asset, not part of the website source.
